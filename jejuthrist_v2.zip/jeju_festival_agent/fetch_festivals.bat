@echo off
chcp 65001 >nul
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" goto noinstall
echo Jeju festival data download (hub API, daily limit safe). Keep this window open.
".venv\Scripts\python.exe" -X utf8 scripts\fetch_festivals.py --wait
pause
exit /b
:noinstall
echo [!] Run install.bat first.
pause
exit /b 1
