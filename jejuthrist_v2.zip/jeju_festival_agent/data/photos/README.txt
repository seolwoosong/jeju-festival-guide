여기에 사진을 넣으면 화면의 그림 대신 사진이 나옵니다. (없으면 직접 그린 제주 그림이 나옵니다)

  hero.jpg  첫 화면 위쪽 (가로로 긴 사진, 예: 한라산·오름·유채꽃)
  fun.jpg   🎉 즐기러 가는 사람 화면 (축제를 즐기는 모습)
  prep.jpg  🛠 준비하는 사람 화면 (천막 설치·준비 모습)

.jpg .jpeg .png .webp 모두 됩니다. 저작권이 있는 사진은 쓰지 마세요.
직접 찍은 사진이나 공공누리 제1유형(출처표시) 사진처럼 써도 되는 사진만 넣고, 출처를 아래에 적어 두세요.

출처 (credits.json 에도 같은 내용이 있고, 화면 아래에 자동으로 표시됩니다):
  hero.jpg  「새별오름에서 보는 제주 석양」 HiHoHo, CC BY-SA 3.0, Wikimedia Commons (가로 1600px로 줄임)
            https://commons.wikimedia.org/wiki/File:%EC%83%88%EB%B3%84%EC%98%A4%EB%A6%84.jpg
  fun.jpg   「제주왕벚꽃축제」 Korea.net / Korean Culture and Information Service, CC BY-SA 2.0, Wikimedia Commons
            https://commons.wikimedia.org/wiki/File:Jeju_King_Cherry_Blossom_Spring_Festival_-_4403570832.jpg
  prep      자유 이용 사진을 찾지 못해 직접 그린 그림(agent/art/prep.svg)을 씁니다.
