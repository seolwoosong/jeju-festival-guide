"""축제 목록(data/festivals.csv)에 있는 축제들의 날씨·버스 자료를 제주데이터허브에서 한꺼번에 받는다.

- 데이터마다 하루 호출 한도(기본 950번, .env 의 HUB_DAILY_BUDGET)를 넘지 않게 센다.
  오늘 쓴 횟수는 data/prep/_usage.json 에 남아, 같은 날 다시 실행해도 한도를 넘지 않는다.
- 이미 받은 날짜는 건너뛴다(이어받기).
- 한도가 차면 멈춘다. --wait 를 붙이면 자정(00:02)까지 기다렸다가 이어서 받는다.
- 무엇을 먼저 받을지는 아래 BUS_PLAN 순서를 따른다. 여러 축제가 같은 날짜를 함께 쓰도록 골랐다.

실행 (jeju_festival_agent 폴더에서)
  .venv\\Scripts\\python.exe scripts\\fetch_festivals.py          # 오늘 한도까지
  .venv\\Scripts\\python.exe scripts\\fetch_festivals.py --wait   # 한도가 차면 자정까지 기다렸다가 계속
  .venv\\Scripts\\python.exe scripts\\fetch_festivals.py --plan   # 받을 목록과 호출 수 예상만 보기
"""
from __future__ import annotations

import json
import os
import sys
import time
from datetime import date, datetime, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.path.insert(0, str(Path(__file__).resolve().parent))

import fetch_prep_data as fp  # noqa: E402
from agent import festivals as F  # noqa: E402

USAGE = fp.OUT / "_usage.json"
BUS_CALLS_PER_DAY = 70        # 하루치 버스 자료 ≈ 6,000~7,000행 = 쪽 60~70개 (예상치)

# 버스: 우선순위 순서. (설명, 날짜들)
#  봄 묶음 하나로 들불 평소(3/21~23) + 왕벚꽃·유채꽃 축제일(3/28~30)과 평소(3/21~23, 4/4~6)를 함께 채운다.
#  가을 묶음 하나로 탐라문화제(10/10~12)와 칠십리축제(10/17~19)의 축제일·평소를 함께 채운다.
#  (10/3~5는 개천절·추석 연휴라 평소로 쓰지 않는다)
BUS_PLAN = [
    ("봄: 들불 평소 · 왕벚꽃·유채꽃 축제일과 평소 (2025)",
     ["2025-03-21", "2025-03-22", "2025-03-23", "2025-03-28", "2025-03-29", "2025-03-30",
      "2025-04-04", "2025-04-05", "2025-04-06", "2025-03-09"]),
    ("가을: 탐라문화제·칠십리축제 축제일과 평소 (2025)",
     ["2025-10-10", "2025-10-11", "2025-10-12", "2025-10-17", "2025-10-18", "2025-10-19",
      "2025-10-24", "2025-10-25", "2025-10-26"]),
    ("해녀축제 (2025)", ["2025-09-20", "2025-09-21", "2025-09-13", "2025-09-14", "2025-09-27", "2025-09-28"]),
    ("고사리축제 (2025)", ["2025-04-26", "2025-04-27", "2025-04-19", "2025-04-20", "2025-05-03", "2025-05-04"]),
    ("방어축제 (2024)", ["2024-11-28", "2024-11-29", "2024-11-30", "2024-12-01",
                       "2024-11-21", "2024-11-22", "2024-11-23", "2024-11-24"]),
]


class BudgetReached(Exception):
    pass


def _today() -> str:
    return date.today().isoformat()


def load_usage() -> dict:
    try:
        u = json.loads(USAGE.read_text(encoding="utf-8"))
    except Exception:
        u = {}
    return u if u.get("date") == _today() else {"date": _today()}


def save_usage(u: dict):
    USAGE.parent.mkdir(parents=True, exist_ok=True)
    USAGE.write_text(json.dumps(u, ensure_ascii=False), encoding="utf-8")


def budget() -> int:
    return int(os.environ.get("HUB_DAILY_BUDGET", "950"))


_real_call = fp.call
_usage = {}


def counted_call(api, key, params):
    global _usage
    if _usage.get("date") != _today():          # 자정을 넘기면 새 한도
        _usage = {"date": _today()}
    if _usage.get(api, 0) >= budget():
        raise BudgetReached(api)
    _usage[api] = _usage.get(api, 0) + 1
    save_usage(_usage)
    return _real_call(api, key, params)


fp.call = counted_call


def weather_plan() -> list[tuple[str, date]]:
    """(축제 이름, 날짜) — 축제 목록 순서대로, 중복 날짜는 한 번만."""
    cat, _ = F.load()
    seen, out = set(), []
    have = {p.stem[3:] for p in (fp.OUT / "weather").glob("wx_*.csv")}
    for _, r in cat.iterrows():
        for d in F.weather_days(r):
            if d in seen or d > date.today() - timedelta(days=2):
                continue
            seen.add(d)
            if f"{d:%Y%m%d}" not in have:
                out.append((abs(r["year"] - d.year), f"{r['year']} {r['name']}", d))
    # 최근 해부터: 한도가 차도 모든 축제가 최근 몇 해치는 먼저 갖도록
    return [(label, d) for _, label, d in sorted(out, key=lambda x: (x[0], x[2]))]


def bus_plan() -> list[tuple[str, str]]:
    have = {p.stem[4:] for p in (fp.OUT / "bus").glob("bus_*.csv")}
    out = []
    for label, days in BUS_PLAN:
        for d in days:
            if d.replace("-", "") not in have and (label, d) not in out:
                out.append((label, d))
    return out


def show_plan():
    w, b = weather_plan(), bus_plan()
    print(f"날씨: 받을 날짜 {len(w)}일 = 약 {len(w)}번 호출 (하루 한도 {budget()}번)")
    print(f"버스: 받을 날짜 {len(b)}일 = 약 {len(b) * BUS_CALLS_PER_DAY}번 호출 (하루치 약 {BUS_CALLS_PER_DAY}번)")
    for label, days in BUS_PLAN:
        left = [d for lab, d in b if lab == label]
        print(f"  - {label}: {len(days) - len(left)}/{len(days)}일 받음")
    u = load_usage()
    print(f"오늘({u['date']}) 쓴 호출: 날씨 {u.get('weather', 0)}번, 버스 {u.get('bus', 0)}번")


def wait_until_midnight():
    now = datetime.now()
    nxt = datetime.combine(now.date() + timedelta(days=1), datetime.min.time()) + timedelta(minutes=2)
    secs = (nxt - now).total_seconds()
    print(f"\n오늘 한도를 다 썼습니다. {nxt:%m-%d %H:%M}까지 기다렸다가 이어서 받습니다 "
          f"(약 {secs / 3600:.1f}시간). 이 창을 닫지 마세요. 그만두려면 창을 닫으면 됩니다.", flush=True)
    time.sleep(max(60, secs))


def run_once(key: str) -> bool:
    """한 번 돈다. 다 받았으면 True."""
    done_w = done_b = True
    # 1) 날씨 (하루 한 번 호출)
    try:
        todo = weather_plan()
        for i, (label, d) in enumerate(todo, 1):
            j = fp.call("weather", key, {"searchDate": f"{d:%Y%m%d}", "limit": 100})
            fp.save(fp.OUT / "weather" / f"wx_{d:%Y%m%d}.csv", j.get("data") or [])
            if i % 25 == 0 or i == len(todo):
                print(f"날씨 {i}/{len(todo)}일 ({label} 등)", flush=True)
            time.sleep(0.12)
    except BudgetReached:
        done_w = False
        print("날씨: 오늘 한도에 닿아 멈춤", flush=True)
    # 2) 버스 (우선순위 순)
    try:
        for label, d in bus_plan():
            if _usage.get("bus", 0) + BUS_CALLS_PER_DAY > budget():
                raise BudgetReached("bus")      # 하루치를 반만 받고 끊기지 않게 미리 멈춘다
            ymd = d.replace("-", "")
            rows = fp.pages("bus", key, {"startDate": ymd, "endDate": ymd, "moveType": "승차", "payType": "카드"})
            fp.save(fp.OUT / "bus" / f"bus_{ymd}.csv", rows)
            note = "" if rows else " ← 자료 없음 (아직 공개 전이거나 그날 기록이 없음)"
            print(f"버스 {d}: {len(rows)}행 ({label}) · 오늘 버스 호출 {_usage.get('bus', 0)}번{note}", flush=True)
    except BudgetReached:
        done_b = False
        print("버스: 오늘 한도에 닿아 멈춤", flush=True)
    return done_w and done_b


def report():
    cat, _ = F.load()
    print("\n== 축제별 받아 둔 자료 ==")
    for _, r in cat.iterrows():
        c = F.coverage(r)
        tag = "준비 계산 가능" if c["weather_ok"] else "날씨 자료 부족"
        bus = f"버스 축제일 {c['bus_fest']}·평소 {c['bus_base']}일" + (" (비교 가능)" if c["bus_ok"] else "")
        print(f"- {r['year']} {r['name']}: 날씨 {c['weather']} · {bus} → {tag}")


def main():
    fp.load_env()
    global _usage
    _usage = load_usage()
    if "--plan" in sys.argv:
        show_plan()
        report()
        return
    key = os.environ.get("HUB_PROJECT_KEY", "").strip()
    if not key:
        sys.exit("HUB_PROJECT_KEY 가 비어 있습니다. .env 파일에 제주데이터허브 프로젝트 키를 적어 주세요.")
    show_plan()
    try:
        for api, fname in (("observatory", "observatories.csv"), ("station", "bus_stations.csv")):
            if not (fp.OUT / fname).exists():
                fp.save(fp.OUT / fname, fp.pages(api, key, {}))
        while True:
            if run_once(key):
                print("\n목록의 축제 자료를 모두 받았습니다.")
                break
            if "--wait" not in sys.argv:
                print("\n오늘 한도까지 받았습니다. 내일(자정 이후) 같은 파일을 다시 실행하면 이어서 받습니다.")
                break
            wait_until_midnight()
    except fp.QuotaOrKeyError as e:
        print(f"\n멈춤: 허브가 요청을 거절했습니다 ({e}).\n"
              "키가 맞는지, 네 가지 데이터를 프로젝트에 담았는지 확인해 주세요. 한도 문제라면 자정 이후 다시 실행하세요.")
    report()


if __name__ == "__main__":
    main()
