"""축제 준비 Agent에 필요한 제주데이터허브 데이터를 받는다 (이어받기 가능).

받는 데이터 (모두 제주데이터허브 Open API)
  1. 기상관측소 정보          - 관측소 위치(위경도). 행사장에서 가까운 관측소를 고를 때 사용
  2. 버스 정류소 기본 정보     - 정류소 위치(위경도). 행사장 근처 정류소를 고를 때 사용
  3. 일별 기상 정보            - 지난 여러 해 같은 시기의 강수량·풍속 (날씨 위험)
  4. 일일 정류소별 버스 이용자 정보 - 축제일과 평소의 승차 인원 (대중교통 수요)

준비
  - jejudatahub.net 가입 → 마이페이지에서 프로젝트 만들기
  - 위 4개 데이터 화면에서 각각 [프로젝트 담기]
  - 프로젝트 키를 .env 의 HUB_PROJECT_KEY= 뒤에 적기

실행 (jeju_festival_agent 폴더에서)
  .venv\\Scripts\\python.exe scripts\\fetch_prep_data.py            # 들불축제 2025 (기본)
  .venv\\Scripts\\python.exe scripts\\fetch_prep_data.py tamra2025   # 탐라문화제 2025

API는 데이터마다 하루 1,000번까지 부를 수 있다. 다 못 받고 멈추면 다음 날 같은 명령을 다시 실행하면
이미 받은 날짜는 건너뛰고 이어서 받는다. 받은 파일은 data/prep/ 아래에 저장된다.
"""
from __future__ import annotations

import csv
import io
import os
import sys
import time
from datetime import date, timedelta
from pathlib import Path

import requests

BASE = Path(__file__).resolve().parent.parent
OUT = BASE / "data" / "prep"
PROXY = "https://open.jejudatahub.net/api/proxy"
API = {
    "observatory": "t1bab75a555a15715btaa7a5abaa1aab",  # 기상관측소 정보
    "station": "DD11ab6a6t11D16baaa1a2tD26ata161",      # 버스 정류소 기본 정보
    "weather": "1aD5taat1attaa51Db1511b51ab9Da19",      # 일별 기상 정보 (하루씩 요청)
    "bus": "1b1ta1a1ba6t6a1ttt3bD6b1tb1t1D3t",          # 일일 정류소별 버스 이용자 정보
}

# 시연 사례. 날짜는 보도·관광공사 축제정보 기준(data/cases.json과 같음).
CASES = {
    "deulbul2025": {
        "name": "2025 제주들불축제", "festival": ["2025-03-14", "2025-03-15", "2025-03-16"],
        "weeks_around": 2,          # 평소 = 축제 전후 2주의 같은 요일 (호출 한도 때문에 2주)
        "weather_years": range(2014, 2026), "weather_window": ("03-07", "03-23"),
    },
    "tamra2025": {
        "name": "2025 탐라문화제", "festival": ["2025-10-10", "2025-10-11", "2025-10-12", "2025-10-13", "2025-10-14"],
        "weeks_around": 2,
        "weather_years": range(2014, 2026), "weather_window": ("10-03", "10-21"),
    },
}


class QuotaOrKeyError(RuntimeError):
    pass


def load_env():
    env = BASE / ".env"
    if env.exists():
        for line in env.read_text(encoding="utf-8").splitlines():
            if "=" in line and not line.strip().startswith("#"):
                k, v = line.split("=", 1)
                os.environ.setdefault(k.strip(), v.strip())


def call(api: str, key: str, params: dict) -> dict:
    url = f"{PROXY}/{API[api]}/{key}"
    last = ""
    for attempt in range(6):  # 허브가 가끔 시간 초과(500)를 내므로 넉넉히 재시도
        try:
            r = requests.get(url, params=params, timeout=60)
            t = r.text.strip()
            if r.status_code == 200 and t.startswith("{"):
                return r.json()
            last = f"{r.status_code} {t[:150]}"
            if r.status_code in (401, 403, 429) or "quota" in t.lower() or "초과" in t or "인증" in t:
                raise QuotaOrKeyError(last)
        except requests.RequestException as e:
            last = str(e)
        time.sleep(5 * (attempt + 1))
    raise RuntimeError(f"허브 응답 오류: {last}")


def pages(api: str, key: str, params: dict, limit: int = 100):
    """쪽(100행)씩 끝까지 받는다. 허브는 마지막 쪽 다음을 빈 응답으로 주므로 totCnt 로 멈춘다."""
    j = call(api, key, {**params, "limit": limit, "number": 1})
    rows = list(j.get("data") or [])
    total = int(j.get("totCnt") or len(rows))
    n = 1
    while len(rows) < total and j.get("hasMore"):
        n += 1
        time.sleep(0.1)
        j = call(api, key, {**params, "limit": limit, "number": n})
        data = j.get("data") or []
        if not data:
            break
        rows += data
    return rows


def save(path: Path, rows: list[dict]):
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = list(rows[0].keys()) if rows else ["empty"]
    buf = io.StringIO()
    w = csv.DictWriter(buf, fieldnames=fields, extrasaction="ignore")
    w.writeheader()
    w.writerows(rows)
    tmp = path.with_suffix(".part")
    tmp.write_text(buf.getvalue(), encoding="utf-8-sig")
    tmp.replace(path)


def baseline_days(festival: list[str], weeks: int) -> list[str]:
    fest = [date.fromisoformat(d) for d in festival]
    out = []
    for w in range(1, weeks + 1):
        for d in fest:
            for sign in (-1, 1):
                b = d + timedelta(weeks=sign * w)
                if b not in fest:
                    out.append(b.isoformat())
    return sorted(set(out))


def main():
    load_env()
    key = os.environ.get("HUB_PROJECT_KEY", "").strip()
    if not key:
        sys.exit("HUB_PROJECT_KEY 가 비어 있습니다. .env 에 제주데이터허브 프로젝트 키를 적어 주세요.")
    case_id = sys.argv[1] if len(sys.argv) > 1 else "deulbul2025"
    c = CASES[case_id]
    print(f"== {c['name']} 준비 데이터 받기 ==", flush=True)

    try:
        # 1·2. 위치 정보 (한 번만)
        for api, fname in (("observatory", "observatories.csv"), ("station", "bus_stations.csv")):
            p = OUT / fname
            if not p.exists():
                rows = pages(api, key, {})
                save(p, rows)
                print(f"{fname}: {len(rows)}행", flush=True)

        # 3. 날씨: 여러 해 같은 시기 (하루 한 번 호출)
        m0, m1 = c["weather_window"]
        for y in c["weather_years"]:
            d, end = date.fromisoformat(f"{y}-{m0}"), date.fromisoformat(f"{y}-{m1}")
            while d <= end:
                p = OUT / "weather" / f"wx_{d:%Y%m%d}.csv"
                if not p.exists():
                    j = call("weather", key, {"searchDate": f"{d:%Y%m%d}", "limit": 100})
                    save(p, j.get("data") or [])
                    time.sleep(0.12)
                d += timedelta(days=1)
            print(f"날씨 {y}년 {m0}~{m1} 완료", flush=True)
        # 4. 버스: 축제일 + 평소(같은 요일). 승차·카드만 받아 호출 수를 줄인다.
        # 축제일 → 1주 전후 → 2주 전후 순서로 받아, 한도가 차도 판정에 필요한 날짜가 먼저 모이게 한다.
        fest0 = [date.fromisoformat(x) for x in c["festival"]]
        days = list(c["festival"])
        for w in range(1, c["weeks_around"] + 1):
            for sign in (-1, 1):
                days += [(x + timedelta(weeks=sign * w)).isoformat() for x in fest0]
        for d in days:
            p = OUT / "bus" / f"bus_{d.replace('-', '')}.csv"
            if p.exists():
                continue
            ymd = d.replace("-", "")
            rows = pages("bus", key, {"startDate": ymd, "endDate": ymd, "moveType": "승차", "payType": "카드"})
            save(p, rows)
            tag = "축제일" if d in c["festival"] else "평소"
            print(f"버스 {d} ({tag}): {len(rows)}행", flush=True)

    except QuotaOrKeyError as e:
        print(f"\n멈춤: 키가 틀렸거나 오늘 호출 한도를 다 썼습니다 ({e}).\n"
              "키와 [프로젝트 담기]를 확인하고, 한도 문제라면 내일 같은 명령을 다시 실행하면 이어서 받습니다.")
        sys.exit(2)
    print("\n모두 받았습니다. 다음: scripts\\check_prep_data.py 로 결과를 확인하세요.")


if __name__ == "__main__":
    main()
