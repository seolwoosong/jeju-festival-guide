"""설치 스크립트. install.bat 이 실행한다.

이 폴더 안에 .venv 를 만들고 필요한 패키지를 설치한다. PC의 다른 곳은 바꾸지 않는다.
"""
import shutil
import subprocess
import sys
import venv
from pathlib import Path

BASE = Path(__file__).resolve().parent.parent
VENV = BASE / ".venv"
PY = VENV / ("Scripts/python.exe" if sys.platform == "win32" else "bin/python")


def main() -> int:
    if sys.version_info < (3, 10):
        print(f"[!] Python 3.10 이상이 필요합니다. 지금 버전: {sys.version.split()[0]}")
        print("    https://www.python.org/downloads/ 에서 새 버전을 설치한 뒤 다시 실행하세요.")
        return 1
    print("[1/3] 실행 환경(.venv) 만드는 중...")
    if not PY.exists():
        venv.EnvBuilder(with_pip=True).create(VENV)
    print("[2/3] 필요한 프로그램 설치 중... (인터넷 필요, 1~3분)")
    r = subprocess.run([str(PY), "-m", "pip", "install", "--disable-pip-version-check", "-q",
                        "-r", str(BASE / "requirements.txt")])
    if r.returncode != 0:
        print("[!] 설치 중 오류가 났습니다. 인터넷 연결을 확인하고 install.bat 을 다시 실행하세요.")
        return 1
    print("[3/3] 설정 파일 준비 중...")
    if not (BASE / ".env").exists():
        shutil.copy(BASE / ".env.example", BASE / ".env")
    print("\n설치가 끝났습니다. 이제 run.bat 을 더블클릭하세요.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
