"""fetch_prep_data.py 로 받은 데이터로 두 가지를 바로 확인한다.

  1) 버스: 행사장 근처 정류소의 승차 인원이 축제일에 평소(같은 요일)보다 뚜렷하게 늘었나?
     → 늘었으면 '버스 증차 판단' 기능을 넣고, 안 늘었으면 버스는 보조 정보로만 쓴다.
  2) 날씨: 지난 여러 해 같은 시기에 비·강풍 날이 몇 번이었나?

실행: .venv\\Scripts\\python.exe scripts\\check_prep_data.py [deulbul2025|tamra2025]
결과는 화면과 data/prep/check_<사례>.txt 에 저장된다.
"""
from __future__ import annotations

import math
import sys
from pathlib import Path

import pandas as pd

BASE = Path(__file__).resolve().parent.parent
PREP = BASE / "data" / "prep"
sys.path.insert(0, str(Path(__file__).resolve().parent))
from fetch_prep_data import CASES, baseline_days  # noqa: E402

# 행사장 위치(위도, 경도)와 '근처'로 볼 반경(km). 대략값이므로 지도에서 확인 후 고쳐 쓰세요.
SITES = {
    "deulbul2025": {"place": "새별오름", "lat": 33.3655, "lon": 126.3570, "radius_km": 2.0},
    "tamra2025": {"place": "탐라광장", "lat": 33.5150, "lon": 126.5265, "radius_km": 0.7},
}
RAIN_MM = 1.0      # 비 온 날 기준
WIND_MS = 14.0     # 강풍 기준 (육상 강풍주의보의 풍속 기준 14m/s 참고)


def km(lat1, lon1, lat2, lon2):
    r = 6371.0
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp, dl = p2 - p1, math.radians(lon2 - lon1)
    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * r * math.asin(math.sqrt(a))


def read_dir(sub: str) -> pd.DataFrame:
    files = sorted((PREP / sub).glob("*.csv"))
    frames = [pd.read_csv(f, dtype=str) for f in files if f.stat().st_size > 10]
    frames = [f for f in frames if "empty" not in f.columns]
    return pd.concat(frames, ignore_index=True) if frames else pd.DataFrame()


def check_bus(case_id: str, out: list[str]):
    c, s = CASES[case_id], SITES[case_id]
    st = pd.read_csv(PREP / "bus_stations.csv", dtype=str)
    st["lat"], st["lon"] = pd.to_numeric(st["latitude"], errors="coerce"), pd.to_numeric(st["longitude"], errors="coerce")
    st["dist"] = [km(s["lat"], s["lon"], a, b) if pd.notna(a) else 99 for a, b in zip(st["lat"], st["lon"])]
    near = st[st["dist"] <= s["radius_km"]]
    out.append(f"[버스] {s['place']} 반경 {s['radius_km']}km 정류소 {near['stationId'].nunique()}곳: "
               + ", ".join(sorted(near["stationName"].dropna().unique())[:15]))
    bus = read_dir("bus")
    if bus.empty or near.empty:
        out.append("  버스 데이터나 근처 정류소가 없어 판단할 수 없습니다.")
        return
    bus["userCount"] = pd.to_numeric(bus["userCount"], errors="coerce").fillna(0)
    bus["d"] = pd.to_datetime(bus["baseDate"], format="%Y%m%d")
    total = bus.groupby("d")["userCount"].sum()                       # 제주 전체(날마다 흔들림 확인용)
    # 이용 데이터의 정류소ID(7자리)와 정류소 기본 정보의 ID(9자리)는 체계가 달라 이름으로 맞춘다.
    norm = lambda x: str(x).replace(" ", "")
    near_names = set(near["stationName"].map(norm))
    local = bus[bus["stationName"].map(norm).isin(near_names)].groupby("d")["userCount"].sum()
    local = local.reindex(total.index, fill_value=0)
    share = local / total * 1000                                        # 전체 1,000명 중 근처 정류소 승차 수
    fest = [pd.Timestamp(d) for d in c["festival"]]
    base = [pd.Timestamp(d) for d in baseline_days(c["festival"], c["weeks_around"])]
    out.append("  날짜        근처 승차   같은요일 평소   차이     판정")
    hits = 0
    for d in fest:
        same = [b for b in base if b.weekday() == d.weekday() and b in local.index]
        if d not in local.index or len(same) < 2:
            out.append(f"  {d:%m/%d}  데이터 부족")
            continue
        m, sd = local[same].mean(), local[same].std(ddof=1)
        sh_m, sh_sd = share[same].mean(), share[same].std(ddof=1)
        diff = local[d] - m
        clear = (share[d] - sh_m) > 2 * max(sh_sd, 1e-9) and diff > 0
        hits += clear
        out.append(f"  {d:%m/%d}({'월화수목금토일'[d.weekday()]})  {local[d]:8.0f}   {m:10.0f}±{sd:<5.0f}  {diff:+7.0f}   "
                   + ("평소 흔들림을 넘는 증가" if clear else "평소 범위 안"))
    verdict = ("버스 데이터에 축제 효과가 보입니다 → '버스 증차 판단' 기능을 넣어도 됩니다."
               if hits else "버스 데이터에 축제 효과가 뚜렷하지 않습니다 → 버스는 보조 정보로만 쓰는 편이 안전합니다.")
    out.append(f"  결론: {verdict}")
    out.append("  (주의: 하차 기록이 없는 데이터라 '근처에서 버스를 탄 사람'만 셉니다. 현금 승차·셔틀·자가용은 빠집니다.)")


def check_weather(case_id: str, out: list[str]):
    c, s = CASES[case_id], SITES[case_id]
    ob = pd.read_csv(PREP / "observatories.csv", dtype=str)
    ob["dist"] = [km(s["lat"], s["lon"], float(a), float(b)) if pd.notna(a) and pd.notna(b) else 99
                  for a, b in zip(ob["latitude"], ob["longitude"])]
    wx = read_dir("weather")
    if wx.empty:
        out.append("[날씨] 받은 날씨 데이터가 없습니다.")
        return
    have = set(wx["observatoryName"])
    ob = ob[ob["observatoryName"].isin(have)].sort_values("dist")
    name, dist = ob.iloc[0]["observatoryName"], ob.iloc[0]["dist"]
    w = wx[wx["observatoryName"] == name].copy()
    w["d"] = pd.to_datetime(w["baseDate"], format="%Y%m%d")
    w["rain"] = pd.to_numeric(w["dailyRainfall"], errors="coerce")
    w["wind"] = pd.to_numeric(w["maximumWindSpeed"], errors="coerce")
    out.append(f"[날씨] 가장 가까운 관측소: {name} ({dist:.1f}km). 기간 {c['weather_window'][0]}~{c['weather_window'][1]}")
    out.append("  연도  관측일  비(≥1mm)  강풍(≥14m/s)  최대풍속")
    tot_days = tot_rain = tot_wind = 0
    for y, g in w.groupby(w["d"].dt.year):
        n, r, k = g["rain"].notna().sum(), (g["rain"] >= RAIN_MM).sum(), (g["wind"] >= WIND_MS).sum()
        tot_days, tot_rain, tot_wind = tot_days + n, tot_rain + r, tot_wind + k
        out.append(f"  {y}  {n:5d}  {r:7d}  {k:10d}  {g['wind'].max():8.1f}")
    if tot_days:
        out.append(f"  합계: {tot_days}일 중 비 {tot_rain}일({tot_rain / tot_days:.0%}), 강풍 {tot_wind}일({tot_wind / tot_days:.0%})")


def main():
    case_id = sys.argv[1] if len(sys.argv) > 1 else "deulbul2025"
    out = [f"== {CASES[case_id]['name']} 데이터 확인 =="]
    for f in (check_bus, check_weather):
        try:
            f(case_id, out)
        except FileNotFoundError as e:
            out.append(f"  파일이 없습니다: {e.filename} (fetch_prep_data.py 를 먼저 실행하세요)")
        out.append("")
    text = "\n".join(out)
    print(text)
    (PREP / f"check_{case_id}.txt").write_text(text, encoding="utf-8")


if __name__ == "__main__":
    main()
