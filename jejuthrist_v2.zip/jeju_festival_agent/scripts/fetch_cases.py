"""data/cases.json 의 실제 사례 데이터를 제주데이터허브 Open API 에서 다시 받는다.

제출물에 들어 있는 data/hub/*.csv 가 어디서 어떻게 왔는지 재현하는 스크립트다.
실행: (.env 에 HUB_PROJECT_KEY 를 적은 뒤) .venv\\Scripts\\python.exe scripts\\fetch_cases.py
"""
import json
import os
import sys
from pathlib import Path

import pandas as pd

BASE = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BASE))
env = BASE / ".env"
if env.exists():
    for line in env.read_text(encoding="utf-8").splitlines():
        if "=" in line and not line.strip().startswith("#"):
            k, v = line.split("=", 1)
            os.environ.setdefault(k.strip(), v.strip())

from agent import hub  # noqa: E402
from agent.tools import Spec  # noqa: E402

cases = json.loads((BASE / "data" / "cases.json").read_text(encoding="utf-8"))
for c in cases:
    spec = Spec(name=c["name"], emd=c["emd"], start=pd.Timestamp(c["start"]), end=pd.Timestamp(c["end"]))
    lo, hi = spec.window
    year = lo.year
    for emd in [c["emd"], c["control"]]:
        rows = hub.fetch_pop(emd, lo, hi, hub.project_key())
        p = hub.HUB_DIR / f"pop_{year}_{emd}_{lo:%Y%m%d}_{hi:%Y%m%d}.csv"
        hub.HUB_DIR.mkdir(parents=True, exist_ok=True)
        p.write_bytes(hub.to_csv(sorted(rows, key=lambda r: (r["baseDate"], r["gender"], r["ageGroup"])), hub.POP_FIELDS))
        print(p.name, len(rows), "행", flush=True)
    wx = hub.fetch_weather(lo, hi, hub.project_key())
    if wx:
        p = hub.HUB_DIR / f"weather_{lo:%Y%m%d}_{hi:%Y%m%d}.csv"
        p.write_bytes(hub.to_csv(sorted(wx, key=lambda r: (r["baseDate"], r["observatoryName"])), hub.WX_FIELDS))
        print(p.name, len(wx), "행", flush=True)
    else:
        print(f"{c['name']}: 허브 일별 기상 정보에 이 기간 자료가 없습니다(허브 제공 기간 밖).", flush=True)
