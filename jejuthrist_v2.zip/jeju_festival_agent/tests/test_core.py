"""핵심 동작 검증. 실행: python -m pytest tests -q  (먼저 python sample_data/make_sample.py)"""
import io
import os
import sys
from pathlib import Path

import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
os.environ.pop("LLM_API_KEY", None)

from agent import core, guard, report, tools  # noqa: E402
from agent.datasets import DatasetError, load_csv  # noqa: E402

S = ROOT / "sample_data"
FEST = {"name": "가을빛 축제", "emd": "삼도2동", "start": "2026-10-09", "end": "2026-10-13", "stations": "탑동, 중앙로"}


@pytest.fixture(scope="module")
def data():
    out = {}
    for f in ["sample_floating_pop.csv", "sample_station_usage.csv", "sample_weather_daily.csv"]:
        d = load_csv((S / f).read_bytes(), f)
        out[d.role] = d
    return out


def facts(ans, tool):
    return next(x["result"] for x in ans["results"] if x["result"].tool == tool).facts


def test_detect(data):
    assert set(data) == {"pop", "bus", "weather"}
    assert data["pop"].hourly


def test_rejects_personal_masked_unknown():
    with pytest.raises(DatasetError):  # 개인 단위 기록
        load_csv("base_date,user_id,route_id\n20261101,abc,1\n".encode(), "x.csv")
    with pytest.raises(DatasetError):  # 대회 예시 파일처럼 값이 가려진 경우
        load_csv(("base_date,time,emd_nm,sex,age,resd_pop_cnt,work_pop_cnt,visit_pop_cnt,resd\n"
                  "20260705,0,제주시 한림읍,여성,1014,***,***,***,제주\n").encode(), "y.csv")
    with pytest.raises(DatasetError):
        load_csv("a,b\n1,2\n".encode(), "z.csv")


def test_recovers_planted_effect(data):
    """가상 데이터에 심은 효과(11~21시 1.5배, 비 온 날 1.25배)를 되찾는다."""
    f = facts(core.verify(FEST, data), "visit_effect")
    assert 30 < f["증가율(%)"] < 50 and f["판정"] == "평소 변동을 넘는 증가" and f["비 온 날(1mm 이상)"] == "10/11(일)"
    assert f["평소를 넘게 늘어난 날"].count("(") == 5


def test_matches_hand_calculation(data):
    """도구의 '축제 기간 평균'이 원본 CSV를 직접 계산한 값과 같다."""
    raw = pd.read_csv(S / "sample_floating_pop.csv")
    r = raw[raw.emd_nm.str.contains("삼도2동") & raw.time.between(9, 22) & raw.base_date.between(20261009, 20261013)]
    expect = r.groupby(["base_date", "time"]).visit_pop_cnt.sum().groupby(level=0).mean().mean()
    assert facts(core.verify(FEST, data), "visit_effect")["축제 기간 평균"] == round(expect)


def test_control_area_shows_no_effect(data):
    """효과를 넣지 않은 읍면동은 '평소 변동 범위 안'으로 나온다 (없는 효과를 만들어 내지 않는다)."""
    f = facts(core.verify({**FEST, "emd": "한림읍", "stations": ""}, data), "visit_effect")
    assert abs(f["증가율(%)"]) < 8 and f["판정"] == "평소 변동 범위 안"


def test_hour_mix_bus(data):
    ans = core.verify(FEST, data)
    assert 11 <= int(facts(ans, "hourly_profile")["가장 많이 늘어난 시간대"][:2]) <= 21
    assert facts(ans, "visitor_mix")["가장 많이 늘어난 집단"] == "거주지 그외"
    assert 20 < facts(ans, "bus_effect")["증가율(%)"] < 40


def test_sentence_parsing_rule_mode(data):
    ans = core.verify({"text": "2026년 가을빛 축제, 10월 9일부터 13일까지 삼도2동에서 열렸어. 정류소는 탑동, 중앙로"}, data)
    sp = ans["spec"]
    assert (sp.emd, f"{sp.start:%m-%d}", f"{sp.end:%m-%d}", sp.stations) == ("삼도2동", "10-09", "10-13", ["탑동", "중앙로"])
    assert "외부 전송 없음" in ans["mode"]


def test_helpful_errors(data):
    with pytest.raises(core.SpecError):
        core.verify({"text": "축제 성과 알려줘"}, data)
    ans = core.verify({**FEST, "start": "2025-03-01", "end": "2025-03-02"}, data)  # 파일에 없는 기간
    assert not ans["results"] and any("축제 기간" in e for e in ans["errors"])


def test_guard_and_report(data):
    t = pd.DataFrame({"항목": ["a", "b"], "값": [5.0, 50.0]})
    g, n = guard.apply(t, "값", ["값"], 10)
    assert n == 1 and g["값"].tolist() == [guard.MASK, 50.0]
    ans = core.verify(FEST, data)
    html_ = report.report_html([ans], [{"name": d.name, "filename": d.filename, "rows": len(d.df), "period": d.period}
                                       for d in data.values()])
    assert "data:image/png;base64" in html_ and "반출 기준 점검 요약" in html_ and "총평" in html_


def test_llm_gets_sentence_and_summary_only(data, monkeypatch):
    sent = []

    def fake(cfg, system, user, kind):
        sent.append((kind, user))
        if kind == "extract":
            return '{"name":"가을빛 축제","emd":"삼도2동","start":"2026-10-09","end":"2026-10-13","stations":["탑동"]}'
        return "총평입니다."
    monkeypatch.setattr(core, "_chat", fake)
    monkeypatch.setenv("LLM_API_KEY", "k"); monkeypatch.setenv("LLM_MODEL", "m")
    ans = core.verify({"text": "가을빛 축제 삼도2동 10월 9일~13일"}, data)
    assert [k for k, _ in sent] == ["extract", "summary"] and "AI 모드" in ans["mode"] and "총평입니다." in ans["spec_html"]
    summary_payload = sent[1][1]
    assert "visit_pop_cnt" not in summary_payload and len(summary_payload) < 1500  # 요약 숫자만 나간다


def test_control_compare(data):
    ans = core.verify({**FEST, "control": "한림읍"}, data)
    f = facts(ans, "control_compare")
    assert 30 < f["평균 순증가(%p)"] < 50  # 대조 지역(효과 없음)을 빼도 효과가 남는다


def test_holidays_excluded_from_baseline(data):
    from agent.holidays import holidays
    assert pd.Timestamp("2026-10-05") in holidays() and pd.Timestamp("2025-03-03") in holidays()


@pytest.mark.skip(reason="웹 흐름은 test_web_flow_real 에서 실제 사례로 확인")
def test_web_flow():
    import app as A
    c = A.app.test_client()
    rx = c.post("/prescribe", json={"text": "가을빛 축제, 2026년 10월 9일부터 13일까지 삼도2동"}).get_json()["html"]
    assert "2026-09" in rx and "2026-11" in rx and "삼도2동" in rx
    files = [(io.BytesIO((S / f).read_bytes()), f) for f in ["sample_floating_pop.csv", "sample_station_usage.csv",
                                                             "sample_weather_daily.csv"]]
    up = c.post("/upload", data={"files": files}, content_type="multipart/form-data").get_json()
    assert all(m["ok"] for m in up["messages"]) and any("삼도2동" in e for e in up["emds"])
    assert "평소 변동을 넘는 증가" in c.post("/verify", json=FEST).get_json()["html"]
    assert c.get("/report").status_code == 200


# ---------- 실제 사례(제주데이터허브 원자료) ----------
import pathlib as _pl
_HUB = _pl.Path(__file__).resolve().parents[1] / "data" / "hub"


@pytest.mark.skipif(not any(_HUB.glob("pop_2026_*.csv")), reason="실제 사례 데이터 없음")
def test_real_case_deulbul2026():
    import app as _app
    j = _app.app.test_client().post("/case/deulbul2026").get_json()
    assert "대조 지역보다 뚜렷한 증가" in j["html"]
    assert "축제 효과로 볼 만한 날은 3/14(토)" in j["html"]


@pytest.mark.skipif(not any(_HUB.glob("pop_2025_*.csv")), reason="실제 사례 데이터 없음")
def test_real_case_deulbul2025_cancelled_days_flat():
    import app as _app
    j = _app.app.test_client().post("/case/deulbul2025").get_json()
    # 첫날(3/14)만 뚜렷하고, 강풍으로 취소된 3/15~16은 뚜렷하지 않아야 한다
    assert "축제 효과로 볼 만한 날은 3/14(금)" in j["html"]
    assert "강풍 날 3/15(토), 3/16(일)" in j["html"]
