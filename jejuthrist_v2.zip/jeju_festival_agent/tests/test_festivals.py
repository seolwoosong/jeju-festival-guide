"""축제 찾기(agent/festivals.py)와 일괄 수집 스크립트(scripts/fetch_festivals.py) 검증.

- 이름이 틀려도 정식 이름을 제안하되 단정하지 않는지
- 목록에 없는 해를 "열리지 않았다"고 말하지 않는지
- 목록의 모든 회차가 출처 링크·날짜·실제 정류소 이름을 갖는지
- 수집 스크립트가 하루 한도를 넘기지 않고 멈추는지 (가짜 허브로 시험)
"""
import sys
from pathlib import Path

import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "scripts"))

from agent import festivals as F  # noqa: E402
from agent import prep  # noqa: E402


def test_typo_suggests_official_name():
    r = F.search("들블축제")
    assert r["found"] and r["how"].startswith("비슷한")
    assert r["names"] == ["제주들불축제"]
    assert "정식 이름이 아닙니다" in r["verdict"]


def test_year_and_cancel_status():
    r = F.search("2024 성산일출축제")
    assert "2024-12-31 ~ 2025-01-01" in r["verdict"] and "취소" in r["verdict"]
    r = F.search("2025 들불축제")
    assert "2025-03-14 ~ 2025-03-16" in r["verdict"] and "강풍" in r["verdict"]
    r = F.search("25년 제18회 제주 해녀 축제")
    assert "2025-09-20 ~ 2025-09-21" in r["verdict"]


def test_unlisted_year_is_not_called_cancelled():
    r = F.search("2019 탐라문화제")
    assert "확인할 수 없습니다" in r["verdict"] and "열리지 않았다는 뜻은 아님" in r["verdict"]


def test_unknown_name():
    r = F.search("화성 우주축제")
    assert not r["found"] and "연도도 판단하지 않습니다" in r["verdict"]


def test_catalog_rows_are_sourced_and_placeable():
    cat, _ = F.load()
    st = pd.read_csv(ROOT / "data" / "prep" / "bus_stations.csv", dtype=str, encoding="utf-8-sig")
    stations = set(st["stationName"])
    assert len(cat) >= 10 and cat["id"].is_unique
    for _, r in cat.iterrows():
        assert r["source_url"].startswith("http"), r["id"]
        assert r["start"] <= r["end"] and r["start"].year == r["year"], r["id"]
        assert r["place"] in stations, f"{r['id']}: 정류소 '{r['place']}' 없음"


def test_prep_form_wraps_new_year():
    f = F.prep_form(F.get("sunrise2023"))
    assert f["wx_from"] == "12-23" and f["wx_to"] == "01-08"
    assert f["ref_start"] == "2023-12-30" and f["ref_end"] == "2024-01-01"


def test_weather_risk_handles_new_year_window(tmp_path):
    d = tmp_path / "prep"
    (d / "weather").mkdir(parents=True)
    pd.DataFrame([{"stationName": "해돋이", "latitude": 33.46, "longitude": 126.93}]).to_csv(
        d / "bus_stations.csv", index=False, encoding="utf-8-sig")
    pd.DataFrame([{"observatoryName": "성산", "latitude": 33.46, "longitude": 126.93}]).to_csv(
        d / "observatories.csv", index=False, encoding="utf-8-sig")
    # 두 철(2022-23, 2023-24) × 12/31, 1/1. 1/1은 두 철 모두 강풍.
    for ymd in ("20221231", "20230101", "20231231", "20240101"):
        wind = 20 if ymd.endswith("0101") else 3
        pd.DataFrame([{"baseDate": ymd, "observatoryName": "성산", "dailyRainfall": 0, "maximumWindSpeed": wind}]).to_csv(
            d / "weather" / f"wx_{ymd}.csv", index=False, encoding="utf-8-sig")
    prep._read_dir.cache_clear()
    s = prep.PrepSpec(name="t", place="해돋이", wx_from="12-30", wx_to="01-02")
    r = prep.weather_risk(s, {"min_count": 10}, d)
    assert list(r.table["날짜"]) == ["12/31", "01/01"]          # 해를 넘겨도 12월 → 1월 순서
    assert r.facts["기록 연수"] == 2 and r.facts["강풍 날 비율(%)"] == 50
    prep._read_dir.cache_clear()


def test_fetch_script_stops_at_daily_budget(tmp_path, monkeypatch):
    import fetch_festivals as FF
    import fetch_prep_data as fp
    monkeypatch.setattr(fp, "OUT", tmp_path)
    monkeypatch.setattr(FF, "USAGE", tmp_path / "_usage.json")
    monkeypatch.setattr(F, "PREP_DIR", tmp_path)
    monkeypatch.setenv("HUB_DAILY_BUDGET", "75")
    calls = []

    def fake(api, key, params):
        calls.append(api)
        if api == "weather":
            return {"data": [{"baseDate": params["searchDate"], "observatoryName": "x"}]}
        n = params.get("number", 1)                  # 버스: 하루 650행 = 7쪽
        return {"data": [{"baseDate": params["startDate"], "stationName": "s", "userCount": 1}] * 100 if n <= 6 else
                [{"baseDate": params["startDate"], "stationName": "s", "userCount": 1}] * 50,
                "totCnt": 650, "hasMore": n < 7}

    monkeypatch.setattr(FF, "_real_call", fake)
    FF._usage = {"date": FF._today()}
    done = FF.run_once("k")
    assert not done
    assert calls.count("weather") == 75                     # 날씨는 한도에서 정확히 멈춤
    assert calls.count("bus") == 7                          # 버스는 하루치(약 70번)를 다 받을 수 없으면 시작 전에 멈춤
    assert FF.load_usage()["weather"] == 75                 # 같은 날 다시 실행해도 이어서 센다
    assert len(list((tmp_path / "bus").glob("bus_*.csv"))) == 1


def test_web_festival_search_and_prep():
    prep._read_dir.cache_clear()
    import app as webapp
    c = webapp.app.test_client()
    h = c.get("/festivals?q=들블축제").get_json()["html"]
    assert "제주들불축제" in h and "정식 이름이 아닙니다" in h
    h = c.get("/festivals?q=").get_json()["html"]
    assert h.count("<tr>") == len(F.load()[0]) + 1
    h = c.post("/festival_prep/deulbul2025", json={"audience": "bus"}).get_json()["html"]
    assert "계산에 쓴 회차: 2025년 제주들불축제" in h and "하루 약 3대분" in h


def test_live_fetch_gets_only_missing_days(tmp_path, monkeypatch):
    from agent import live
    import fetch_festivals as FF
    import fetch_prep_data as fp
    monkeypatch.setattr(fp, "OUT", tmp_path)
    monkeypatch.setattr(FF, "USAGE", tmp_path / "_usage.json")
    monkeypatch.setattr(F, "PREP_DIR", tmp_path)
    monkeypatch.setattr(live, "hub_key", lambda: "k")
    calls = []

    def fake(api, key, params):
        calls.append(api)
        if api == "weather":
            return {"data": [{"baseDate": params["searchDate"], "observatoryName": "x"}]}
        return {"data": [{"baseDate": params["startDate"], "stationName": "s", "userCount": 1}], "totCnt": 1, "hasMore": False}

    monkeypatch.setattr(FF, "_real_call", fake)
    row = F.get("tamra2025")
    need = len(set(F.weather_days(row)))
    assert live.fetch_weather(row) == need and calls.count("weather") == need
    assert F.coverage(row)["weather_ok"]
    assert live.fetch_weather(row) == 0                      # 두 번째는 받지 않음 (저장된 자료 사용)
    assert live.fetch_bus(row) == 9                         # 축제 처음 3일 + 1주 전·후 같은 요일
    assert not live.bus_todo(row)


def test_live_without_key_explains(monkeypatch):
    from agent import live
    monkeypatch.setattr(live, "hub_key", lambda: "")
    with pytest.raises(live.LiveError, match="HUB_PROJECT_KEY"):
        live.fetch_weather(F.get("tamra2025"))


def test_guide_api_two_audiences():
    import app as webapp
    c = webapp.app.test_client()
    assert "제주 축제 길잡이" in c.get("/").get_data(as_text=True)
    j = c.get("/api/guide?q=들블축제").get_json()
    assert j["found"] and j["name"] == "제주들불축제" and j["short"] == "3.14–16" and j["partial"] and not j["cancelled"]
    assert j["weather"]["wind_pct"] == 40 and j["bus"]["max_extra"] == 118 and j["bus"]["buses"] == 3
    assert j["crowd"]["best"]["net"] == 13.8                      # 대조 지역(한림읍) 대비 순증가
    assert j["advice"]["prep"] and j["advice"]["fun"] and j["advice"]["prep"] != j["advice"]["fun"]
    assert "3/10–12" in " ".join(j["advice"]["prep"])
    assert c.get("/api/guide?q=축제").get_json()["choices"]          # 여러 개면 고르게 한다


def test_settings_key_and_add_festival(tmp_path, monkeypatch):
    import shutil
    from agent import settings as S
    env = tmp_path / ".env"
    env.write_text("# 설정\nHUB_PROJECT_KEY=\nBUS_SEATS=40\n", encoding="utf-8")
    monkeypatch.setattr(S, "ENV", env)
    S.save_key("abcDEF123456")
    assert "HUB_PROJECT_KEY=abcDEF123456" in env.read_text(encoding="utf-8") and "BUS_SEATS=40" in env.read_text(encoding="utf-8")
    with pytest.raises(ValueError):
        S.save_key("짧음")
    cat = tmp_path / "festivals.csv"
    shutil.copy(F.CATALOG, cat)
    monkeypatch.setattr(F, "CATALOG", cat)
    with pytest.raises(ValueError, match="출처"):
        S.add_festival({"name": "새 축제", "start": "2026-05-01", "place": "새별오름"})
    with pytest.raises(ValueError, match="정류소"):
        S.add_festival({"name": "새 축제", "start": "2026-05-01", "place": "없는정류소", "source_url": "https://x.kr"})
    row = S.add_festival({"name": "제주 시험 마라톤", "start": "2026-05-01", "end": "2026-05-01", "place": "새별오름",
                          "source_url": "https://example.kr/news"})
    assert row["emd"] == "애월읍"
    r = F.search("시험 마라톤")
    assert r["found"] and r["names"] == ["제주 시험 마라톤"] and "2026" in r["verdict"]


def test_persona_pages_and_extra():
    import app as webapp
    c = webapp.app.test_client()
    assert "전용" not in c.get("/for/prep?id=deulbul2025").get_data(as_text=True)[:200]
    assert c.get("/for/fun?id=deulbul2025").status_code == 200
    x = c.get("/api/extra?id=canola2025").get_json()
    assert any(o["name"] == "전농로 왕벚꽃축제" and o["same_days"] for o in x["overlaps"])
    assert x["stops"][0]["name"] == "가시리사무소"


def test_catalog_cards_one_per_festival():
    import app
    c = app.app.test_client()
    cards = c.get("/api/catalog").get_json()
    names = [x["name"] for x in cards]
    assert len(names) == len(set(names)) and len(cards) >= 10
    assert [x["month"] for x in cards] == sorted(x["month"] for x in cards)
    deul = next(x for x in cards if x["name"] == "제주들불축제")
    assert deul["editions"] == 2 and deul["ready"] and deul["id"] == "deulbul2025"   # 키 없이 바로 볼 수 있는 회차로 연다


def test_scene_art_and_optional_photo():
    import app
    c = app.app.test_client()
    for n in ("hero", "fun", "prep"):
        r = c.get(f"/art/{n}.svg")
        assert r.status_code == 200 and r.mimetype == "image/svg+xml" and b"<svg" in r.data
    assert c.get("/art/..%2Fapp.svg").status_code == 404
    assert c.get("/photo/other").status_code == 404


def test_photos_have_credits():
    """넣어 둔 사진은 출처·이용 허락이 반드시 함께 있어야 한다."""
    import app
    p = app.app.test_client().get("/api/photos").get_json()
    for name, x in p.items():
        if x["have"] and name != "prep":
            assert x.get("author") and x.get("license") and x.get("source", "").startswith("https://")
