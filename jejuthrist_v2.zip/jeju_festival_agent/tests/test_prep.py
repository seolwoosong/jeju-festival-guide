"""축제 준비 도구(agent/prep.py) 검증. 실행: python -m pytest tests -q

가짜 자료를 임시 폴더에 만들어, 정답을 아는 상황에서 도구가 맞게 세는지 확인한다.
실제 허브 자료(data/prep)가 있으면 2025 들불축제 사례도 확인한다.
"""
import sys
from pathlib import Path

import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from agent import prep  # noqa: E402
from agent.tools import ToolError  # noqa: E402

CFG = {"min_count": 10}


def _write(path: Path, rows: list[dict]):
    path.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).to_csv(path, index=False, encoding="utf-8-sig")


@pytest.fixture()
def fake(tmp_path):
    d = tmp_path / "prep"
    # 정류소 위치: 행사장(A오름)과 근처 1곳, 먼 곳 1곳. ID는 이용 자료와 다르게(9자리) 둔다.
    _write(d / "bus_stations.csv", [
        {"stationId": "405000001", "stationName": "A오름", "latitude": 33.36, "longitude": 126.35},
        {"stationId": "405000002", "stationName": "B마을", "latitude": 33.365, "longitude": 126.355},
        {"stationId": "405000003", "stationName": "먼정류소", "latitude": 33.50, "longitude": 126.53}])
    _write(d / "observatories.csv", [
        {"observatoryName": "가까운관측소", "latitude": 33.361, "longitude": 126.351},
        {"observatoryName": "먼관측소", "latitude": 33.5, "longitude": 126.5}])
    # 날씨 3년 × 03-10~03-12. 가까운 관측소: 03-11은 매년 강풍, 03-12는 2년 비.
    for y in (2022, 2023, 2024):
        for day in (10, 11, 12):
            date = f"{y}03{day:02d}"
            near = {"wind": 20.0 if day == 11 else 5.0, "rain": 5.0 if (day == 12 and y < 2024) else 0.0}
            _write(d / "weather" / f"wx_{date}.csv", [
                {"baseDate": date, "observatoryName": "가까운관측소", "dailyRainfall": near["rain"], "maximumWindSpeed": near["wind"]},
                {"baseDate": date, "observatoryName": "먼관측소", "dailyRainfall": 50, "maximumWindSpeed": 30}])
    # 버스: 축제일 2025-03-14(금)만 근처 승차 +100. 이용 자료 ID는 7자리.
    for day in ["2025-02-28", "2025-03-07", "2025-03-14", "2025-03-21", "2025-03-28"]:
        ymd = day.replace("-", "")
        boost = 100 if day == "2025-03-14" else 0
        _write(d / "bus" / f"bus_{ymd}.csv", [
            {"baseDate": ymd, "stationId": "0000001", "stationName": "A오름", "userCount": 20 + boost + (day[-1] == "8")},
            {"baseDate": ymd, "stationId": "0000002", "stationName": "B마을", "userCount": 15},
            {"baseDate": ymd, "stationId": "0000003", "stationName": "먼정류소", "userCount": 5000}])
    prep._read_dir.cache_clear()
    return d


def spec(**kw):
    base = dict(name="시험 축제", place="A오름", wx_from="03-10", wx_to="03-12",
                ref_start=pd.Timestamp("2025-03-14"), ref_end=pd.Timestamp("2025-03-14"))
    base.update(kw)
    return prep.PrepSpec(**base)


def test_weather_counts_nearest_station(fake):
    r = prep.weather_risk(spec(), CFG, fake)
    f = r.facts
    assert f["관측소"] == "가까운관측소"                 # 먼 관측소(늘 폭풍)를 고르지 않는다
    assert f["강풍 날 비율(%)"] == round(3 / 9 * 100)    # 9일 중 03-11 세 번
    assert f["비 온 날 비율(%)"] == round(2 / 9 * 100)
    assert "03/10" in f["비·강풍이 가장 적었던 날"].split(", ")[0]
    assert r.table.set_index("날짜").loc["03/11", "강풍 해"] == 3


def test_weather_missing_window(fake):
    with pytest.raises(ToolError):
        prep.weather_risk(spec(wx_from="10-01", wx_to="10-05"), CFG, fake)


def test_bus_detects_planted_increase_by_name(fake):
    r = prep.bus_demand(spec(), CFG, fake)
    row = r.table.iloc[0]
    assert row["축제일 승차"] == 135 and row["평소(같은 요일 평균)"] == 36   # (36+35+35+36)/4=35.5
    assert row["늘어난 인원"] == 100 and row["판정"].startswith("평소보다 뚜렷이")
    assert r.facts["하루 최대 추가 승차(명)"] == 100
    assert "먼정류소" not in r.facts["근처 정류소"]


def test_bus_no_effect_says_so(fake):
    r = prep.bus_demand(spec(ref_start=pd.Timestamp("2025-03-21"), ref_end=pd.Timestamp("2025-03-21")), CFG, fake)
    assert r.table.iloc[0]["판정"] == "평소 범위"
    assert "뚜렷한 차이가 없었습니다" in prep.sentence(r)


def test_bus_missing_period_is_error(fake):
    with pytest.raises(ToolError):
        prep.bus_demand(spec(ref_start=pd.Timestamp("2025-10-10"), ref_end=pd.Timestamp("2025-10-12")), CFG, fake)


def test_unknown_place(fake):
    with pytest.raises(ToolError):
        prep.weather_risk(spec(place="없는장소"), CFG, fake)


REAL = ROOT / "data" / "prep"


@pytest.mark.skipif(not (REAL / "weather").exists(), reason="실제 허브 준비 자료 없음")
def test_real_deulbul_2025():
    prep._read_dir.cache_clear()
    s = spec(place="새별오름", wx_from="03-07", wx_to="03-23",
             ref_start=pd.Timestamp("2025-03-14"), ref_end=pd.Timestamp("2025-03-16"))
    w = prep.weather_risk(s, CFG)
    assert w.facts["관측소"] == "새별오름"
    assert "3/15(토) 비 14.0mm·바람 24.8m/s" in w.facts["지난 축제 기간 실제 날씨"]   # 보도된 강풍 취소일
    b = prep.bus_demand(s, CFG)
    assert b.table.iloc[0]["판정"].startswith("평소보다 뚜렷이")                      # 개막일 승차 증가


# ---------- 대상별 준비 제안 ("누가 쓰나요?") ----------
import re  # noqa: E402


def _results(fake, **kw):
    s = spec(**kw)
    return [prep.weather_risk(s, CFG, fake), prep.bus_demand(s, CFG, fake)]


def _numbers(text: str) -> set[str]:
    # 날짜(03/10, 3/14) 속 숫자도 함께 뽑는다
    return set(re.findall(r"\d+(?:\.\d+)?", text))


def test_every_audience_gets_text_and_numbers_come_from_results(fake):
    res = _results(fake)
    wf, bf = res[0].facts, res[1].facts
    allowed = _numbers(" ".join(str(v) for r in res for v in r.facts.values()))
    allowed |= {f"{prep.WIND_MS:.0f}", f"{prep.RAIN_MM:.0f}", str(prep.BUS_SEATS), "10", "1", "2",
                str(round(wf["강풍 날 비율(%)"] / 10)), str(round(wf["비 온 날 비율(%)"] / 10)),
                prep._x(bf["평소 대비 배율"])}
    texts = {k: prep.advice(res, k) for k in prep.AUDIENCES}
    assert len(set(texts.values())) == len(texts)               # 대상마다 말이 다르다
    for k, t in texts.items():
        assert t and t != "판단에 쓸 결과가 없습니다.", k
        extra = _numbers(t) - allowed
        assert not extra, f"{k}: 결과에 없는 숫자 {extra}"      # 숫자를 지어내지 않는다


def test_audience_wording(fake):
    res = _results(fake)
    assert "10번 중 약 3번" in prep.advice(res, "visitor")       # 강풍 3/9일 = 33%
    assert "귀가" in prep.advice(res, "visitor")
    bus = prep.advice(res, "bus")
    assert bus.startswith("지난 같은 축제 때") and "하루 약 3대분" in bus   # 100명 / 40명
    assert "평소의 약" in prep.advice(res, "merchant")
    assert "가장 센 바람은 20.0m/s" in prep.advice(res, "safety")
    assert prep.advice(res, "없는대상") == prep.advice(res, "organizer")


def test_outdoor_needs_only_place_and_dates(fake):
    w = prep.weather_risk(spec(ref_start=None, ref_end=None), CFG, fake)
    t = prep.advice([w], "outdoor")
    assert "03/10" in t and "예비일" in t
    assert prep.advice([w], "bus").startswith("버스 수요는 비교할 지난 축제 기간을")
    assert not prep.advice([w], "merchant").startswith("다만")


@pytest.mark.skipif(not (REAL / "weather").exists(), reason="실제 허브 준비 자료 없음")
def test_web_audience_choice():
    prep._read_dir.cache_clear()
    import app as webapp
    c = webapp.app.test_client()
    assert c.get("/detail").get_data(as_text=True).count('name="aud"') == len(prep.AUDIENCES)
    h = c.post("/prep_case/deulbul2026", json={"audience": "bus"}).get_json()["html"]
    assert "버스 운영(대중교통 부서·운수사)용 정리" in h and "하루 약 3대분" in h
    h = c.post("/prep", json={"place": "새별오름", "wx_from": "03-07", "wx_to": "03-23", "audience": "outdoor"}).get_json()["html"]
    assert "지난 축제 기간(시작일·종료일)" not in h and "03/10" in h      # 야외 행사는 날짜만으로 충분
