"""반출 기준 점검.

집계표에서 바탕이 되는 이용자 수가 기준(기본 10) 미만인 칸을 가린다.
가려진 값은 화면, 보고서, 외부 AI 전송 어디에도 나가지 않는다.
기준값은 설정(EXPORT_MIN_COUNT)으로 바꿀 수 있다. 실제 반출 가능 여부의 최종 판단은
제주빅데이터센터의 반출 심의를 따른다.
"""
from __future__ import annotations

import pandas as pd

MASK = "기준 미만"


def apply(table: pd.DataFrame, base_col: str, value_cols: list[str], min_count: int):
    """base_col(바탕 인원 수)이 min_count 미만인 행의 value_cols 를 가린다.

    반환: (가린 표, 가린 행 수)
    """
    t = table.copy()
    low = t[base_col] < min_count
    n = int(low.sum())
    if n:
        for c in value_cols:
            t[c] = t[c].astype(object)
            t.loc[low, c] = MASK
    return t, n


def safe_records(table: pd.DataFrame, limit: int = 40) -> list[dict]:
    """외부 AI에 보낼 수 있는 형태로 바꾼다: 가려진 값은 그대로 '기준 미만'으로 나간다."""
    out = []
    for rec in table.head(limit).to_dict(orient="records"):
        out.append({k: (round(v, 2) if isinstance(v, float) else (v.item() if hasattr(v, "item") else v))
                    for k, v in rec.items()})
    return out
