"""화면에서 바꾸는 설정: 허브 키 저장·찾기, 축제 추가, VISIT JEJU 파일 올리기."""
from __future__ import annotations

import csv
import io
import os
import re
import time
from pathlib import Path
from urllib.parse import urlparse

import pandas as pd

from . import festivals as F
from . import prep

BASE = Path(__file__).resolve().parent.parent
ENV = BASE / ".env"
KEY_RE = re.compile(r"^[ \t]*HUB_PROJECT_KEY[ \t]*=[ \t]*(.*)$", re.M)


def _read_key(p: Path) -> str:
    try:
        m = KEY_RE.search(p.read_text(encoding="utf-8"))
    except Exception:
        return ""
    return m.group(1).strip().strip('"').strip("'") if m else ""


def current_key() -> str:
    return _read_key(ENV) if ENV.exists() else ""


def masked(k: str) -> str:
    return "" if not k else (k[:3] + "•" * max(4, len(k) - 6) + k[-3:] if len(k) > 8 else "•" * len(k))


def save_key(key: str) -> None:
    key = key.strip()
    if not re.fullmatch(r"[A-Za-z0-9_\-]{8,128}", key):
        raise ValueError("키 모양이 이상합니다. 허브 마이페이지의 프로젝트 키를 그대로 붙여 넣어 주세요.")
    text = ENV.read_text(encoding="utf-8") if ENV.exists() else (
        (BASE / ".env.example").read_text(encoding="utf-8") if (BASE / ".env.example").exists() else "")
    text = KEY_RE.sub(f"HUB_PROJECT_KEY={key}", text) if KEY_RE.search(text) else text.rstrip() + f"\nHUB_PROJECT_KEY={key}\n"
    ENV.write_text(text, encoding="utf-8")
    os.environ["HUB_PROJECT_KEY"] = key


def find_other_keys(max_depth: int = 3) -> list[dict]:
    """이 PC의 다른 축제 프로그램 폴더(.env)에 적힌 허브 키를 찾는다 (상위 두 단계 폴더 아래만)."""
    roots, seen, out = [BASE.parent, BASE.parent.parent], set(), []
    for root in roots:
        if not root.exists():
            continue
        for dirpath, dirnames, filenames in os.walk(root):
            depth = len(Path(dirpath).relative_to(root).parts)
            dirnames[:] = [d for d in dirnames if not d.startswith((".venv", "$", "System Volume", "node_modules", "__"))]
            if depth >= max_depth:
                dirnames[:] = []
            if ".env" in filenames:
                p = Path(dirpath) / ".env"
                if p.resolve() == ENV.resolve() or p in seen:
                    continue
                seen.add(p)
                k = _read_key(p)
                if k:
                    out.append({"path": str(p), "masked": masked(k), "key": k})
    return out


def test_key(key: str) -> tuple[bool, str]:
    """허브에 1번만 물어봐 키가 맞는지 확인한다 (기상관측소 정보 첫 쪽)."""
    import requests
    url = f"https://open.jejudatahub.net/api/proxy/t1bab75a555a15715btaa7a5abaa1aab/{key}"
    try:
        r = requests.get(url, params={"limit": 1, "number": 1}, timeout=20)
    except Exception as e:
        return False, f"허브에 연결하지 못했습니다 (인터넷 확인). {str(e)[:60]}"
    t = r.text.strip()
    if r.status_code == 200 and t.startswith("{") and ("data" in t or "totCnt" in t):
        return True, "허브 연결 확인됨"
    return False, f"허브가 키를 받지 않았습니다 ({r.status_code}). 키와 [프로젝트 담기]를 확인해 주세요."


# ---------- 축제 추가 ----------

def stations(q: str, n: int = 12) -> list[str]:
    p = prep.PREP_DIR / "bus_stations.csv"
    if not p.exists() or not q.strip():
        return []
    st = pd.read_csv(p, dtype=str, encoding="utf-8-sig")
    key = q.replace(" ", "")
    hit = st[st["stationName"].str.replace(" ", "").str.contains(key, regex=False, na=False)]
    return hit["stationName"].drop_duplicates().head(n).tolist()


def add_festival(form: dict) -> dict:
    name = (form.get("name") or "").strip()
    edition = (form.get("edition") or "").strip()
    venue = (form.get("venue") or "").strip()
    place = (form.get("place") or "").strip()
    url = (form.get("source_url") or "").strip()
    title = (form.get("source_title") or "").strip()
    status = (form.get("status") or "개최").strip()
    try:
        start, end = pd.Timestamp(form.get("start")), pd.Timestamp(form.get("end") or form.get("start"))
    except Exception:
        raise ValueError("시작일·종료일을 날짜로 적어 주세요.")
    if not name:
        raise ValueError("축제 이름을 적어 주세요.")
    if end < start:
        raise ValueError("종료일이 시작일보다 앞입니다.")
    if not url.startswith("http"):
        raise ValueError("출처 링크(기사·공식 누리집 주소)를 적어 주세요. 날짜를 확인할 근거입니다.")
    st = pd.read_csv(prep.PREP_DIR / "bus_stations.csv", dtype=str, encoding="utf-8-sig")
    hit = st[st["stationName"] == place]
    if hit.empty:
        raise ValueError(f"'{place}' 정류소가 없습니다. 행사장 바로 앞 정류소 이름을 목록에서 골라 주세요.")
    addr = str(hit["stationAddress"].dropna().iloc[0]) if hit["stationAddress"].notna().any() else ""
    emd = next((t for t in addr.split() if re.search(r"(읍|면|동)$", t)), "")
    cat = pd.read_csv(F.CATALOG, dtype=str, encoding="utf-8-sig").fillna("")
    fid = "u" + time.strftime("%Y%m%d%H%M%S")
    row = {c: "" for c in cat.columns}
    row.update({"id": fid, "name": name, "edition": edition, "year": str(start.year), "start": f"{start:%Y-%m-%d}",
                "end": f"{end:%Y-%m-%d}", "status": status, "venue": venue or place, "place": place,
                "place_note": "사용자가 추가 · 정류소 이름 기준", "emd": emd,
                "source_title": title or urlparse(url).netloc, "source_url": url})
    dup = cat[(cat["name"] == name) & (cat["start"] == row["start"])]
    if len(dup):
        raise ValueError("같은 이름·시작일의 회차가 이미 목록에 있습니다.")
    with open(F.CATALOG, "a", encoding="utf-8-sig", newline="") as f:
        csv.DictWriter(f, fieldnames=list(cat.columns)).writerow(row)
    return row


def save_visit_file(name: str, data: bytes) -> int:
    for enc in ("utf-8-sig", "cp949"):
        try:
            d = pd.read_csv(io.BytesIO(data), dtype=str, encoding=enc)
            break
        except Exception:
            d = None
    if d is None:
        raise ValueError("CSV로 읽지 못했습니다.")
    cols = {c.strip() for c in d.columns}
    if not ({"콘텐츠명", "행사명", "축제명"} & cols and {"시작일", "행사시작일"} & cols):
        raise ValueError("행사 이름(콘텐츠명·행사명)과 시작일 컬럼이 있는 파일이 아닙니다.")
    safe = re.sub(r"[^0-9A-Za-z가-힣_.-]", "_", Path(name).name) or "visitjeju.csv"
    (BASE / "data" / f"visitjeju_{safe}").write_bytes(data)
    return len(d)
