"""Agent 본체: 축제 설명 → 조건 추출 → 데이터 점검 → 도구 실행 → 반출 점검 → 종합 판정.

외부 AI(LLM)로 나가는 것은 두 가지뿐이다.
  1) 조건 추출: 이용자가 적은 축제 설명 문장. 데이터는 보내지 않는다.
  2) 총평 작성: 반출 기준 점검을 통과한 핵심 숫자(증가율 등 요약값).
나간 내용은 모두 logs/llm_audit.jsonl 에 남는다.
API 키가 없으면 외부로 아무것도 보내지 않는 '기본 모드'(규칙 기반)로 동작한다.
"""
from __future__ import annotations

import html
import json
import os
import re
import time
from pathlib import Path

import pandas as pd
import requests

from . import tools
from .datasets import Loaded
from .tools import Spec

LOG_DIR = Path(__file__).resolve().parent.parent / "logs"


def config() -> dict:
    return {
        "api_key": os.environ.get("LLM_API_KEY", "").strip(),
        "base_url": os.environ.get("LLM_BASE_URL", "https://api.openai.com/v1").rstrip("/"),
        "model": os.environ.get("LLM_MODEL", "").strip(),
        "min_count": int(os.environ.get("EXPORT_MIN_COUNT", "10")),
        "send_summary": os.environ.get("LLM_SEND_AGGREGATES", "1") == "1",
    }


def llm_on(cfg) -> bool:
    return bool(cfg["api_key"] and cfg["model"])


def _audit(kind: str, payload) -> None:
    LOG_DIR.mkdir(exist_ok=True)
    with open(LOG_DIR / "llm_audit.jsonl", "a", encoding="utf-8") as f:
        f.write(json.dumps({"time": time.strftime("%Y-%m-%d %H:%M:%S"), "kind": kind, "sent": payload},
                           ensure_ascii=False, default=str) + "\n")


def _chat(cfg, system: str, user: str, kind: str) -> str:
    """OpenAI 호환 Chat Completions 형식. 다른 제공자는 LLM_BASE_URL 로 바꾼다."""
    _audit(kind, {"system": system, "user": user})
    r = requests.post(cfg["base_url"] + "/chat/completions", timeout=60,
                      headers={"Authorization": f"Bearer {cfg['api_key']}"},
                      json={"model": cfg["model"], "temperature": 0,
                            "messages": [{"role": "system", "content": system},
                                         {"role": "user", "content": user}]})
    r.raise_for_status()
    return r.json()["choices"][0]["message"]["content"]


class SpecError(ValueError):
    pass


# ---------- 1. 축제 조건 추출 ----------

EXTRACT_SYSTEM = """이용자가 적은 제주 축제·행사 설명에서 검증에 필요한 조건을 뽑아 JSON으로만 답하세요.
형식: {"name":"축제 이름","emd":"개최지 읍면동 이름(예: 삼도2동, 한림읍)","start":"YYYY-MM-DD","end":"YYYY-MM-DD","stations":["인근 버스 정류소 이름에 들어갈 글자"]}
규칙: 문장에 없는 값은 빈 문자열이나 빈 배열로 두세요. 읍면동이 직접 적혀 있지 않고 장소 이름만 있으면,
그 장소가 속한 제주의 읍면동을 확실히 아는 경우에만 적고 모르면 비워 두세요. 날짜를 지어내지 마세요."""


def _parse_json(text: str):
    m = re.search(r"\{.*\}", text, re.S)
    return json.loads(m.group(0)) if m else None


def _dates_from_text(text: str, default_year: int):
    """'2026-10-09 ~ 2026-10-13', '10월 9일부터 13일까지', '10/9~10/13' 같은 표기를 읽는다."""
    found = []
    for y, m, d in re.findall(r"(\d{4})[-./년]\s*(\d{1,2})[-./월]\s*(\d{1,2})", text):
        found.append((int(y), int(m), int(d)))
    if not found:
        year = int(re.search(r"(20\d{2})\s*년", text).group(1)) if re.search(r"(20\d{2})\s*년", text) else default_year
        md = re.findall(r"(\d{1,2})\s*[월/]\s*(\d{1,2})", text)
        for m, d in md:
            found.append((year, int(m), int(d)))
        if len(found) == 1:  # '10월 9일부터 13일까지'
            tail = re.search(r"\d{1,2}\s*[월/]\s*\d{1,2}\s*일?\s*(?:부터|~|-|에서)\s*(\d{1,2})\s*일", text)
            if tail:
                found.append((year, found[0][1], int(tail.group(1))))
    try:
        ds = [pd.Timestamp(year=y, month=m, day=d) for y, m, d in found[:2]]
    except ValueError:
        return None, None
    if not ds:
        return None, None
    return ds[0], (ds[1] if len(ds) > 1 else ds[0])


def _match_emd(text: str, emd_names: list[str]) -> str:
    """파일에 있는 읍면동 이름 중 문장에 나온 것을 찾는다. '제주시 한림읍' → '한림읍'으로도 찾는다."""
    best = ""
    for full in emd_names:
        short = str(full).split()[-1]
        for cand in (str(full), short):
            if cand and cand in text and len(cand) > len(best):
                best = short
    return best


def build_spec(form: dict, data: dict[str, Loaded], cfg: dict) -> tuple[Spec, str, list[str]]:
    """화면에서 받은 값(form)으로 Spec 을 만든다. 빈 칸은 설명 문장(form['text'])에서 채운다.

    반환: (Spec, 사용한 방식, 알림 목록)
    """
    notes: list[str] = []
    text = (form.get("text") or "").strip()
    pop = data.get("pop")
    emd_names = tools.emd_names(data)
    default_year = int(pop.df["base_date"].max().year) if pop is not None and len(pop.df) else pd.Timestamp.now().year

    got = {"name": (form.get("name") or "").strip(), "emd": (form.get("emd") or "").strip(),
           "control": (form.get("control") or "").strip(), "weather_station": (form.get("weather_station") or "").strip(),
           "start": (form.get("start") or "").strip(), "end": (form.get("end") or "").strip(),
           "stations": [s.strip() for s in re.split(r"[,，/]", form.get("stations") or "") if s.strip()]}
    mode = "입력한 값 사용"

    if text and not (got["emd"] and got["start"]):
        ext = None
        if llm_on(cfg):
            for attempt in range(2):  # 형식이 틀리면 한 번 더
                try:
                    ext = _parse_json(_chat(cfg, EXTRACT_SYSTEM, text, "extract"))
                    if isinstance(ext, dict):
                        mode = f"AI 모드({cfg['model']})로 문장에서 조건 추출"
                        break
                except Exception as e:
                    ext = None
                    if attempt == 1:
                        notes.append(f"AI 연결에 실패해 기본 모드로 문장을 읽었습니다. ({type(e).__name__})")
        if not isinstance(ext, dict):
            s, e = _dates_from_text(text, default_year)
            m = re.search(r"([가-힣A-Za-z0-9 ]{2,25}?(?:축제|문화제|페스티벌|행사|박람회|대회))", text)
            st = re.search(r"정류소\s*(?:는|은|:)?\s*([가-힣A-Za-z0-9, ]+)", text)
            emd_guess = _match_emd(text, emd_names)
            if not emd_guess and not emd_names:  # 파일을 넣기 전: 문장에서 '○○읍/면/동' 꼴을 찾는다
                g = re.search(r"([가-힣]{1,6}\d?(?:읍|면|동))(?:에서|에|의|\s|,|$)", text)
                emd_guess = g.group(1) if g else ""
            ext = {"name": m.group(1).strip() if m else "", "emd": emd_guess,
                   "start": f"{s:%Y-%m-%d}" if s is not None else "", "end": f"{e:%Y-%m-%d}" if e is not None else "",
                   "stations": [x.strip() for x in st.group(1).split(",") if x.strip()] if st else []}
            mode = "기본 모드(외부 전송 없음)로 문장에서 조건 추출"
        for k in ("name", "emd", "start", "end"):
            if not got[k] and ext.get(k):
                got[k] = str(ext[k]).strip()
        if not got["stations"] and isinstance(ext.get("stations"), list):
            got["stations"] = [str(x).strip() for x in ext["stations"] if str(x).strip()]

    missing = [lab for k, lab in (("emd", "개최 읍면동"), ("start", "시작일")) if not got[k]]
    if missing:
        raise SpecError(" · ".join(missing) + "을(를) 알 수 없습니다. 위 입력 칸에 직접 적어 주세요.")
    try:
        start = pd.Timestamp(got["start"])
        end = pd.Timestamp(got["end"]) if got["end"] else start
    except (ValueError, TypeError):
        raise SpecError("날짜를 읽지 못했습니다. 2026-10-09 처럼 적어 주세요.")
    if end < start:
        start, end = end, start
        notes.append("시작일과 종료일이 뒤바뀌어 있어 바로잡았습니다.")
    if (end - start).days > 30:
        raise SpecError("축제 기간이 31일을 넘습니다. 기간을 다시 확인해 주세요.")
    emd = got["emd"].split()[-1]
    if emd_names and not any(emd in str(n) for n in emd_names) and not form.get("allow_missing"):
        guess = _match_emd(text + " " + got["emd"], emd_names)
        if guess:
            notes.append(f"'{emd}' 대신 데이터에 있는 '{guess}'(으)로 분석했습니다.")
            emd = guess
        else:
            raise SpecError(f"유동인구 데이터에 '{emd}'이(가) 없습니다. '허브에서 가져오기'를 누르거나, 있는 읍면동 중에서 "
                            "고르세요: " + ", ".join(str(n) for n in emd_names[:15]))
    control = got["control"].split()[-1] if got["control"] else ""
    if control and control == emd:
        control = ""
    if control and emd_names and not any(control in str(n) for n in emd_names) and not form.get("allow_missing"):
        notes.append(f"대조 지역 '{control}'의 데이터가 없어 대조 비교는 건너뜁니다.")
        control = ""
    spec = Spec(name=got["name"] or "이름 없는 행사", emd=emd, start=start, end=end, stations=got["stations"],
                control=control, weather_station=got["weather_station"])
    return spec, mode, notes


# ---------- 2. 요약 문장 ----------

def tool_sentence(res: tools.Result) -> str:
    f = res.facts
    if res.tool == "visit_effect":
        up = f.get("증가율(%)")
        if up is None:
            return "평소와 비교할 수 없었습니다."
        weather = []
        if f.get("비 온 날(1mm 이상)", "없음") != "없음":
            weather.append(f"비 온 날 {f['비 온 날(1mm 이상)']}")
        if f.get("강풍 날(최대 풍속 14m/s 이상)", "없음") != "없음":
            weather.append(f"강풍 날 {f['강풍 날(최대 풍속 14m/s 이상)']}")
        wtxt = f" 축제 기간 날씨({f['날씨 기준']}): " + ", ".join(weather) + "." if weather else ""
        return (f"{res.title.split('(')[-1].split(',')[-1].strip(' )')}만 따로 보면 축제 기간 방문 인구가 같은 요일 평소보다 {abs(up):.1f}% {'많았' if up >= 0 else '적었'}고 "
                f"(평소 변동폭 {f.get('평소 변동폭(%)')}%), 판정은 '{f['판정']}'입니다. "
                f"평소 변동을 넘게 늘어난 날은 {f['평소를 넘게 늘어난 날']}이며, 가장 많이 늘어난 날은 {f['가장 많이 늘어난 날']}입니다.{wtxt}")
    if res.tool == "control_compare":
        n = f.get("평균 순증가(%p)")
        if n is None:
            return "대조 지역과 비교할 수 없었습니다."
        return (f"같은 날 이웃 {f['대조 지역']}의 변화를 빼고 보면(순증가) 축제 기간 평균 {n:+.1f}%p이고, "
                f"가장 큰 날은 {f['순증가가 가장 큰 날']}입니다. 순증가의 평소 변동폭({f.get('순증가 평소 변동폭(%p)')}%p)의 "
                f"2배를 넘은 날, 즉 축제 효과로 볼 만한 날은 {f['순증가가 뚜렷한 날']}입니다.")
    if res.tool == "hourly_profile":
        return f"평소 대비 가장 많이 늘어난 시간대는 {f['가장 많이 늘어난 시간대']}({f['그 시간대 증가율(%)']:+.1f}%)입니다."
    if res.tool == "visitor_mix":
        word = "가장 많이 늘어난" if (f['그 집단 증가율(%)'] or 0) >= 0 else "가장 덜 줄어든"
        return (f"{f['대상 날짜']} 기준으로 평소 같은 요일보다 {word} 집단은 '{f['가장 많이 늘어난 집단']}'"
                f"({f['그 집단 증가율(%)']:+.1f}%)입니다.")
    if res.tool == "bus_effect":
        return (f"인근 정류소 {f['대상 정류소 수']}곳의 버스 승하차는 평소 대비 {f['증가율(%)']:+.1f}%였습니다."
                if f.get("증가율(%)") is not None else "버스 승하차를 평소와 비교할 수 없었습니다.")
    return "표를 참고해 주세요."


SUMMARY_SYSTEM = """당신은 제주 축제 성과 검증 보고서의 총평을 쓰는 담당입니다.
주어진 핵심 숫자만 근거로 4~6문장의 한국어 총평을 쓰세요.
규칙: 주어지지 않은 숫자나 사실을 만들지 마세요. 증가를 축제 때문이라고 단정하지 말고 '~로 보입니다'처럼 쓰세요.
대조 지역 비교(control_compare)가 있으면 그 판정을 가장 중요한 근거로 쓰세요. 계절 변화처럼 제주 전체에 생긴 변화는 대조 지역에서도 나타나기 때문입니다. 순증가가 뚜렷한 날이 '없음'이면 효과가 확인되지 않았다고 분명히 쓰세요. 날씨(비, 강풍)가 있으면 그 영향 가능성을 언급하세요. 마지막 문장에는 다음 축제 준비에 쓸 수 있는 점 한 가지를 제안하세요."""


def summary_text(cfg, spec: Spec, results: list[tools.Result]) -> tuple[str, str]:
    facts = {r.tool: {k: v for k, v in r.facts.items() if not k.startswith("_")} for r in results if r.facts}
    order = {"control_compare": 0, "visit_effect": 1}
    ordered = sorted([r for r in results if r.facts], key=lambda r: order.get(r.tool, 2))
    rule = " ".join(tool_sentence(r) for r in ordered)
    cc = next((r for r in results if r.tool == "control_compare"), None)
    if cc is not None and cc.facts.get("순증가가 뚜렷한 날", "없음") != "없음":
        rule = "결론: 대조 지역과 비교하면 축제 효과로 볼 만한 증가가 확인됩니다. " + rule
    elif cc is not None and cc.facts.get("평균 순증가(%p)") is not None:
        rule = "결론: 대조 지역과 비교해도 축제 효과로 볼 만한 증가는 확인되지 않았습니다. " + rule
    if llm_on(cfg) and cfg["send_summary"] and facts:
        try:
            user = json.dumps({"축제": spec.name, "기간": f"{spec.start:%Y-%m-%d}~{spec.end:%Y-%m-%d}",
                               "읍면동": spec.emd, "핵심 숫자": facts}, ensure_ascii=False, default=str)
            return _chat(cfg, SUMMARY_SYSTEM, user, "summary").strip(), "AI 작성"
        except Exception:
            pass
    return rule, "자동 요약"


# ---------- 3. 실행 ----------

def _spec_html(spec: Spec, mode: str) -> str:
    lo, hi = spec.window
    st = ", ".join(spec.stations) if spec.stations else "입력 없음"
    return ('<table><tbody>'
            f'<tr><th>축제</th><td class="l">{html.escape(spec.name)}</td><th>개최 읍면동</th><td class="l">{html.escape(spec.emd)}</td></tr>'
            f'<tr><th>기간</th><td class="l">{spec.start:%Y-%m-%d} ~ {spec.end:%Y-%m-%d} ({len(spec.days)}일)</td>'
            f'<th>평소로 본 기간</th><td class="l">{lo:%Y-%m-%d} ~ {hi:%Y-%m-%d} 중 같은 요일 (축제일·공휴일 제외)</td></tr>'
            f'<tr><th>대조 지역</th><td class="l">{html.escape(spec.control or "없음")}</td>'
            f'<th>인근 정류소</th><td class="l">{html.escape(st)}</td></tr>'
            f'<tr><th>조건을 정한 방식</th><td class="l" colspan="3">{html.escape(mode)}</td></tr>'
            '</tbody></table>')


def verify(form: dict, data: dict[str, Loaded]) -> dict:
    cfg = config()
    spec, mode, notes = build_spec(form, data, cfg)
    results, errors = [], list(notes)
    plan = ["visit_effect"]
    if spec.control:
        plan.append("control_compare")
    pop = data.get("pop")
    if pop is not None and pop.hourly:
        plan.append("hourly_profile")
    plan.append("visitor_mix")
    if "bus" in data and spec.stations:
        plan.append("bus_effect")
    sig_days = None
    for name in plan:
        try:
            if name == "visitor_mix":
                r = tools.visitor_mix(data, spec, cfg, days=sig_days)
            else:
                r = tools.run(name, data, spec, cfg)
            results.append(r)
            if name == "visit_effect":
                # 구성 분석은 '평소를 넘게 늘어난 날'만 대상으로 한다 (사전행사처럼 효과 없는 날이 섞이지 않게)
                t = r.table
                ok = t[t["판정"] == "평소 변동을 넘는 증가"]["날짜"]
                sig_days = pd.to_datetime(ok).tolist() or None
            if name == "control_compare" and r.facts.get("_sig_days"):
                # 대조 지역 비교가 있으면, 순증가가 뚜렷한 날을 우선 대상으로 삼는다
                sig_days = list(r.facts["_sig_days"])
        except tools.ToolError as e:
            if name not in ("hourly_profile",):
                errors.append(str(e))
    ve = next((r for r in results if r.tool == "visit_effect"), None)
    if ve is not None and (ve.table["평소 비교 일수"] < 2).any():
        errors.append("같은 요일의 평소 날짜가 2일 미만인 날이 있습니다. 판정은 참고용으로만 보세요.")
    items = [{"result": r, "text": tool_sentence(r), "how": "자동 요약"} for r in results]
    total, how = summary_text(cfg, spec, results) if results else ("분석 결과가 없습니다.", "자동 요약")
    return {"question": f"축제 성과 검증: {spec.label()}", "mode": mode, "note": "", "errors": errors,
            "results": items, "time": time.strftime("%Y-%m-%d %H:%M"), "min_count": cfg["min_count"],
            "spec": spec, "spec_html": _spec_html(spec, mode)
            + f'<div class="say"><b>총평</b> {html.escape(total)} <span class="small">({how})</span></div>'}
