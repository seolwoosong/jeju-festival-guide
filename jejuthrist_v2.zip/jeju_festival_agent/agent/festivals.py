"""축제 찾기: 정확한 축제 이름과 개최 연도·기간을 출처와 함께 확인한다.

목록은 두 가지를 합친다.
  1. data/festivals.csv  - 행사장·정류소까지 확인해 둔 축제 회차 (언론·관광공사 자료 출처 링크 포함)
  2. VISIT JEJU 「축제행사콘텐츠」 파일 (제주데이터허브 데이터 761, 있으면) - 이름·시작일·종료일
     data/ 아래에 '콘텐츠명'(또는 '행사명')·'시작일'·'종료일' 컬럼이 있는 CSV를 넣으면 자동으로 읽는다.

원칙: 목록에 없는 해는 "열리지 않았다"고 하지 않고 "이 목록에서는 확인할 수 없다"고 답한다.
이름이 조금 틀리면(예: 들블축제) 가장 가까운 정식 이름을 제안하되, 맞다고 단정하지 않는다.
"""
from __future__ import annotations

import difflib
import re
from datetime import date, timedelta
from functools import lru_cache
from pathlib import Path

import pandas as pd

BASE = Path(__file__).resolve().parent.parent
CATALOG = BASE / "data" / "festivals.csv"
PREP_DIR = BASE / "data" / "prep"
WX_YEARS = 10          # 날씨는 최근 10철을 본다
WX_PAD = 7             # 축제 앞뒤 7일까지 날씨를 본다
VISIT_SRC = "VISIT JEJU 축제행사콘텐츠 (제주데이터허브)"


def _norm(s) -> str:
    """비교용 이름: 공백·기호·회차·연도를 뺀다. '2025 제18회 제주 해녀 축제' → '제주해녀축제'"""
    s = str(s)
    s = re.sub(r"(19|20)\d{2}\s*년?", "", s)
    s = re.sub(r"(?<!\d)\d{2}\s*년", "", s)
    s = re.sub(r"제?\s*\d+\s*회", "", s)
    return re.sub(r"[\s\W_]+", "", s)


def _visit_files() -> list[Path]:
    out = []
    for p in sorted((BASE / "data").glob("*.csv")):
        if p.name == CATALOG.name:
            continue
        try:
            head = pd.read_csv(p, nrows=0, encoding="utf-8-sig").columns
        except Exception:
            try:
                head = pd.read_csv(p, nrows=0, encoding="cp949").columns
            except Exception:
                continue
        cols = {str(c).strip() for c in head}
        if ({"콘텐츠명", "행사명", "축제명"} & cols) and ({"시작일", "행사시작일"} & cols):
            out.append(p)
    return out


def _read_visit(p: Path) -> pd.DataFrame:
    for enc in ("utf-8-sig", "cp949"):
        try:
            d = pd.read_csv(p, dtype=str, encoding=enc)
            break
        except UnicodeDecodeError:
            continue
    d.columns = [str(c).strip() for c in d.columns]
    pick = lambda *names: next((d[n] for n in names if n in d.columns), pd.Series([""] * len(d)))  # noqa: E731
    out = pd.DataFrame({
        "name": pick("콘텐츠명", "행사명", "축제명").fillna("").str.strip(),
        "start": pd.to_datetime(pick("시작일", "행사시작일"), errors="coerce"),
        "end": pd.to_datetime(pick("종료일", "행사종료일"), errors="coerce"),
        "host": pick("주최", "주최기관").fillna(""),
    }).dropna(subset=["start"])
    out["end"] = out["end"].fillna(out["start"])
    out["year"] = out["start"].dt.year
    out["source_title"] = f"{VISIT_SRC} · {p.name}"
    return out[out["name"] != ""]


@lru_cache(maxsize=1)
def _load_cached(mtime: float) -> tuple[pd.DataFrame, pd.DataFrame]:
    cat = pd.read_csv(CATALOG, dtype=str, encoding="utf-8-sig").fillna("")
    cat["start"] = pd.to_datetime(cat["start"])
    cat["end"] = pd.to_datetime(cat["end"])
    cat["year"] = cat["year"].astype(int)
    visit = pd.concat([_read_visit(p) for p in _visit_files()], ignore_index=True) if _visit_files() else pd.DataFrame(
        columns=["name", "start", "end", "host", "year", "source_title"])
    return cat, visit


def load() -> tuple[pd.DataFrame, pd.DataFrame]:
    """(확인된 회차 목록, VISIT JEJU 목록)"""
    stamp = CATALOG.stat().st_mtime + sum(p.stat().st_mtime for p in _visit_files())
    return _load_cached(stamp)


def names() -> list[str]:
    cat, visit = load()
    return sorted(set(cat["name"]) | set(visit["name"]))


def _year_of(q: str) -> int | None:
    m = re.search(r"(19|20)\d{2}", q)
    if m:
        return int(m.group(0))
    m = re.search(r"(?<!\d)(\d{2})\s*년", q)
    return 2000 + int(m.group(1)) if m else None


def search(q: str) -> dict:
    """이름(+연도)으로 찾는다. 결과: 정식 이름, 맞춘 방식, 회차 목록, 판정 문장."""
    q = (q or "").strip()
    year = _year_of(q)
    key = _norm(q)
    if not key:
        return {"query": q, "found": False, "verdict": "축제 이름을 적어 주세요. 예: 2025 탐라문화제"}
    cat, visit = load()
    all_names = names()
    normmap = {}
    for n in all_names:
        normmap.setdefault(_norm(n), n)
    exact = [n for k, n in normmap.items() if k == key]
    part = [n for k, n in normmap.items() if key in k or (len(k) >= 3 and k in key)]
    how = "정확히 일치"
    if exact:
        matched = exact
    elif part:
        matched, how = sorted(set(part)), "이름 일부 일치"
    else:
        close = difflib.get_close_matches(key, list(normmap), n=3, cutoff=0.6)
        matched, how = [normmap[c] for c in close], "비슷한 이름 (철자 확인 필요)"
    if not matched:
        return {"query": q, "found": False, "year": year,
                "verdict": f"'{q}'와 맞는 축제를 목록에서 찾지 못했습니다. 정확한 이름을 확인할 수 없어 연도도 판단하지 않습니다."}

    rows = cat[cat["name"].isin(matched)].sort_values("start", ascending=False)
    vrows = visit[visit["name"].isin(matched)].sort_values("start", ascending=False)
    lines = []
    if how.startswith("비슷한"):
        lines.append(f"'{q}'는 목록에 있는 정식 이름이 아닙니다. 가장 가까운 정식 이름: {', '.join(matched)}.")
    for name in matched:
        r = rows[rows["name"] == name]
        v = vrows[vrows["name"] == name]
        yrs = sorted(set(r["year"]) | set(v["year"].astype(int)))
        if year is None:
            lines.append(f"{name}: 목록에서 확인되는 해 {', '.join(map(str, yrs)) or '없음'}.")
            continue
        hit = r[r["year"] == year]
        vh = v[v["year"] == year]
        if not hit.empty:
            h = hit.iloc[0]
            ed = f"{h['edition']} " if h["edition"] else ""
            lines.append(f"{year}년 {ed}{name}: {h['start']:%Y-%m-%d} ~ {h['end']:%Y-%m-%d}, {h['venue']}. "
                         f"상태: {h['status']}. (출처: {h['source_title']})")
        elif not vh.empty:
            h = vh.iloc[0]
            lines.append(f"{year}년 {name}: {h['start']:%Y-%m-%d} ~ {h['end']:%Y-%m-%d}. (출처: {VISIT_SRC})")
        else:
            lines.append(f"{year}년 {name}은(는) 이 목록에서 확인할 수 없습니다 (열리지 않았다는 뜻은 아님). "
                         f"목록에서 확인되는 해: {', '.join(map(str, yrs)) or '없음'}.")
    if year is not None:
        rows = rows[rows["year"] == year] if (rows["year"] == year).any() else rows
    return {"query": q, "found": True, "year": year, "how": how, "names": matched,
            "rows": rows, "visit_rows": vrows, "verdict": " ".join(lines)}


# ---------- 준비 계산과 받아 둔 자료 ----------

def wx_window(row) -> tuple[str, str]:
    a = (row["start"] - timedelta(days=WX_PAD)).strftime("%m-%d")
    b = (row["end"] + timedelta(days=WX_PAD)).strftime("%m-%d")
    return a, b


def weather_days(row, years: int = WX_YEARS) -> list[date]:
    """이 회차의 날씨 위험 계산에 필요한 날짜들 (최근 years 철, 축제 앞뒤 WX_PAD일)."""
    s0, e0 = row["start"].date(), row["end"].date()
    out = []
    for back in range(years):
        try:
            s = s0.replace(year=s0.year - back) - timedelta(days=WX_PAD)
            e = e0.replace(year=e0.year - back) + timedelta(days=WX_PAD)
        except ValueError:          # 2월 29일
            continue
        d = s
        while d <= e:
            out.append(d)
            d += timedelta(days=1)
    return out


def bus_days(row, weeks: int = 1) -> tuple[list[date], list[date]]:
    """(축제일, 평소로 쓸 같은 요일) — 평소는 앞뒤 weeks주."""
    fest = []
    d = row["start"].date()
    while d <= row["end"].date():
        fest.append(d)
        d += timedelta(days=1)
    base = sorted({x + timedelta(weeks=s * w) for x in fest for w in range(1, weeks + 1) for s in (-1, 1)} - set(fest))
    return fest, base


def _have(sub: str, days: list[date], prefix: str) -> int:
    folder = PREP_DIR / sub
    n = 0
    for d in days:
        f = folder / f"{prefix}_{d:%Y%m%d}.csv"
        n += f.exists() and f.stat().st_size >= 10      # 빈 응답(자료 없음) 파일은 세지 않는다
    return n


def coverage(row) -> dict:
    wd = weather_days(row)
    fest, base = bus_days(row, weeks=2)
    return {"weather": f"{_have('weather', wd, 'wx')}/{len(wd)}일",
            "weather_ok": _have("weather", wd, "wx") >= len(wd) * 0.8,
            "bus_fest": f"{_have('bus', fest, 'bus')}/{len(fest)}일",
            "bus_base": _have("bus", base, "bus"),
            "bus_ok": _have("bus", fest, "bus") > 0 and _have("bus", base, "bus") >= 2}


def prep_form(row) -> dict:
    a, b = wx_window(row)
    return {"name": f"{row['year']} {row['name']} 기준 준비", "place": row["place"], "wx_from": a, "wx_to": b,
            "ref_start": f"{row['start']:%Y-%m-%d}", "ref_end": f"{row['end']:%Y-%m-%d}"}


def get(fid: str):
    cat, _ = load()
    hit = cat[cat["id"] == fid]
    return None if hit.empty else hit.iloc[0]
