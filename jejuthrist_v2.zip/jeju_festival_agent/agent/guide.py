"""제주 축제 길잡이: 축제 이름 하나로 '준비하는 사람'과 '즐기는 사람'에게 줄 답을 만든다.

화면(JS)이 그림으로 그릴 수 있게 숫자만 담은 사전(dict)을 돌려준다. 문장은 짧게, 숫자는 모두 실측 결과에서 가져온다.
  - 언제: 축제 목록(출처 있음)의 회차 날짜
  - 사람: 읍면동 유동인구(일별 방문 인구) - 축제날 vs 같은 요일 평소, 1년 중 붐볐던 날
  - 날씨: 가장 가까운 관측소의 지난 10철 같은 시기 비·강풍
  - 버스: 행사장 근처 정류소 교통카드 승차 - 축제날 vs 같은 요일 평소
"""
from __future__ import annotations

from datetime import date, timedelta

import pandas as pd

from . import festivals as F
from . import holidays as H
from . import prep
from .datasets import WEEKDAYS
from .tools import ToolError

CFG = {"min_count": 10}


def _md(s: str) -> str:            # '03-14' or '03/14' → '3/14'
    s = s.replace("/", "-")
    m, d = s.split("-")
    return f"{int(m)}/{int(d)}"


def short_range(a, b) -> str:
    a, b = pd.Timestamp(a), pd.Timestamp(b)
    if a == b:
        return f"{a.month}.{a.day}"
    return f"{a.month}.{a.day}–{b.day}" if a.month == b.month else f"{a.month}.{a.day}–{b.month}.{b.day}"


def day_range(mds: list[str]) -> str:
    """['3/10','3/11','3/12'] → '3/10–12'"""
    p = [tuple(map(int, x.split("/"))) for x in mds]
    run = len(p) > 1 and all(p[i][0] == p[i - 1][0] and p[i][1] == p[i - 1][1] + 1 for i in range(1, len(p)))
    return f"{p[0][0]}/{p[0][1]}–{p[-1][1]}" if run else ", ".join(mds)


def _d(x) -> str:
    x = pd.Timestamp(x)
    return f"{x.month}/{x.day}({WEEKDAYS[x.dayofweek]})"


# ---------- 사람(유동인구) ----------

def crowd(pop_df: pd.DataFrame | None, row) -> dict | None:
    """읍면동 일별 방문 인구로 축제날 붐빔과 '1년(받은 기간) 중 붐볐던 날'을 계산한다."""
    if pop_df is None or pop_df.empty or not row["emd"]:
        return None
    d = pop_df[pop_df["emd_nm"] == row["emd"]]
    if d.empty:
        return None
    def series(emd):
        x = pop_df[pop_df["emd_nm"] == emd].groupby("base_date")["visit_pop_cnt"].sum().sort_index()
        x.index = pd.to_datetime(x.index)
        # 그 회차 앞뒤 4달만 본다 (다른 해 자료가 섞이지 않게)
        return x[(x.index >= row["start"] - pd.Timedelta(days=120)) & (x.index <= row["end"] + pd.Timedelta(days=120))]
    daily = series(row["emd"])
    ctrl = series(row["control"]) if row.get("control") else pd.Series(dtype=float)
    fest = [x for x in pd.date_range(row["start"], row["end"]) if x in daily.index]
    if not fest:
        return None
    hol = H.holidays()
    lo, hi = row["start"] - pd.Timedelta(weeks=4), row["end"] + pd.Timedelta(weeks=4)
    fdays = set(pd.date_range(row["start"], row["end"]))
    days = []
    for x in fest:
        base = [x + pd.Timedelta(weeks=k) for k in (-4, -3, -2, -1, 1, 2, 3, 4)]
        base = [b for b in base if b in daily.index and b not in fdays and b not in hol and lo <= b <= hi]
        if len(base) < 2:
            continue
        b = float(daily[base].mean())
        pct = (float(daily[x]) / b - 1) * 100
        net = None
        cb = [y for y in base if y in ctrl.index]
        if x in ctrl.index and len(cb) >= 2:      # 대조 지역도 같은 날 함께 줄거나 늘었다면 그만큼 뺀다
            net = round(pct - (float(ctrl[x]) / float(ctrl[cb].mean()) - 1) * 100, 1)
        days.append({"date": f"{x:%Y-%m-%d}", "label": _d(x), "visit": round(float(daily[x])), "base": round(b),
                     "pct": round(pct, 1), "net": net})
    # 받은 기간 전체에서 붐볐던 날 (같은 요일 평균 대비가 아니라 절대 방문 인구 순)
    cat, _ = F.load()
    others = {}
    for _, r in cat[cat["emd"] == row["emd"]].iterrows():
        for x in pd.date_range(r["start"], r["end"]):
            others[x] = f"{r['name']}"
    top = []
    for x, v in daily.sort_values(ascending=False).head(5).items():
        tag = others.get(x) or ("공휴일" if x in hol else ("주말" if x.dayofweek >= 5 else ""))
        top.append({"date": f"{x:%Y-%m-%d}", "label": _d(x), "visit": round(float(v)), "tag": tag})
    cal = [{"date": f"{x:%Y-%m-%d}", "v": round(float(v)), "fest": x in fdays} for x, v in daily.items()]
    score = (lambda z: z["net"] if z["net"] is not None else z["pct"])
    best = max(days, key=score) if days else None
    return {"emd": row["emd"], "control": row.get("control") if len(ctrl) else "", "period": f"{daily.index.min():%Y-%m-%d} ~ {daily.index.max():%Y-%m-%d}",
            "n_days": len(daily), "days": days, "best": best, "top": top, "calendar": cal,
            "median": round(float(daily.median()))}


# ---------- 날씨 ----------

def weather(row) -> dict | None:
    f = F.prep_form(row)
    spec = prep.PrepSpec(name=f["name"], place=row["place"], wx_from=f["wx_from"], wx_to=f["wx_to"],
                         ref_start=row["start"], ref_end=row["end"])
    try:
        r = prep.weather_risk(spec, CFG)
    except ToolError as e:
        return {"error": str(e)}
    t, fx = r.table, r.facts
    fest_md = {f"{x:%m/%d}" for x in pd.date_range(row["start"], row["end"])}
    strip = [{"md": _md(a), "bad": int(b), "n": int(n), "wind": int(w), "rain": int(rr), "fest": a in fest_md}
             for a, b, n, w, rr in zip(t["날짜"], (t["비 또는 강풍 비율(%)"] * t["기록 연수"] / 100).round(),
                                       t["기록 연수"], t["강풍 해"], t["비 온 해"])]
    return {"obs": fx["관측소"], "dist": fx["행사장과 거리(km)"], "years": fx["기록 연수"], "span": fx["기록 연도"],
            "wind_pct": fx["강풍 날 비율(%)"], "rain_pct": fx["비 온 날 비율(%)"],
            "best": [_md(x) for x in fx["비·강풍이 가장 적었던 날"].split(", ")],
            "worst": [_md(x) for x in fx["비·강풍이 가장 잦았던 날"].split(", ")],
            "max_wind": fx.get("이 기간 가장 센 바람(m/s)"), "max_wind_day": fx.get("가장 센 바람이 분 날"),
            "past": fx.get("지난 축제 기간 실제 날씨"), "strip": strip}


# ---------- 버스 ----------

def bus(row) -> dict | None:
    f = F.prep_form(row)
    spec = prep.PrepSpec(name=f["name"], place=row["place"], wx_from=f["wx_from"], wx_to=f["wx_to"],
                         ref_start=row["start"], ref_end=row["end"])
    try:
        r = prep.bus_demand(spec, CFG)
    except ToolError as e:
        return {"error": str(e)}
    fx = r.facts
    days = []
    for _, x in r.table.iterrows():
        if x["판정"] in ("자료 없음",):
            continue
        days.append({"label": _d(x["날짜"]), "fest": x["축제일 승차"], "base": x["평소(같은 요일 평균)"],
                     "extra": x["늘어난 인원"], "verdict": x["판정"]})
    key = f"참고 증차(버스 1대 {prep.BUS_SEATS}명 기준, 하루)"
    return {"stops": fx["근처 정류소"], "radius": fx["반경(km)"], "days": days,
            "max_extra": fx["하루 최대 추가 승차(명)"], "buses": fx[key], "ratio": fx.get("평소 대비 배율"),
            "peak_day": fx.get("가장 많이 늘어난 날"), "note": fx.get("판정 참고용 여부") == "예",
            "seats": prep.BUS_SEATS}


# ---------- 두 사람에게 줄 한 줄 ----------

def advice(info: dict) -> dict:
    w, b, c = info.get("weather") or {}, info.get("bus") or {}, info.get("crowd") or {}
    prep_l, fun_l = [], []
    if w and not w.get("error"):
        if w["wind_pct"] >= 30:
            prep_l.append(f"무대·천막 강풍 대비, 예비일 잡기 (강풍 {w['wind_pct']}%)")
            fun_l.append("바람막이 챙기기, 연기·취소 공지 확인")
        elif w["rain_pct"] >= 30:
            prep_l.append(f"우천 동선과 예비일 잡기 (비 {w['rain_pct']}%)")
            fun_l.append("우산·우비 챙기기")
        prep_l.append(f"날짜를 고른다면 {day_range(w['best'])}")
        fun_l.append(f"고를 수 있다면 {day_range(w['best'])}에 가기")
    if b and not b.get("error") and b.get("max_extra"):
        prep_l.append(f"마치는 시간 버스 {b['buses']}대 더 (하루 +{b['max_extra']}명)")
        fun_l.append("돌아오는 버스 붐빔 · 귀가 수단 미리")
    if c and c.get("best") and (c["best"]["net"] if c["best"]["net"] is not None else c["best"]["pct"]) > 0:
        v = round(c["best"]["net"] if c["best"]["net"] is not None else c["best"]["pct"])
        prep_l.append(f"가장 붐빈 날 {c['best']['label']}(평소보다 약 {v}%) 기준으로 인력 배치")
        fun_l.append(f"덜 붐비려면 {c['best']['label']} 피하기 (평소보다 약 {v}% 더 붐빔)")
    return {"prep": prep_l[:3], "fun": fun_l[:3]}


def reports(fid: str) -> list[dict]:
    """언론에 보도된 기록 (data/festival_reports.csv, 출처 링크 포함)."""
    p = F.BASE / "data" / "festival_reports.csv"
    if not p.exists():
        return []
    d = pd.read_csv(p, dtype=str, encoding="utf-8-sig").fillna("")
    return d[d["id"] == fid].drop(columns=["id"]).to_dict("records")


def build(row, pop_df) -> dict:
    cat, _ = F.load()
    eds = cat[cat["name"] == row["name"]].sort_values("start")
    today = pd.Timestamp(date.today())
    nxt = eds[eds["start"] > today]
    info = {
        "id": row["id"], "name": row["name"], "edition": row["edition"], "year": int(row["year"]),
        "start": f"{row['start']:%Y-%m-%d}", "end": f"{row['end']:%Y-%m-%d}",
        "when": (f"{row['start']:%Y.%m.%d}" if row["start"] == row["end"] else f"{row['start']:%Y.%m.%d} – {row['end']:%m.%d}"),
        "status": row["status"],
        "cancelled": row["status"].startswith("취소"), "partial": "일부 취소" in row["status"],
        "short": short_range(row["start"], row["end"]), "venue": row["venue"], "place": row["place"],
        "place_note": row["place_note"], "source": {"title": row["source_title"], "url": row["source_url"]},
        "editions": [{"id": r["id"], "year": int(r["year"]), "when": f"{r['start']:%m.%d}–{r['end']:%m.%d}",
                      "status": r["status"], "cancelled": r["status"].startswith("취소"),
                      "partial": "일부 취소" in r["status"]} for _, r in eds.iterrows()],
        "next": (f"{nxt.iloc[0]['start']:%Y.%m.%d}" if len(nxt) else None),
        "weather": weather(row), "bus": bus(row), "crowd": crowd(pop_df, row),
    }
    info["reports"] = reports(row["id"])
    info["advice"] = advice(info)
    cov = F.coverage(row)
    info["coverage"] = cov
    return info


# ---------- 전용 화면(준비하는 사람 / 즐기는 사람)에 쓰는 추가 자료 ----------

def extra(row, info: dict) -> dict:
    """같은 시기 다른 축제, 공휴일, 근처 정류소, 날짜 고르기용 기록."""
    cat, _ = F.load()
    lo, hi = row["start"] - pd.Timedelta(days=14), row["end"] + pd.Timedelta(days=14)
    ov = cat[(cat["id"] != row["id"]) & (cat["end"] >= lo) & (cat["start"] <= hi)]
    overlaps = [{"id": r["id"], "name": r["name"], "when": short_range(r["start"], r["end"]), "venue": r["venue"],
                 "same_days": bool((r["end"] >= row["start"]) and (r["start"] <= row["end"]))}
                for _, r in ov.sort_values("start").iterrows()]
    hol = sorted(x for x in H.holidays() if lo <= x <= hi)
    stops = []
    try:
        lat, lon, _ = prep.locate(prep.PrepSpec(name="", place=row["place"], wx_from="01-01", wx_to="01-02"))
        near = prep._near_station_names(lat, lon, 1.0, prep.PREP_DIR)
        for _, s in near.drop_duplicates("stationName").head(6).iterrows():
            stops.append({"name": s["stationName"], "m": int(round(s["dist"] * 1000))})
    except Exception:
        pass
    # 요일별 평소 방문 인구 (즐기는 사람: 고른 날이 붐비는 요일인지)
    wd = None
    c = info.get("crowd")
    if c:
        s = pd.Series({pd.Timestamp(x["date"]): x["v"] for x in c["calendar"] if not x["fest"]})
        if len(s):
            g = s.groupby(s.index.dayofweek).median()
            wd = [{"dow": WEEKDAYS[i], "v": round(float(g.get(i, 0)))} for i in range(7)]
    return {"overlaps": overlaps, "holidays": [f"{x.month}/{x.day}" for x in hol], "stops": stops,
            "weekday": wd, "seats": prep.BUS_SEATS}
