"""축제 성과 검증 도구 모음.

핵심 방법: 축제 기간의 값을 '평소'와 비교한다.
평소 = 축제 전후 N주(기본 4주) 안에서 같은 요일인 날들의 평균. 축제일과 공휴일은 평소에서 뺀다.
대조 지역(이웃 읍면동)을 함께 보면, 같은 기간 제주 전체에 생긴 변화(날씨, 관광 수요)를 걸러 낼 수 있다.
AI는 여기 있는 도구만 고를 수 있고, 계산은 모두 이 PC 안에서 pandas 로 한다.
"""
from __future__ import annotations

import io
from dataclasses import dataclass, field

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import pandas as pd  # noqa: E402
from matplotlib import font_manager  # noqa: E402

from . import guard  # noqa: E402
from .datasets import WEEKDAYS, Loaded  # noqa: E402
from .holidays import holidays  # noqa: E402


def _setup_font():
    names = {f.name for f in font_manager.fontManager.ttflist}
    for cand in ["Malgun Gothic", "맑은 고딕", "NanumGothic", "AppleGothic",
                 "Noto Sans CJK KR", "Noto Sans KR", "Noto Sans CJK JP"]:
        if cand in names:
            plt.rcParams["font.family"] = cand
            break
    plt.rcParams["axes.unicode_minus"] = False


_setup_font()
C_FEST, C_BASE, C_CTRL = "#e08a2c", "#8fa3b8", "#2a6fb0"


@dataclass
class Spec:
    """검증할 축제 한 건."""
    name: str
    emd: str                      # 읍면동 이름(일부만 적어도 됨)
    start: pd.Timestamp
    end: pd.Timestamp
    stations: list[str] = field(default_factory=list)   # 인근 버스 정류소 이름에 들어가는 글자
    control: str = ""             # 대조 지역(이웃 읍면동). 비우면 대조 비교를 하지 않음
    weather_station: str = ""     # 날씨 관측소 이름. 비우면 읍면동 이름으로 찾고, 없으면 전체 평균
    weeks: int = 4                # 평소로 볼 전후 주 수
    hour_from: int = 9
    hour_to: int = 22

    @property
    def days(self) -> pd.DatetimeIndex:
        return pd.date_range(self.start, self.end, freq="D")

    @property
    def window(self) -> tuple[pd.Timestamp, pd.Timestamp]:
        w = pd.Timedelta(weeks=self.weeks)
        return self.start - w, self.end + w

    def label(self) -> str:
        return f"{self.name} ({self.start:%Y-%m-%d} ~ {self.end:%Y-%m-%d}, {self.emd})"


@dataclass
class Result:
    tool: str
    title: str
    table: pd.DataFrame
    method: str
    data_used: list[str]
    limits: list[str] = field(default_factory=list)
    masked: int = 0
    chart: bytes | None = None
    facts: dict = field(default_factory=dict)   # 요약 문장에 쓰는 핵심 숫자


class ToolError(ValueError):
    pass


# ---------- 공통 ----------

def _num(t: pd.DataFrame, col: str) -> pd.Series:
    return pd.to_numeric(t[col], errors="coerce")


def _png(fig) -> bytes:
    buf = io.BytesIO()
    fig.tight_layout()
    fig.savefig(buf, format="png", dpi=110)
    plt.close(fig)
    return buf.getvalue()


def _pct(a: float, b: float):
    return round((a - b) / b * 100, 1) if b and b == b else None


def _short(day: pd.Timestamp) -> str:
    return f"{day.month}/{day.day}({WEEKDAYS[day.dayofweek]})"


def emd_names(data) -> list[str]:
    p = data.get("pop")
    return sorted(str(x) for x in p.df["emd_nm"].dropna().unique()) if p else []


def _pop_rows(data, emd: str, spec: Spec) -> tuple[Loaded, pd.DataFrame]:
    d = data.get("pop")
    if d is None:
        raise ToolError("유동인구 데이터가 없습니다. '실제 사례 불러오기'를 누르거나, 허브에서 가져오거나, CSV를 넣어 주세요.")
    df = d.df[d.df["emd_nm"].str.contains(emd, regex=False, na=False)]
    if df.empty:
        raise ToolError(f"유동인구 데이터에 '{emd}'이(가) 없습니다. 있는 읍면동: {', '.join(emd_names(data)[:12])}")
    lo, hi = spec.window
    df = df[(df["base_date"] >= lo) & (df["base_date"] <= hi)]
    if not df["base_date"].isin(spec.days).any():
        raise ToolError(f"유동인구 데이터에 축제 기간({spec.start:%Y-%m-%d} ~ {spec.end:%Y-%m-%d})의 날짜가 없습니다.")
    return d, df


def _daily_visit(d: Loaded, df: pd.DataFrame, spec: Spec) -> pd.Series:
    """날짜별 방문 인구. 시간대별 자료면 운영 시간대의 시간 평균, 일별 자료면 하루 합계."""
    if d.hourly:
        df = df[(df["time"] >= spec.hour_from) & (df["time"] <= spec.hour_to)]
        return df.groupby(["base_date", "time"])["visit_pop_cnt"].sum().groupby(level=0).mean()
    return df.groupby("base_date")["visit_pop_cnt"].sum().astype(float)


def _compare(daily: pd.Series, spec: Spec) -> tuple[pd.DataFrame, pd.Series, float | None]:
    """축제일마다 같은 요일 평소 평균을 붙인다. 평소에서는 축제일과 공휴일을 뺀다.

    반환: (축제일 표, 평소로 쓴 날짜들의 값, 평소 변동폭 %)
    """
    lo, hi = spec.window
    hol = holidays()
    base = daily[(daily.index >= lo) & (daily.index <= hi) & ~daily.index.isin(spec.days) & ~daily.index.isin(hol)]
    if base.empty:
        raise ToolError("평소와 비교할 날짜가 없습니다. 축제 전후 기간의 데이터도 함께 넣어 주세요 "
                        f"(권장: {lo:%Y-%m-%d} ~ {hi:%Y-%m-%d}).")
    groups = base.groupby(base.index.dayofweek)
    rows = []
    for d in spec.days:
        if d not in daily.index:
            continue
        b = groups.get_group(d.dayofweek) if d.dayofweek in groups.groups else pd.Series(dtype=float)
        rows.append({"date": d, "fest": float(daily[d]), "base": float(b.mean()) if len(b) else float("nan"),
                     "n_base": int(len(b)), "holiday": d in hol})
    t = pd.DataFrame(rows)
    if t.empty or t["base"].isna().all():
        raise ToolError("같은 요일의 평소 날짜가 부족합니다. 축제 전후 4주가 포함된 데이터를 넣어 주세요.")
    # 평소 변동폭: 요일 차이를 뺀 뒤 평소 날짜들이 흔들리는 정도
    ratio = base / base.groupby(base.index.dayofweek).transform("mean")
    cv = float(ratio.std() * 100) if len(ratio) > 3 else None
    return t, base, cv


def _verdict(up, cv) -> str:
    if up is None or cv is None:
        return "판단 보류"
    if up > 2 * cv:
        return "평소 변동을 넘는 증가"
    if up < -2 * cv:
        return "평소 변동을 넘는 감소"
    return "평소 변동 범위 안"


def _net_verdict(net, cv) -> str:
    if net is None or cv is None:
        return "판단 보류"
    if net > 2 * cv:
        return "대조 지역보다 뚜렷한 증가"
    if net < -2 * cv:
        return "대조 지역보다 뚜렷한 감소"
    return "차이 뚜렷하지 않음"


def _weather(data, spec: Spec, days) -> tuple[dict, str]:
    """날짜별 (강수량, 최대 풍속). 관측소는 지정값 → 읍면동 이름과 같은 관측소 → 전체 평균 순으로 고른다."""
    w = data.get("weather")
    if w is None:
        return {}, ""
    df = w.df[w.df["base_date"].isin(days)]
    if df.empty:
        return {}, ""
    names = set(df["station"].astype(str))
    pick = spec.weather_station if spec.weather_station in names else ""
    if not pick:
        stem = spec.emd[:-1] if spec.emd[-1:] in "읍면동" else spec.emd
        pick = stem if stem in names else ""
    sel = df[df["station"] == pick] if pick else df
    g = sel.groupby("base_date")
    rain = g["daily_rainfall"].mean()
    wind = g["maximum_wind_speed"].max() if "maximum_wind_speed" in sel.columns else pd.Series(dtype=float)
    out = {d: (float(rain[d]) if d in rain.index and rain[d] == rain[d] else None,
               float(wind[d]) if d in wind.index and wind[d] == wind[d] else None) for d in days}
    return out, (f"{pick} 관측소" if pick else "전 관측소 평균")


# ---------- 도구 ----------

def visit_effect(data, spec: Spec, cfg) -> Result:
    """축제 기간의 방문 인구를 같은 요일 평소와 날짜별로 비교한다."""
    d, df = _pop_rows(data, spec.emd, spec)
    daily = _daily_visit(d, df, spec)
    t, base, cv = _compare(daily, spec)
    wx, wx_from = _weather(data, spec, list(t["date"]))
    t["up"] = [_pct(a, b) for a, b in zip(t["fest"], t["base"])]
    f_mean, b_mean = t["fest"].mean(), t["base"].mean()
    uplift = _pct(f_mean, b_mean)
    sig = [x for x, u in zip(t["date"], t["up"]) if u is not None and cv is not None and u > 2 * cv]
    peak = t.loc[t["up"].idxmax()] if t["up"].notna().any() else None
    unit = "시간대 평균" if d.hourly else "하루 합계"

    out = pd.DataFrame({
        "날짜": t["date"].dt.strftime("%Y-%m-%d"), "요일": t["date"].dt.dayofweek.map(lambda i: WEEKDAYS[i]),
        f"축제일 방문 인구({unit})": t["fest"].round(0), "평소(같은 요일 평균)": t["base"].round(0),
        "증가율(%)": t["up"], "판정": [_verdict(u, cv) for u in t["up"]], "평소 비교 일수": t["n_base"]})
    if wx:
        out["강수량(mm)"] = [None if wx[x][0] is None else round(wx[x][0], 1) for x in t["date"]]
        out["최대 풍속(m/s)"] = [None if wx[x][1] is None else round(wx[x][1], 1) for x in t["date"]]
    col = f"축제일 방문 인구({unit})"
    out, m = guard.apply(out, col, [col, "평소(같은 요일 평균)", "증가율(%)"], cfg["min_count"])

    fig, ax = plt.subplots(figsize=(8.8, 4.3))
    lo, hi = spec.window
    s = daily[(daily.index >= lo) & (daily.index <= hi)]
    ax.plot(s.index, s.values, color=C_BASE, lw=1.6, label=f"{spec.emd} 날짜별 방문 인구")
    ax.axvspan(spec.start - pd.Timedelta(hours=12), spec.end + pd.Timedelta(hours=12), color=C_FEST, alpha=0.16,
               label="축제 기간")
    ax.scatter(t["date"], t["fest"], color=C_FEST, zorder=3)
    for x in sig:
        ax.annotate(_short(x), (x, daily[x]), textcoords="offset points", xytext=(0, 7), ha="center", fontsize=8.5)
    hol = [h for h in holidays() if lo <= h <= hi]
    if hol:
        ax.scatter(hol, [daily.get(h, float("nan")) for h in hol], marker="x", color="#7a7a7a", zorder=3,
                   label="공휴일(평소에서 제외)")
    ax.set_ylabel(f"방문 인구({unit})")
    ax.set_title(f"{spec.emd} 방문 인구: {spec.name} 기간과 전후 {spec.weeks}주")
    ax.legend(loc="upper left", fontsize=8.5); ax.spines[["top", "right"]].set_visible(False); fig.autofmt_xdate()

    facts = {"축제 기간 평균": round(f_mean), "평소 평균": round(b_mean), "증가율(%)": uplift,
             "평소 변동폭(%)": round(cv, 1) if cv is not None else None, "판정": _verdict(uplift, cv),
             "평소를 넘게 늘어난 날": ", ".join(_short(x) for x in sig) or "없음",
             "가장 많이 늘어난 날": f"{_short(peak['date'])} {peak['up']:+.1f}%" if peak is not None else "-",
             "비 온 날(1mm 이상)": ", ".join(_short(x) for x in t["date"] if wx and wx[x][0] is not None and wx[x][0] >= 1) or "없음",
             "강풍 날(최대 풍속 14m/s 이상)": ", ".join(_short(x) for x in t["date"] if wx and wx[x][1] is not None and wx[x][1] >= 14) or "없음",
             "날씨 기준": wx_from or "날씨 데이터 없음", "단위": unit}
    limits = ["방문객 '수'가 아니라 통신 데이터로 추정한 방문 인구 지표입니다. 같은 사람이 여러 번 잡힐 수 있어 "
              "절대값보다 평소 대비 증가율로 봐야 합니다.",
              "읍면동 전체 값이라 축제장 밖의 유동인구가 섞여 있습니다. 축제장이 읍면동에서 차지하는 비중이 작으면 효과가 작게 보입니다.",
              "같은 기간의 다른 행사·날씨 영향을 완전히 분리하지 못합니다. 대조 지역 비교로 일부를 걸러 냅니다."]
    method = (f"{spec.emd}의 방문 인구(visit_pop_cnt)를 날짜별 {unit}로 구했습니다. 평소는 축제 전후 {spec.weeks}주 안의 "
              "같은 요일 평균이며, 축제일과 공휴일은 뺐습니다. 평소 변동폭은 요일 차이를 뺀 뒤 평소 날짜들이 흔들리는 "
              "정도(표준편차)이고, 증가율이 그 2배를 넘으면 '평소 변동을 넘는 증가'로 판정합니다.")
    used = [f"{d.name} ({d.source})"] + ([f"{data['weather'].name} ({data['weather'].source}, {wx_from})"] if wx else [])
    return Result("visit_effect", f"방문 효과: {spec.label()}", out, method, used, limits, m, _png(fig), facts)


def control_compare(data, spec: Spec, cfg) -> Result:
    """대조 지역(이웃 읍면동)과 같은 날짜의 증가율을 비교해, 축제 지역에만 생긴 변화인지 본다."""
    if not spec.control:
        raise ToolError("대조 지역을 정하지 않았습니다.")
    d, df_f = _pop_rows(data, spec.emd, spec)
    _, df_c = _pop_rows(data, spec.control, spec)
    tf, base_f, cv_f = _compare(_daily_visit(d, df_f, spec), spec)
    tc, base_c, cv_c = _compare(_daily_visit(d, df_c, spec), spec)
    # 순증가의 평소 변동폭: 평소 날짜마다 (축제 지역 - 대조 지역) 요일 보정 증가율을 구해 그 흔들림을 본다
    rf = base_f / base_f.groupby(base_f.index.dayofweek).transform("mean")
    rc = base_c / base_c.groupby(base_c.index.dayofweek).transform("mean")
    both = (rf - rc).dropna() * 100
    cv_net = float(both.std()) if len(both) > 3 else None
    j = tf.merge(tc, on="date", suffixes=("_f", "_c"))
    j["up_f"] = [_pct(a, b) for a, b in zip(j["fest_f"], j["base_f"])]
    j["up_c"] = [_pct(a, b) for a, b in zip(j["fest_c"], j["base_c"])]
    j["net"] = [None if a is None or b is None else round(a - b, 1) for a, b in zip(j["up_f"], j["up_c"])]
    out = pd.DataFrame({"날짜": j["date"].dt.strftime("%Y-%m-%d"), "요일": j["date"].dt.dayofweek.map(lambda i: WEEKDAYS[i]),
                        f"{spec.emd} 증가율(%)": j["up_f"], f"{spec.control} 증가율(%)": j["up_c"],
                        "순증가(%p)": j["net"], "판정": [_net_verdict(x, cv_net) for x in j["net"]],
                        "_base": j["fest_f"]})
    out, m = guard.apply(out, "_base", [f"{spec.emd} 증가율(%)", "순증가(%p)"], cfg["min_count"])
    out = out.drop(columns="_base")
    net_mean = round(pd.Series([x for x in j["net"] if x is not None]).mean(), 1) if j["net"].notna().any() else None
    best = j.loc[j["net"].astype(float).idxmax()] if j["net"].notna().any() else None

    fig, ax = plt.subplots(figsize=(8.8, 4.0))
    x = range(len(j)); wd = 0.38
    ax.bar([i - wd / 2 for i in x], j["up_c"].fillna(0), wd, color=C_CTRL, alpha=0.75, label=f"{spec.control}(대조)")
    ax.bar([i + wd / 2 for i in x], j["up_f"].fillna(0), wd, color=C_FEST, label=f"{spec.emd}(축제 지역)")
    ax.axhline(0, color="#555", lw=0.8)
    ax.set_xticks(list(x)); ax.set_xticklabels([_short(dd) for dd in j["date"]])
    ax.set_ylabel("같은 요일 평소 대비 증가율(%)"); ax.set_title("축제 지역과 대조 지역의 날짜별 증가율")
    ax.legend(fontsize=9); ax.spines[["top", "right"]].set_visible(False)
    sig = [dd for dd, x in zip(j["date"], j["net"]) if x is not None and cv_net is not None and x > 2 * cv_net]
    facts = {"대조 지역": spec.control, "평균 순증가(%p)": net_mean,
             "순증가 평소 변동폭(%p)": round(cv_net, 1) if cv_net is not None else None,
             "순증가가 뚜렷한 날": ", ".join(_short(x) for x in sig) or "없음",
             "_sig_days": sig,
             "순증가가 가장 큰 날": f"{_short(best['date'])} {best['net']:+.1f}%p" if best is not None else "-",
             "대조 지역 평소 변동폭(%)": round(cv_c, 1) if cv_c is not None else None}
    return Result("control_compare", f"대조 지역 비교: {spec.emd} vs {spec.control}", out,
                  "두 읍면동에 같은 방법(같은 요일 평소 대비 증가율)을 적용하고, 축제 지역 증가율에서 대조 지역 증가율을 뺀 "
                  "값을 '순증가'로 봤습니다. 같은 날 제주 전체에 생긴 변화(날씨, 관광 수요)는 두 지역에 함께 나타나므로 "
                  "순증가가 축제 지역에만 생긴 변화에 더 가깝습니다. 평소 날짜들에서도 같은 방식으로 순증가를 구해 그 "
                  "흔들림(표준편차)을 '순증가 평소 변동폭'으로 삼고, 그 2배를 넘으면 '대조 지역보다 뚜렷한 증가'로 판정합니다.",
                  [f"{d.name} ({d.source})"],
                  ["대조 지역은 성격이 비슷한 이웃 읍면동을 고른 것이며, 완전히 같은 조건은 아닙니다."], m, _png(fig), facts)


def hourly_profile(data, spec: Spec, cfg) -> Result:
    """시간대별 방문 인구: 축제 기간 평균과 평소(같은 요일) 평균. 시간대별 자료(센터 CSV)일 때만."""
    d, df = _pop_rows(data, spec.emd, spec)
    if not d.hourly:
        raise ToolError("일별 자료라 시간대 분석은 건너뜁니다. 센터의 시간대별 유동인구 CSV를 넣으면 볼 수 있습니다.")
    hourly = df.groupby(["base_date", "time"])["visit_pop_cnt"].sum().unstack("time")
    hol = holidays()
    fest = hourly[hourly.index.isin(spec.days)]
    base = hourly[~hourly.index.isin(spec.days) & ~hourly.index.isin(hol)
                  & hourly.index.dayofweek.isin(set(spec.days.dayofweek))]
    if fest.empty or base.empty:
        raise ToolError("시간대별 비교에 필요한 날짜가 부족합니다.")
    f, b = fest.mean(), base.mean()
    t = pd.DataFrame({"시간대": [f"{h:02d}시" for h in f.index], "축제 기간 평균": f.round(0).values,
                      "평소 평균": b.reindex(f.index).round(0).values})
    t["증가율(%)"] = [_pct(x, y) for x, y in zip(t["축제 기간 평균"], t["평소 평균"])]
    peak = t.loc[(t["축제 기간 평균"] - t["평소 평균"]).idxmax()]
    facts = {"가장 많이 늘어난 시간대": peak["시간대"], "그 시간대 증가율(%)": peak["증가율(%)"]}
    t, m = guard.apply(t, "축제 기간 평균", ["축제 기간 평균", "평소 평균", "증가율(%)"], cfg["min_count"])
    fig, ax = plt.subplots(figsize=(8.8, 4.2))
    hours = t["시간대"].str[:2].astype(int)
    ax.plot(hours, _num(t, "평소 평균"), color=C_BASE, marker="o", ms=3, label="평소 평균")
    ax.plot(hours, _num(t, "축제 기간 평균"), color=C_FEST, marker="o", ms=3, label="축제 기간 평균")
    ax.set_xticks(range(0, 24, 2)); ax.set_xlabel("시간대(시)"); ax.set_ylabel("방문 인구")
    ax.set_title("시간대별 방문 인구"); ax.legend(); ax.spines[["top", "right"]].set_visible(False)
    return Result("hourly_profile", "시간대별 방문 인구", t,
                  "시간대별 방문 인구 합계를 축제 기간의 날들과, 전후 기간 중 같은 요일인 날들(공휴일 제외)에 대해 각각 평균했습니다.",
                  [f"{d.name} ({d.source})"], ["운영 시간과 겹치는 시간대의 증가가 축제 효과일 가능성이 높습니다."], m, _png(fig), facts)


def visitor_mix(data, spec: Spec, cfg, days=None) -> Result:
    """방문 인구 구성(성별·연령대, 있으면 거주지): 축제일과 평소의 비중 비교."""
    d, df = _pop_rows(data, spec.emd, spec)
    if d.hourly:
        df = df[(df["time"] >= spec.hour_from) & (df["time"] <= spec.hour_to)]
    target = pd.DatetimeIndex(days) if days is not None and len(days) else spec.days
    hol = holidays()
    is_f = df["base_date"].isin(target)
    same_dow = df["base_date"].dt.dayofweek.isin(set(target.dayofweek))
    fest = df[is_f]
    base = df[~df["base_date"].isin(spec.days) & ~df["base_date"].isin(hol) & same_dow]
    if fest.empty or base.empty:
        raise ToolError("구성 비교에 필요한 날짜가 부족합니다.")
    cols = [("resd", "거주지")] if df["resd"].notna().any() else []
    cols += [("sex", "성별"), ("age_band", "연령대")]
    rows = []
    for col, label in cols:
        f, b = fest.groupby(col)["visit_pop_cnt"].sum(), base.groupby(col)["visit_pop_cnt"].sum()
        fs, bs = f / f.sum() * 100, b / b.sum() * 100
        fd = f / fest["base_date"].nunique()
        bd = b / base["base_date"].nunique()
        for k in sorted(f.index, key=str):
            rows.append({"구분": label, "항목": k, "축제일 비중(%)": round(fs[k], 1),
                         "평소 비중(%)": round(bs.get(k, float("nan")), 1),
                         "비중 차이(%p)": round(fs[k] - bs.get(k, float("nan")), 1) + 0.0,
                         "인원 증가율(%)": _pct(fd[k], bd.get(k, float("nan"))), "_base": float(f[k])})
    t = pd.DataFrame(rows)
    top = t.loc[t["인원 증가율(%)"].astype(float).idxmax()]
    ages = t[t["구분"] == "연령대"]
    topage = ages.loc[ages["인원 증가율(%)"].astype(float).idxmax()]
    facts = {"가장 많이 늘어난 집단": f"{top['구분']} {top['항목']}", "그 집단 증가율(%)": top["인원 증가율(%)"],
             "가장 많이 늘어난 연령대": topage["항목"], "그 연령대 증가율(%)": topage["인원 증가율(%)"],
             "대상 날짜": ", ".join(_short(x) for x in target)}
    t, m = guard.apply(t, "_base", ["축제일 비중(%)", "평소 비중(%)", "비중 차이(%p)", "인원 증가율(%)"], cfg["min_count"])
    t = t.drop(columns="_base")
    ages = t[t["구분"] == "연령대"]
    fig, ax = plt.subplots(figsize=(8.8, 4.0))
    ax.bar(ages["항목"], _num(ages, "인원 증가율(%)").fillna(0), color=C_FEST)
    ax.axhline(0, color="#555", lw=0.8)
    ax.set_ylabel("같은 요일 평소 대비 증가율(%)"); ax.set_title("연령대별 방문 인구 증가율")
    ax.spines[["top", "right"]].set_visible(False)
    return Result("visitor_mix", "누가 더 왔나: 성별·연령대", t,
                  f"방문 인구를 성별·연령대별로 합쳐, 대상 날짜({facts['대상 날짜']})와 평소(전후 기간의 같은 요일, 공휴일 제외)의 "
                  "하루 평균을 비교했습니다. 비중은 전체 중 차지하는 몫, 인원 증가율은 그 집단 자체가 얼마나 늘었는지입니다.",
                  [f"{d.name} ({d.source})"],
                  ["축제일만 따로 보려고, 평소를 넘게 늘어난 날이 있으면 그 날들만 대상으로 삼습니다."], m, _png(fig), facts)


def bus_effect(data, spec: Spec, cfg) -> Result:
    """인근 정류소의 버스 승하차를 평소와 비교한다."""
    d = data.get("bus")
    if d is None:
        raise ToolError("버스 비교를 하려면 '버스 정류소별 이용 현황' CSV도 넣어 주세요.")
    if not spec.stations:
        raise ToolError("버스 비교를 하려면 축제장 인근 정류소 이름(일부)을 적어 주세요.")
    mask = pd.Series(False, index=d.df.index)
    for kw in spec.stations:
        mask |= d.df["bus_station_name"].str.contains(kw, regex=False, na=False)
    df = d.df[mask]
    if df.empty:
        raise ToolError(f"이름에 {', '.join(spec.stations)}이(가) 들어간 정류소가 없습니다.")
    daily = df.groupby("base_date")["user_count"].sum().astype(float)
    t, _, cv = _compare(daily, spec)
    out = pd.DataFrame({
        "날짜": t["date"].dt.strftime("%Y-%m-%d"), "요일": t["date"].dt.dayofweek.map(lambda i: WEEKDAYS[i]),
        "축제일 승하차": t["fest"].round(0), "평소(같은 요일 평균)": t["base"].round(0),
        "증가율(%)": [_pct(a, b) for a, b in zip(t["fest"], t["base"])]})
    facts = {"증가율(%)": _pct(t["fest"].mean(), t["base"].mean()), "대상 정류소 수": int(df["bus_station_name"].nunique())}
    out, m = guard.apply(out, "축제일 승하차", ["축제일 승하차", "평소(같은 요일 평균)", "증가율(%)"], cfg["min_count"])
    fig, ax = plt.subplots(figsize=(8.8, 4.0))
    x = range(len(out)); wd = 0.38
    ax.bar([i - wd / 2 for i in x], _num(out, "평소(같은 요일 평균)").fillna(0), wd, color=C_BASE, label="평소")
    ax.bar([i + wd / 2 for i in x], _num(out, "축제일 승하차").fillna(0), wd, color=C_FEST, label="축제일")
    ax.set_xticks(list(x)); ax.set_xticklabels(out["날짜"].str[5:] + "(" + out["요일"] + ")")
    ax.set_ylabel("승하차 인원(명)"); ax.set_title("인근 정류소 버스 승하차"); ax.legend()
    ax.spines[["top", "right"]].set_visible(False)
    names = ", ".join(sorted(df["bus_station_name"].unique())[:8])
    return Result("bus_effect", "대중교통 이용: 인근 정류소 승하차", out,
                  f"이름에 {', '.join(spec.stations)}이(가) 들어간 정류소({names})의 승하차 인원을 날짜별로 합쳐 "
                  "같은 요일 평소 평균(공휴일 제외)과 비교했습니다.",
                  [f"{d.name} ({d.source})"], ["교통카드 태그 기준이라 현금 승차와 자가용·렌터카 방문은 빠져 있습니다."],
                  m, _png(fig), facts)


TOOLS = {
    "visit_effect": (visit_effect, "축제 기간 방문 인구를 평소와 날짜별로 비교하고 판정"),
    "control_compare": (control_compare, "이웃 읍면동(대조 지역)과 증가율을 비교해 축제 지역에만 생긴 변화인지 확인"),
    "hourly_profile": (hourly_profile, "시간대별 방문 인구 비교(센터 시간대별 자료일 때)"),
    "visitor_mix": (visitor_mix, "성별·연령대별 방문 인구 변화"),
    "bus_effect": (bus_effect, "인근 정류소 버스 승하차 비교(정류소 이름 필요)"),
}


def run(tool: str, data: dict, spec: Spec, cfg: dict) -> Result:
    if tool not in TOOLS:
        raise ToolError(f"알 수 없는 도구: {tool}")
    return TOOLS[tool][0](data, spec, cfg)


def prescription(spec: Spec) -> list[dict]:
    """이 축제를 검증하려면 무엇이 필요한지 알려 준다."""
    lo, hi = spec.window
    months = ", ".join(sorted({f"{d:%Y-%m}" for d in pd.date_range(lo, hi, freq="D")}))
    emds = spec.emd + (f", {spec.control}(대조)" if spec.control else "")
    return [
        {"데이터": "유동인구 (필수)", "기간": f"{lo:%Y-%m-%d} ~ {hi:%Y-%m-%d}", "조건": f"읍면동 = {emds}",
         "자동으로 가져오기(허브 키 필요)": "읍면동 단위 내국인 유동인구 API",
         "센터에서 직접 받을 때": f"내국인 유동인구(읍면동)_v02, {months}"},
        {"데이터": "날씨 (권장)", "기간": f"{lo:%Y-%m-%d} ~ {hi:%Y-%m-%d}", "조건": "없음",
         "자동으로 가져오기(허브 키 필요)": "일별 기상 정보 API (허브 제공 기간 안일 때)",
         "센터에서 직접 받을 때": f"일일 날씨 정보, {months}"},
        {"데이터": "버스 (선택)", "기간": f"{lo:%Y-%m-%d} ~ {hi:%Y-%m-%d}", "조건": "인근 정류소 이름",
         "자동으로 가져오기(허브 키 필요)": "지원 안 함 (하루 수천 행이라 센터 CSV 권장)",
         "센터에서 직접 받을 때": f"버스 정류소별 이용 현황, {months}"},
    ]
