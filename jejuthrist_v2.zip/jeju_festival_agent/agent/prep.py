"""다음 축제 준비 도구: 날씨 위험과 대중교통 수요.

성과 검증 도구(tools.py)가 '지난 축제에 무엇이 달라졌나'를 본다면, 이 모듈은 '다음 축제를 어떻게 준비할까'에
필요한 근거 숫자를 만든다. 모두 실제로 잰 값(강수량·풍속)과 실제로 센 값(교통카드 승차)만 쓴다.

  weather_risk : 행사장에서 가장 가까운 관측소의 여러 해 같은 시기 기록으로 비·강풍 날 수를 센다.
  bus_demand   : 지난 같은 축제 때 행사장 근처 정류소 승차 인원을 같은 요일 평소와 비교한다.

데이터는 scripts/fetch_prep_data.py 가 제주데이터허브에서 받아 data/prep/ 에 저장한 CSV를 읽는다.
  - 기상관측소 정보, 일별 기상 정보, 버스 정류소 기본 정보, 일일 정류소별 버스 이용자 정보
"""
from __future__ import annotations

import math
import os
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd

from . import guard
from .datasets import WEEKDAYS
from .tools import C_BASE, C_FEST, Result, ToolError, _png, _short

PREP_DIR = Path(__file__).resolve().parent.parent / "data" / "prep"
RAIN_MM = 1.0      # 비 온 날 기준(일강수량)
WIND_MS = 14.0     # 강풍 기준(최대풍속). 육상 강풍주의보의 풍속 기준 14m/s 를 참고
HUB = "제주데이터허브"


@dataclass
class PrepSpec:
    """준비할 행사 한 건."""
    name: str
    place: str                       # 행사장 이름 (예: 새별오름). 정류소 이름으로 위치를 찾는다
    wx_from: str                     # 날씨를 볼 기간 시작 'MM-DD'
    wx_to: str                       # 날씨를 볼 기간 끝 'MM-DD'
    ref_start: pd.Timestamp | None = None   # 비교할 지난 축제 기간(버스 수요용)
    ref_end: pd.Timestamp | None = None
    radius_km: float = 2.0
    weeks: int = 2                   # 평소로 볼 전후 주 수
    lat: float | None = None
    lon: float | None = None

    @property
    def ref_days(self) -> list[pd.Timestamp]:
        if self.ref_start is None or self.ref_end is None:
            return []
        return list(pd.date_range(self.ref_start, self.ref_end, freq="D"))


def _km(lat1, lon1, lat2, lon2) -> float:
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp, dl = p2 - p1, math.radians(lon2 - lon1)
    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * 6371.0 * math.asin(math.sqrt(a))


def _norm(x) -> str:
    return str(x).replace(" ", "")


def in_window(md: pd.Series, a: str, b: str) -> pd.Series:
    """'MM-DD' 기간 안인지. 12-23~01-08 처럼 해를 넘기는 기간도 된다."""
    return (md >= a) & (md <= b) if a <= b else (md >= a) | (md <= b)


def _read(path: Path) -> pd.DataFrame:
    return pd.read_csv(path, dtype=str, encoding="utf-8-sig")


@lru_cache(maxsize=8)
def _read_dir(folder: str) -> pd.DataFrame:
    files = sorted(Path(folder).glob("*.csv"))
    frames = []
    for f in files:
        if f.stat().st_size < 10:
            continue
        d = _read(f)
        if "empty" not in d.columns and len(d):
            frames.append(d)
    return pd.concat(frames, ignore_index=True) if frames else pd.DataFrame()


def available(prep_dir: Path = PREP_DIR) -> dict:
    """받아 둔 준비 데이터 현황 (화면 표시용)."""
    out = {}
    for key, sub, col in (("weather", "weather", "baseDate"), ("bus", "bus", "baseDate")):
        d = _read_dir(str(prep_dir / sub))
        out[key] = (f"{d[col].min()} ~ {d[col].max()} ({d[col].nunique()}일)" if not d.empty else "없음")
    for key, f in (("stations", "bus_stations.csv"), ("observatories", "observatories.csv")):
        out[key] = "있음" if (prep_dir / f).exists() else "없음"
    return out


def locate(spec: PrepSpec, prep_dir: Path = PREP_DIR) -> tuple[float, float, str]:
    """행사장 위치를 정한다. 좌표가 있으면 그대로, 없으면 이름이 같은 버스 정류소의 위치를 쓴다."""
    if spec.lat is not None and spec.lon is not None:
        return spec.lat, spec.lon, "입력한 좌표"
    p = prep_dir / "bus_stations.csv"
    if not p.exists():
        raise ToolError("정류소 위치 자료가 없습니다. scripts\\fetch_prep_data.py 를 먼저 실행해 주세요.")
    st = _read(p)
    key = _norm(spec.place)
    hit = st[st["stationName"].map(_norm) == key]
    if hit.empty:
        hit = st[st["stationName"].map(_norm).str.contains(key, regex=False, na=False)]
    hit = hit.assign(lat=pd.to_numeric(hit["latitude"], errors="coerce"),
                     lon=pd.to_numeric(hit["longitude"], errors="coerce")).dropna(subset=["lat", "lon"])
    if hit.empty:
        raise ToolError(f"'{spec.place}' 이름의 정류소가 없어 행사장 위치를 찾지 못했습니다. "
                        "행사장 바로 앞 정류소 이름(예: 새별오름, 탐라광장)을 적어 주세요.")
    return float(hit["lat"].mean()), float(hit["lon"].mean()), f"정류소 '{hit['stationName'].iloc[0]}' 위치"


# ---------- 날씨 위험 ----------

def weather_risk(spec: PrepSpec, cfg: dict, prep_dir: Path = PREP_DIR) -> Result:
    lat, lon, how = locate(spec, prep_dir)
    wx = _read_dir(str(prep_dir / "weather"))
    obs_p = prep_dir / "observatories.csv"
    if wx.empty or not obs_p.exists():
        raise ToolError("날씨 자료가 없습니다. scripts\\fetch_prep_data.py 로 일별 기상 정보를 받아 주세요.")
    ob = _read(obs_p)
    md_all = pd.to_datetime(wx["baseDate"], format="%Y%m%d", errors="coerce").dt.strftime("%m-%d")
    in_win = wx[in_window(md_all, spec.wx_from, spec.wx_to)]
    if in_win.empty:
        raise ToolError(f"받아 둔 날씨 자료에 {spec.wx_from}~{spec.wx_to} 기간이 없습니다. "
                        "scripts\\fetch_prep_data.py 로 이 기간의 일별 기상 정보를 받아 주세요.")
    ob = ob[ob["observatoryName"].isin(set(in_win["observatoryName"]))].copy()
    ob["dist"] = [_km(lat, lon, float(a), float(b)) for a, b in zip(ob["latitude"], ob["longitude"])]
    ob = ob.sort_values("dist")
    if ob.empty:
        raise ToolError("받은 날씨 자료에 위치를 아는 관측소가 없습니다.")
    name, dist = ob.iloc[0]["observatoryName"], float(ob.iloc[0]["dist"])

    w = wx[wx["observatoryName"] == name].drop_duplicates(["baseDate"]).copy()
    w["d"] = pd.to_datetime(w["baseDate"], format="%Y%m%d", errors="coerce")
    w["rain"] = pd.to_numeric(w["dailyRainfall"], errors="coerce")
    w["wind"] = pd.to_numeric(w["maximumWindSpeed"], errors="coerce")
    w["md"] = w["d"].dt.strftime("%m-%d")
    w = w[in_window(w["md"], spec.wx_from, spec.wx_to)].dropna(subset=["d"])
    if w.empty:
        raise ToolError(f"{name} 관측소의 {spec.wx_from}~{spec.wx_to} 기록이 없습니다.")
    w["is_rain"], w["is_wind"] = w["rain"] >= RAIN_MM, w["wind"] >= WIND_MS
    w["is_bad"] = w["is_rain"] | w["is_wind"]
    if spec.wx_from > spec.wx_to:   # 해를 넘기는 기간은 시작한 해로 묶는다 (12/30~1/1 → 한 철)
        season = w["d"].dt.year - (w["md"] <= spec.wx_to).astype(int)
    else:
        season = w["d"].dt.year
    years = sorted(season.unique())
    ny = len(years)

    # 날짜(월-일)마다 '몇 해 중 몇 해' 비·강풍이었나
    by_md = w.groupby("md").agg(n=("d", "count"), rain=("is_rain", "sum"), wind=("is_wind", "sum"),
                                bad=("is_bad", "sum"), maxwind=("wind", "max")).reset_index()
    if spec.wx_from > spec.wx_to:   # 해를 넘기는 기간은 12월 → 1월 순서로
        by_md = pd.concat([by_md[by_md["md"] >= spec.wx_from], by_md[by_md["md"] <= spec.wx_to]], ignore_index=True)
    table = pd.DataFrame({
        "날짜": by_md["md"].str.replace("-", "/"),
        "기록 연수": by_md["n"].astype(int),
        "비 온 해": by_md["rain"].astype(int),
        "강풍 해": by_md["wind"].astype(int),
        "비 또는 강풍 비율(%)": (by_md["bad"] / by_md["n"] * 100).round(0),
        "가장 센 바람(m/s)": by_md["maxwind"].round(1),
    })
    tot = len(w)
    rain_d, wind_d = int(w["is_rain"].sum()), int(w["is_wind"].sum())
    bad_rate = by_md["bad"] / by_md["n"]
    safest = by_md.loc[bad_rate.nsmallest(3).index, "md"].str.replace("-", "/").tolist()
    riskiest = by_md.loc[bad_rate.nlargest(3).index, "md"].str.replace("-", "/").tolist()
    top = w.loc[w["wind"].idxmax()] if w["wind"].notna().any() else None
    facts = {"관측소": name, "행사장과 거리(km)": round(dist, 1), "기록 연도": f"{years[0]}~{years[-1]} ({ny}년)",
             "기록 연수": ny, "본 기간": f"{spec.wx_from}~{spec.wx_to}", "전체 관측일": tot,
             "비 온 날 비율(%)": round(rain_d / tot * 100), "강풍 날 비율(%)": round(wind_d / tot * 100),
             "비 또는 강풍 날 비율(%)": round(int(w["is_bad"].sum()) / tot * 100),
             "비·강풍이 가장 적었던 날": ", ".join(safest), "비·강풍이 가장 잦았던 날": ", ".join(riskiest)}
    if top is not None:
        facts["이 기간 가장 센 바람(m/s)"] = round(float(top["wind"]), 1)
        facts["가장 센 바람이 분 날"] = f"{top['d']:%Y-%m-%d}"
    # 지난 축제 기간의 실제 날씨
    if spec.ref_days:
        past = w[w["d"].isin(spec.ref_days)]
        if not past.empty:
            facts["지난 축제 기간 실제 날씨"] = ", ".join(
                f"{_short(r.d)} 비 {r.rain:.1f}mm·바람 {r.wind:.1f}m/s" for r in past.itertuples())
            windy = past[past["is_wind"]]
            facts["지난 축제 기간 강풍 날"] = ", ".join(
                f"{_short(r.d)} {r.wind:.1f}m/s" for r in windy.itertuples()) or "없음"

    fig, ax = plt.subplots(figsize=(8.8, 3.8))
    x = range(len(table))
    ax.bar(x, (by_md["wind"] / by_md["n"] * 100), color=C_FEST, label=f"강풍(최대풍속 {WIND_MS:.0f}m/s 이상)")
    ax.plot(list(x), (by_md["rain"] / by_md["n"] * 100), color="#2a6fb0", marker="o", label=f"비({RAIN_MM:.0f}mm 이상)")
    ax.set_xticks(list(x)); ax.set_xticklabels(table["날짜"], rotation=45, fontsize=8)
    ax.set_ylabel(f"{ny}년 중 해당한 해의 비율(%)"); ax.set_ylim(0, 100)
    ax.set_title(f"{name} 관측소 · 날짜별 비·강풍 빈도 ({years[0]}~{years[-1]})"); ax.legend(fontsize=8)
    ax.spines[["top", "right"]].set_visible(False)
    return Result(
        "weather_risk", f"날씨 위험: {spec.place} 주변 {spec.wx_from}~{spec.wx_to}", table,
        f"행사장 위치({how})에서 가장 가까운 관측소({name}, {dist:.1f}km)의 {ny}년치 일별 기록에서 "
        f"일강수량 {RAIN_MM:.0f}mm 이상인 날을 '비', 최대풍속 {WIND_MS:.0f}m/s 이상인 날을 '강풍'으로 세었습니다.",
        [f"일별 기상 정보 ({HUB})", f"기상관측소 정보 ({HUB})", f"버스 정류소 기본 정보 ({HUB}, 행사장 위치)"],
        ["과거 빈도이지 예보가 아닙니다. 행사 직전에는 기상청 예보를 함께 보세요.",
         f"관측소가 처음 생긴 해부터만 기록이 있어 관측소마다 연수가 다를 수 있습니다 (여기서는 {ny}년).",
         "최대풍속은 10분 평균 풍속의 최댓값이라 순간 돌풍보다 낮게 나옵니다.",
         "날짜별 비율은 해마다 한 번씩만 세므로, 날짜끼리 1~2해 차이는 우연일 수 있습니다."],
        0, _png(fig), facts)


# ---------- 대중교통 수요 ----------

BUS_SEATS = int(os.environ.get("BUS_SEATS", "40"))   # 증차 참고 계산에 쓰는 버스 한 대 인원


def _near_station_names(lat, lon, radius_km, prep_dir: Path) -> pd.DataFrame:
    st = _read(prep_dir / "bus_stations.csv")
    st["lat"] = pd.to_numeric(st["latitude"], errors="coerce")
    st["lon"] = pd.to_numeric(st["longitude"], errors="coerce")
    st = st.dropna(subset=["lat", "lon"])
    st["dist"] = [_km(lat, lon, a, b) for a, b in zip(st["lat"], st["lon"])]
    return st[st["dist"] <= radius_km].sort_values("dist")


def bus_demand(spec: PrepSpec, cfg: dict, prep_dir: Path = PREP_DIR) -> Result:
    if not spec.ref_days:
        raise ToolError("대중교통 수요를 보려면 비교할 지난 축제 기간(시작일·종료일)을 적어 주세요.")
    lat, lon, how = locate(spec, prep_dir)
    radius, radius_note = spec.radius_km, ""
    near = _near_station_names(lat, lon, radius, prep_dir)
    if len(near) > 15:   # 도심은 정류소가 빽빽해 축제와 무관한 승차가 섞인다 → 가까운 곳만 남긴다
        radius = 0.5
        near = _near_station_names(lat, lon, radius, prep_dir)
        radius_note = f" 반경 {spec.radius_km}km 안에 정류소가 너무 많아(도심) 반경을 {radius}km로 줄였습니다."
    if near.empty:
        raise ToolError(f"행사장 반경 {radius}km 안에 버스 정류소가 없습니다.")
    bus = _read_dir(str(prep_dir / "bus"))
    if bus.empty:
        raise ToolError("버스 이용 자료가 없습니다. scripts\\fetch_prep_data.py 로 받아 주세요.")
    # 이용 데이터의 정류소ID(7자리)와 정류소 기본 정보의 ID(9자리)는 체계가 달라 이름으로 맞춘다.
    names = set(near["stationName"].map(_norm))
    bus = bus.assign(d=pd.to_datetime(bus["baseDate"], format="%Y%m%d", errors="coerce"),
                     n=pd.to_numeric(bus["userCount"], errors="coerce").fillna(0))
    have_days = set(bus["d"].dropna())
    loc = bus[bus["stationName"].map(_norm).isin(names)]
    daily = loc.groupby("d")["n"].sum().reindex(sorted(have_days), fill_value=0)
    used_names = sorted(loc["stationName"].unique())

    fest = set(spec.ref_days)
    if not fest & have_days:
        raise ToolError(f"지난 축제 기간({spec.ref_start:%Y-%m-%d}~{spec.ref_end:%Y-%m-%d})의 버스 자료를 아직 받지 않았습니다. "
                        "scripts\\fetch_prep_data.py 로 그 기간과 전후 같은 요일 자료를 받아 주세요.")
    rows = []
    for d in spec.ref_days:
        if d not in have_days:
            rows.append({"날짜": f"{d:%Y-%m-%d}", "요일": WEEKDAYS[d.dayofweek], "축제일 승차": None,
                         "평소(같은 요일 평균)": None, "늘어난 인원": None, "평소 비교 일수": 0, "판정": "자료 없음"})
            continue
        base = [d + pd.Timedelta(weeks=s * k) for k in range(1, spec.weeks + 1) for s in (-1, 1)]
        base = [b for b in base if b in have_days and b not in fest]
        bv = daily.reindex(base).astype(float)
        m = float(bv.mean()) if len(bv) else float("nan")
        sd = float(bv.std(ddof=1)) if len(bv) >= 2 else float("nan")
        v = float(daily.get(d, 0))
        extra = v - m if m == m else None
        if len(bv) < 2:
            verdict = "평소 자료 부족"
        elif extra is not None and extra > max(2 * (sd if sd == sd else 0), 0.3 * m):
            verdict = "평소보다 뚜렷이 많음" + (" (참고: 평소 2일 비교)" if len(bv) == 2 else "")
        else:
            verdict = "평소 범위"
        rows.append({"날짜": f"{d:%Y-%m-%d}", "요일": WEEKDAYS[d.dayofweek], "축제일 승차": round(v),
                     "평소(같은 요일 평균)": round(m) if m == m else None,
                     "늘어난 인원": round(extra) if extra is not None else None,
                     "평소 비교 일수": len(bv), "판정": verdict})
    out = pd.DataFrame(rows)
    ok = out[out["판정"].str.startswith("평소보다 뚜렷이")]
    max_extra = int(ok["늘어난 인원"].max()) if not ok.empty else 0
    bus_key = f"참고 증차(버스 1대 {BUS_SEATS}명 기준, 하루)"
    facts = {"근처 정류소": ", ".join(used_names) or "없음", "반경(km)": radius,
             "평소보다 뚜렷이 많았던 날": ", ".join(_short(pd.Timestamp(x)) for x in ok["날짜"]) or "없음",
             "하루 최대 추가 승차(명)": max_extra,
             bus_key: math.ceil(max_extra / BUS_SEATS) if max_extra else 0}
    if not ok.empty:   # 가장 많이 늘어난 날의 실제 승차와 평소 (대상별 문장에 쓴다)
        top = ok.loc[ok["늘어난 인원"].idxmax()]
        facts["가장 많이 늘어난 날"] = _short(pd.Timestamp(top["날짜"]))
        facts["그날 승차(명)"] = int(top["축제일 승차"])
        facts["그날 평소(명)"] = int(top["평소(같은 요일 평균)"])
        if top["평소(같은 요일 평균)"]:
            facts["평소 대비 배율"] = round(float(top["축제일 승차"]) / float(top["평소(같은 요일 평균)"]), 1)
        facts["판정 참고용 여부"] = "예" if ok["판정"].str.contains("참고").any() else "아니오"
    out, masked = guard.apply(out.fillna({"축제일 승차": 0}), "축제일 승차",
                              ["축제일 승차", "평소(같은 요일 평균)", "늘어난 인원"], cfg["min_count"])

    fig, ax = plt.subplots(figsize=(8.8, 3.8))
    x = list(range(len(rows)))
    wd = 0.38
    ax.bar([i - wd / 2 for i in x], [r["평소(같은 요일 평균)"] or 0 for r in rows], wd, color=C_BASE, label="평소(같은 요일)")
    ax.bar([i + wd / 2 for i in x], [r["축제일 승차"] or 0 for r in rows], wd, color=C_FEST, label="지난 축제일")
    ax.set_xticks(x); ax.set_xticklabels([f"{r['날짜'][5:]}({r['요일']})" for r in rows])
    ax.set_ylabel("승차 인원(명)"); ax.set_title(f"{spec.place} 반경 {radius}km 정류소 버스 승차"); ax.legend()
    ax.spines[["top", "right"]].set_visible(False)
    return Result(
        "bus_demand", f"대중교통 수요: 지난 축제 때 {spec.place} 근처 버스 승차", out,
        f"행사장 위치({how}) 반경 {radius}km 안의 정류소({', '.join(used_names[:8])})에서 교통카드로 승차한 인원을 "
        f"날짜별로 합쳐, 전후 {spec.weeks}주 같은 요일 평소 평균과 비교했습니다. 늘어난 인원이 평소 흔들림(표준편차)의 2배와 "
        "평소의 30%를 모두 넘으면 '뚜렷이 많음'으로 봅니다." + radius_note,
        [f"일일 정류소별 버스 이용자 정보 ({HUB})", f"버스 정류소 기본 정보 ({HUB})"],
        ["하차 기록이 없는 데이터라 '근처에서 버스를 탄 사람'만 셉니다 (주로 행사 후 돌아가는 수요).",
         "교통카드 승차만 셉니다. 현금 승차, 셔틀버스, 자가용·렌터카 방문은 빠집니다.",
         f"참고 증차 대수는 하루 추가 승차를 버스 1대 {BUS_SEATS}명으로 나눈 단순 계산입니다. 실제 배차는 시간대·노선을 함께 봐야 합니다."],
        masked, _png(fig), facts)


def sentence(res: Result) -> str:
    f = res.facts
    if res.tool == "weather_risk":
        s = (f"{f['기록 연도']} {f['관측소']} 관측소 기록으로 보면, {f['본 기간']}에는 강풍(최대풍속 {WIND_MS:.0f}m/s 이상)인 날이 "
             f"{f['강풍 날 비율(%)']}%, 비 온 날이 {f['비 온 날 비율(%)']}%였습니다. 이 기간 중 비·강풍이 가장 적었던 날은 "
             f"{f['비·강풍이 가장 적었던 날']}, 가장 잦았던 날은 {f['비·강풍이 가장 잦았던 날']}입니다.")
        if f.get("지난 축제 기간 실제 날씨"):
            s += f" 지난 축제 기간 실제 날씨: {f['지난 축제 기간 실제 날씨']}."
        return s
    if res.tool == "bus_demand":
        if f["평소보다 뚜렷이 많았던 날"] == "없음":
            return (f"지난 축제 때 근처 정류소({f['근처 정류소']}) 승차는 평소와 뚜렷한 차이가 없었습니다. "
                    "이 행사는 대중교통보다 자가용·셔틀 비중이 큰 것으로 보이며, 버스 증차 근거로 쓰기는 어렵습니다.")
        return (f"지난 축제 때 근처 정류소({f['근처 정류소']}) 승차가 {f['평소보다 뚜렷이 많았던 날']}에 평소보다 뚜렷이 많았고, "
                f"하루 최대 {f['하루 최대 추가 승차(명)']}명이 더 탔습니다. 버스 1대 {BUS_SEATS}명 기준으로 하루 약 "
                f"{f[f'참고 증차(버스 1대 {BUS_SEATS}명 기준, 하루)']}대분의 추가 수요입니다(참고 계산).")
    return "표를 참고해 주세요."


# ---------- 대상별 준비 제안 ----------
# 같은 숫자를 누가 보느냐에 따라 말만 바꾼다. 숫자는 결과(facts)와 기준값(RAIN_MM·WIND_MS·BUS_SEATS)에서만 가져온다.

AUDIENCES = {
    "organizer": "축제·행사 주최자",
    "visitor": "방문객·도민",
    "bus": "버스 운영(대중교통 부서·운수사)",
    "merchant": "인근 상인·소상공인",
    "safety": "안전·행정(읍면동·소방·경찰 협조)",
    "outdoor": "일반 야외 행사(마을 행사·체육대회·야외 촬영·마라톤)",
}
WINDY_PCT = 30   # 이 비율 이상이면 '잦다'고 말한다
RAINY_PCT = 30


def _x(v: float) -> str:
    """배율 표기: 3.95 → '4', 2.4 → '2.4'"""
    t = f"{v:.1f}"
    return t[:-2] if t.endswith(".0") else t


def _wx_line(f: dict, who: str) -> str:
    wind, rain = f["강풍 날 비율(%)"], f["비 온 날 비율(%)"]
    obs, ny = f["관측소"], f["기록 연수"]
    safe, risky = f["비·강풍이 가장 적었던 날"], f["비·강풍이 가장 잦았던 날"]
    past_wind = f.get("지난 축제 기간 강풍 날", "없음")
    if who == "organizer":
        if wind >= WINDY_PCT:
            return (f"이 시기 {obs} 관측소는 강풍 날이 {wind}%로 잦습니다. 야외 무대·천막의 강풍 대비와 "
                    f"예비일(우천·강풍 연기일)을 계획에 넣는 것을 권합니다. 날짜를 고를 수 있다면 {safe} 쪽이 유리했습니다.")
        if rain >= RAINY_PCT:
            return f"이 시기 비 온 날이 {rain}%입니다. 우천 대비 동선과 예비일을 권합니다."
        return f"이 시기 비·강풍 빈도는 높지 않았습니다 (강풍 {wind}%, 비 {rain}%)."
    if who == "visitor":
        if wind >= WINDY_PCT:
            s = (f"지난 {ny}년 이 시기 행사장 부근은 강풍(최대풍속 {WIND_MS:.0f}m/s 이상)인 날이 10번 중 약 {round(wind / 10)}번이었습니다. "
                 "바람막이 같은 방풍 옷차림을 챙기고, 행사가 연기·취소될 수 있으니 일정에 여유를 두세요.")
        elif rain >= RAINY_PCT:
            s = f"지난 {ny}년 이 시기 비 온 날이 10번 중 약 {round(rain / 10)}번이었습니다. 우산·우비를 챙기세요."
        else:
            s = f"지난 {ny}년 이 시기 비·강풍은 잦지 않았습니다 (강풍 {wind}%, 비 {rain}%)."
        return s + f" 날짜를 고를 수 있다면 {safe} 쪽이 비·강풍이 적었습니다. 출발 전 기상청 예보를 꼭 확인하세요."
    if who == "bus":
        if wind >= WINDY_PCT:
            return (f"이 시기 강풍 날이 {wind}%여서 행사가 연기·취소될 수 있습니다. 증차는 당일 개최 여부 확인과 "
                    "연동해 두는 것을 권합니다.")
        return ""
    if who == "merchant":
        if wind >= WINDY_PCT or rain >= RAINY_PCT:
            s = (f"다만 이 시기 강풍 날이 {wind}%, 비 온 날이 {rain}%여서 행사가 줄거나 취소될 수 있습니다. "
                 "재고·임시 인력은 행사 직전 기상청 예보를 보고 확정하는 것을 권합니다.")
            if past_wind != "없음":
                s += f" 지난 축제 기간에도 강풍 날이 있었습니다({past_wind})."
            return s
        return f"이 시기 비·강풍 빈도는 높지 않았습니다 (강풍 {wind}%, 비 {rain}%)."
    if who == "safety":
        s = (f"{obs} 관측소(행사장에서 {f['행사장과 거리(km)']}km) {f['기록 연도']} 기록: 강풍 날 {wind}%, 비 온 날 {rain}%, "
             f"비·강풍이 잦았던 날 {risky}.")
        if "이 기간 가장 센 바람(m/s)" in f:
            s += f" 이 기간 가장 센 바람은 {f['이 기간 가장 센 바람(m/s)']}m/s({f['가장 센 바람이 분 날']})였습니다."
        if wind >= WINDY_PCT:
            s += " 강풍이 잦은 장소·시기이므로 무대·천막·임시 구조물 고정 상태와 풍속에 따른 행사 중단 기준을 우선 점검 대상으로 권합니다."
        return s
    if who == "outdoor":
        s = (f"{f['본 기간']} 중 지난 {ny}년 비·강풍이 가장 적었던 날은 {safe}, 가장 잦았던 날은 {risky}입니다 "
             f"(전체로는 강풍 {wind}%, 비 {rain}%).")
        s += " 날짜끼리 1~2해 차이는 우연일 수 있으니 예비일을 함께 잡고, 직전에는 기상청 예보를 확인하세요."
        return s
    return ""


def _bus_line(f: dict, who: str) -> str:
    hit = f["평소보다 뚜렷이 많았던 날"] != "없음"
    note = ", 평소 비교 날짜가 적어 참고용" if f.get("판정 참고용 여부") == "예" else ""
    xs = f"평소의 약 {_x(f['평소 대비 배율'])}배" if "평소 대비 배율" in f else "평소보다 뚜렷이 많음"
    k = f[f"참고 증차(버스 1대 {BUS_SEATS}명 기준, 하루)"]
    if who == "organizer":
        if not hit:
            return ""
        return (f"지난 축제 때 근처 정류소 승차가 하루 최대 {f['하루 최대 추가 승차(명)']}명 늘었습니다. "
                "행사 마치는 시간대에 해당 노선 증차나 임시 정류 안내를 검토하세요.")
    if who == "visitor":
        if not hit:
            return "지난 축제 때 근처 정류소 버스 승차는 평소와 뚜렷한 차이가 없었습니다. 주최 측 셔틀·주차 안내를 함께 확인하세요."
        return (f"지난 축제 {f['가장 많이 늘어난 날']}에 근처 정류소 승차가 {xs}였습니다"
                f"(하루 {f['그날 승차(명)']}명, 평소 {f['그날 평소(명)']}명{note}). 근처에서 버스를 '탄' 사람이라 "
                "주로 돌아가는 수요입니다. 귀가 버스가 붐빌 수 있으니 시간표와 다른 귀가 수단을 미리 정해 두세요.")
    if who == "bus":
        if not hit:
            return (f"지난 축제 때 근처 정류소({f['근처 정류소']}) 승차는 평소와 뚜렷한 차이가 없었습니다. "
                    "이 행사는 버스 증차 근거로 보기 어렵습니다.")
        return (f"지난 같은 축제 때 근처 정류소({f['근처 정류소']}) 교통카드 승차가 {f['평소보다 뚜렷이 많았던 날']}에 평소보다 뚜렷이 많았고, "
                f"하루 최대 {f['하루 최대 추가 승차(명)']}명이 더 탔습니다({f['가장 많이 늘어난 날']}, {xs}{note}). "
                f"버스 1대 {BUS_SEATS}명 기준 하루 약 {k}대분입니다(참고 계산). 하차 자료가 없어 주로 행사 후 귀가 수요이므로 "
                "행사 마치는 시간대에 이 정류소를 지나는 노선의 증차를 검토하세요.")
    if who == "merchant":
        if not hit:
            return "지난 축제 때 근처 정류소 버스 승차는 평소와 뚜렷한 차이가 없었습니다 (버스로 오는 손님만 센 값)."
        return (f"지난 축제 {f['가장 많이 늘어난 날']}에 근처 정류소 승차가 {xs}였습니다"
                f"(하루 {f['그날 승차(명)']}명, 평소 {f['그날 평소(명)']}명{note}). 버스로 오간 사람만 센 값이지만 "
                "그날 행사장 주변 사람이 평소보다 뚜렷이 늘었다는 근거입니다. 읍면동 유동인구로 본 지난 축제 효과는 "
                "'지난 축제 성과 보기'에서 확인할 수 있습니다.")
    if who == "safety":
        if not hit:
            return ""
        return (f"지난 축제 때 근처 정류소 승차가 하루 최대 {f['하루 최대 추가 승차(명)']}명 늘었습니다({xs}{note}). "
                "행사 마치는 시간대 정류소 주변 보행·승차 혼잡 관리도 함께 점검하세요.")
    if who == "outdoor":
        if not hit:
            return ""
        return (f"참고로 지난 같은 시기 행사 때 근처 정류소 승차가 {xs}였습니다. 행사가 겹치면 버스가 붐빌 수 있습니다.")
    return ""


def advice(results: list[Result], audience: str = "organizer") -> str:
    """결과를 묶어 고른 대상에게 줄 정리 (규칙 기반, 숫자는 결과에서만 가져온다)."""
    who = audience if audience in AUDIENCES else "organizer"
    order = {"bus": ("bus_demand", "weather_risk"), "merchant": ("bus_demand", "weather_risk")}.get(
        who, ("weather_risk", "bus_demand"))
    by = {r.tool: r for r in results}
    lines = []
    for tool in order:
        r = by.get(tool)
        if r is None:
            continue
        line = _wx_line(r.facts, who) if tool == "weather_risk" else _bus_line(r.facts, who)
        if line:
            lines.append(line)
    if lines and lines[0].startswith("다만 "):   # 앞 문장(버스)이 없을 때
        lines[0] = lines[0][3:]
    if lines and who in ("bus", "merchant") and "bus_demand" not in by:
        lines.insert(0, "버스 수요는 비교할 지난 축제 기간을 넣어야 계산됩니다.")
    if not lines:
        return "판단에 쓸 결과가 없습니다."
    return " ".join(lines)
