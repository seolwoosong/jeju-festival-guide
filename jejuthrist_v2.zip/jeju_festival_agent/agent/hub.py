"""제주데이터허브 Open API 에서 실제 데이터를 직접 가져오기.

이용자가 CSV를 하나하나 내려받아 넣지 않아도 되도록, Agent가 축제 조건(읍면동·기간)을 보고
필요한 데이터를 스스로 요청한다. 가져온 데이터는 data/hub/ 폴더에 CSV로 저장해 다음부터 다시 쓴다.

필요한 것: 제주데이터허브(jejudatahub.net)에서 발급받은 프로젝트 키를 .env 의 HUB_PROJECT_KEY 에 적기.
허브 API 규칙(허브 데이터 상세 화면 기준): GET, 한 번에 최대 100행(limit), 쪽 번호는 number(1부터).
"""
from __future__ import annotations

import csv
import io
import os
import time
from pathlib import Path

import pandas as pd
import requests

BASE_URL = "https://open.jejudatahub.net/api/proxy"
# 허브 데이터별 API 주소 (허브 데이터 상세 화면의 '요청 URL')
API = {
    "pop": "Daaa1t3at3tt8a8DD3t55538t35Dab1t",       # 읍면동 단위 내국인 유동인구 (일 단위)
    "weather": "1aD5taat1attaa51Db1511b51ab9Da19",   # 일별 기상 정보
}
HUB_DIR = Path(__file__).resolve().parent.parent / "data" / "hub"
POP_FIELDS = ["baseDate", "city", "emd", "gender", "ageGroup", "resdPop", "workPop", "visitPop"]
WX_FIELDS = ["baseDate", "observatoryName", "averageTemperature", "dailyRainfall", "maximumWindSpeed",
             "averageWindSpeed"]


class HubError(RuntimeError):
    pass


def project_key() -> str:
    return os.environ.get("HUB_PROJECT_KEY", "").strip()


def _get(api: str, params: dict, key: str, session=None) -> dict:
    s = session or requests
    url = f"{BASE_URL}/{API[api]}/{key}"
    last = None
    for attempt in range(3):  # 허브가 잠깐 응답하지 않을 때를 대비해 두 번 더 시도
        try:
            r = s.get(url, params=params, timeout=30)
            text = r.text
            if r.status_code != 200 or not text.lstrip().startswith("{"):
                raise HubError(f"허브 응답 오류({r.status_code}): {text[:120]}")
            return r.json()
        except (requests.RequestException, ValueError, HubError) as e:
            last = e
            time.sleep(1.5 * (attempt + 1))
    raise HubError(f"제주데이터허브에서 데이터를 받지 못했습니다. 프로젝트 키와 인터넷 연결을 확인해 주세요. ({last})")


def fetch_pop(emd: str, start: pd.Timestamp, end: pd.Timestamp, key: str, session=None) -> list[dict]:
    """읍면동 하나의 기간 전체 유동인구를 쪽(100행)씩 끝까지 받는다."""
    rows, page = [], 1
    while True:
        j = _get("pop", {"startDate": f"{start:%Y%m%d}", "endDate": f"{end:%Y%m%d}", "emd": emd,
                         "limit": 100, "number": page}, key, session)
        data = j.get("data") or []
        rows.extend(data)
        if not j.get("hasMore") or not data or page > 200:
            break
        page += 1
        time.sleep(0.2)
    uniq = {(r["baseDate"], r["emd"], r["gender"], r["ageGroup"]): r for r in rows}
    if not uniq:
        raise HubError(f"허브에 '{emd}'의 {start:%Y-%m-%d} ~ {end:%Y-%m-%d} 유동인구가 없습니다. "
                       "읍면동 이름(예: 애월읍, 삼도2동)과 기간을 확인해 주세요.")
    return list(uniq.values())


def fetch_weather(start: pd.Timestamp, end: pd.Timestamp, key: str, session=None) -> list[dict]:
    """일별 기상 정보는 하루씩 요청하는 API다. 허브 제공 기간 밖의 날짜는 빈 결과로 돌아온다."""
    rows = []
    for d in pd.date_range(start, end, freq="D"):
        j = _get("weather", {"searchDate": f"{d:%Y%m%d}", "limit": 100}, key, session)
        rows.extend(j.get("data") or [])
        time.sleep(0.15)
    return rows


def to_csv(rows: list[dict], fields: list[str]) -> bytes:
    buf = io.StringIO()
    w = csv.DictWriter(buf, fieldnames=fields, extrasaction="ignore")
    w.writeheader()
    for r in rows:
        w.writerow({k: r.get(k, "") for k in fields})
    return buf.getvalue().encode("utf-8")


def collect(emds: list[str], start: pd.Timestamp, end: pd.Timestamp, key: str | None = None,
            with_weather: bool = True, session=None, progress=None) -> list[Path]:
    """축제 검증에 필요한 데이터를 허브에서 받아 data/hub/ 에 저장하고 파일 경로를 돌려준다."""
    key = key or project_key()
    if not key:
        raise HubError("제주데이터허브 프로젝트 키가 없습니다. .env 파일의 HUB_PROJECT_KEY 에 키를 적어 주세요 "
                       "(발급 방법은 README의 '허브 키 설정' 참고).")
    HUB_DIR.mkdir(parents=True, exist_ok=True)
    saved = []
    for emd in emds:
        if progress:
            progress(f"유동인구 받는 중: {emd}")
        rows = fetch_pop(emd, start, end, key, session)
        p = HUB_DIR / f"pop_{emd}_{start:%Y%m%d}_{end:%Y%m%d}.csv"
        p.write_bytes(to_csv(rows, POP_FIELDS))
        saved.append(p)
    if with_weather:
        if progress:
            progress("날씨 받는 중")
        rows = fetch_weather(start, end, key, session)
        if rows:
            p = HUB_DIR / f"weather_{start:%Y%m%d}_{end:%Y%m%d}.csv"
            p.write_bytes(to_csv(rows, WX_FIELDS))
            saved.append(p)
    return saved
