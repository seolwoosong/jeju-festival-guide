"""데이터 인식·불러오기.

두 가지 출처를 같은 모양으로 맞춘다.
  1) 제주빅데이터센터 CSV: 영문 컬럼명, 쉼표, UTF-8, 결측 'NA' (대회 게시판 답변, 대회 제공 예시 파일 기준)
  2) 제주데이터허브 Open API 결과(agent/hub.py 가 저장한 CSV): baseDate, emd, visitPop 같은 낙타 표기 컬럼
컬럼명만 보고 어떤 데이터인지 자동으로 알아낸다.
"""
from __future__ import annotations

import io
from dataclasses import dataclass

import pandas as pd

SPECS = {
    "floating_pop": {
        "name": "내국인 유동인구(읍면동, 시간대별)", "source": "제주빅데이터센터 4-10, 4-11",
        "required": {"base_date", "time", "emd_nm", "sex", "age", "resd_pop_cnt", "work_pop_cnt", "visit_pop_cnt"},
    },
    "hub_pop": {
        "name": "읍면동 단위 내국인 유동인구(일별)", "source": "제주데이터허브 Open API",
        "required": {"baseDate", "emd", "gender", "ageGroup", "resdPop", "workPop", "visitPop"},
    },
    "station_usage": {
        "name": "버스 정류소별 이용 현황", "source": "제주빅데이터센터 3-04",
        "required": {"base_date", "base_hour", "bus_station_name", "get_on_off_type", "user_count"},
    },
    "weather_daily": {
        "name": "일일 날씨 정보", "source": "제주빅데이터센터 5-02",
        "required": {"base_date", "observatory_code", "daily_rainfall"},
    },
    "hub_weather": {
        "name": "일별 기상 정보", "source": "제주데이터허브 Open API",
        "required": {"baseDate", "observatoryName", "dailyRainfall"},
    },
}
# 출처가 달라도 분석에서는 같은 종류로 다룬다
CANONICAL = {"floating_pop": "pop", "hub_pop": "pop", "station_usage": "bus",
             "weather_daily": "weather", "hub_weather": "weather"}
POP_COLS = ["resd_pop_cnt", "work_pop_cnt", "visit_pop_cnt"]
BLOCKED_COLUMNS = {"user_id", "user_card_id", "mac_address"}   # 개인 단위 기록
WEEKDAYS = ["월", "화", "수", "목", "금", "토", "일"]


@dataclass
class Loaded:
    kind: str           # 원래 형식 (SPECS 의 키)
    name: str
    filename: str
    df: pd.DataFrame
    dropped: int = 0

    @property
    def role(self) -> str:
        return CANONICAL[self.kind]

    @property
    def source(self) -> str:
        return SPECS[self.kind]["source"]

    @property
    def period(self) -> str:
        d = self.df["base_date"].dropna() if "base_date" in self.df.columns else []
        return f"{d.min():%Y-%m-%d} ~ {d.max():%Y-%m-%d}" if len(d) else "-"

    @property
    def hourly(self) -> bool:
        return "time" in self.df.columns and self.df["time"].notna().any()

    def schema_summary(self) -> dict:
        """외부 AI에 보내도 되는 정보만 담는다: 컬럼명, 행 수, 기간. 값은 담지 않는다."""
        return {"kind": self.kind, "name": self.name, "columns": list(self.df.columns),
                "rows": int(len(self.df)), "period": self.period}


class DatasetError(ValueError):
    pass


def detect_kind(columns) -> str | None:
    cols = {str(c).strip() for c in columns}
    for kind, spec in sorted(SPECS.items(), key=lambda kv: -len(kv[1]["required"])):
        if spec["required"] <= cols:
            return kind
    return None


def load_csv(data: bytes, filename: str) -> Loaded:
    try:
        text = data.decode("utf-8-sig")
    except UnicodeDecodeError:
        text = data.decode("cp949", errors="replace")
    df = pd.read_csv(io.StringIO(text), dtype=str, na_values=["NA", "NULL", ""], keep_default_na=False)
    df.columns = [str(c).strip() for c in df.columns]
    if BLOCKED_COLUMNS & set(df.columns):
        raise DatasetError("개인 단위 기록(이용자 식별자 포함)은 이 Agent에서 분석하지 않습니다. "
                           "집계된 데이터(유동인구, 버스 정류소별 이용 현황)를 사용해 주세요.")
    kind = detect_kind(df.columns)
    if kind is None:
        raise DatasetError("지원하는 데이터가 아닙니다. 지원 데이터: "
                           + ", ".join(sorted({s['name'] for s in SPECS.values()})))
    df, dropped = _normalize(df, kind)
    return Loaded(kind=kind, name=SPECS[kind]["name"], filename=filename, df=df, dropped=dropped)


def merge(old: Loaded, new: Loaded) -> Loaded:
    """같은 종류를 여러 파일(여러 달, 여러 읍면동)로 넣으면 이어 붙인다."""
    df = pd.concat([old.df, new.df], ignore_index=True).drop_duplicates()
    name = old.name if old.kind == new.kind else f"{old.name} + {new.name}"
    return Loaded(kind=old.kind, name=name, filename=f"{old.filename}, {new.filename}", df=df,
                  dropped=old.dropped + new.dropped)


def _numeric_or_fail(df: pd.DataFrame, cols: list[str], label: str):
    """숫자가 아닌 값('**'처럼 가려진 값)이 있는 행은 0으로 바꾸지 않고 뺀다."""
    num = df[cols].apply(pd.to_numeric, errors="coerce")
    bad = num.isna().any(axis=1)
    if len(df) and bad.all():
        raise DatasetError(f"이 파일은 {label} 값이 숫자가 아닙니다('**'처럼 가려진 예시 파일로 보입니다). "
                           "센터에서 내려받은 실제 CSV를 넣어 주세요.")
    df = df[~bad].copy()
    df[cols] = num[~bad]
    return df, int(bad.sum())


def _normalize(df: pd.DataFrame, kind: str):
    df = df.copy()
    for c in df.select_dtypes(include=["object", "string"]).columns:
        df[c] = df[c].str.strip()
    if kind == "hub_pop":
        df = df.rename(columns={"baseDate": "base_date", "emd": "emd_nm", "gender": "sex", "ageGroup": "age",
                                "resdPop": "resd_pop_cnt", "workPop": "work_pop_cnt", "visitPop": "visit_pop_cnt"})
    elif kind == "hub_weather":
        df = df.rename(columns={"baseDate": "base_date", "observatoryName": "station",
                                "dailyRainfall": "daily_rainfall", "maximumWindSpeed": "maximum_wind_speed",
                                "averageTemperature": "average_temperature"})
    df["base_date"] = pd.to_datetime(df["base_date"], format="%Y%m%d", errors="coerce")
    df = df.dropna(subset=["base_date"])
    dropped = 0
    if kind in ("floating_pop", "hub_pop"):
        df, dropped = _numeric_or_fail(df, POP_COLS, "유동인구")
        df = df.dropna(subset=["emd_nm"])
        if kind == "floating_pop":
            df["time"] = pd.to_numeric(df["time"], errors="coerce")
            df = df.dropna(subset=["time"])
            df["time"] = df["time"].astype(int)
        df["sex"] = df["sex"].replace({"남": "남성", "여": "여성", "M": "남성", "F": "여성"})
        df["age_band"] = df["age"].map(_age_band)
        if "resd" not in df.columns:
            df["resd"] = None
    elif kind == "station_usage":
        df, dropped = _numeric_or_fail(df, ["user_count"], "이용자 수")
        df["user_count"] = df["user_count"].astype(int)
    else:  # 날씨
        if "station" not in df.columns:
            df["station"] = df["observatory_code"].astype(str)
        for c in ("daily_rainfall", "maximum_wind_speed", "average_temperature"):
            if c in df.columns:
                df[c] = pd.to_numeric(df[c], errors="coerce")
    df["day_of_week"] = df["base_date"].dt.dayofweek.map(lambda i: WEEKDAYS[i])
    return df, dropped


def _age_band(code) -> str:
    """연령 표기를 10세 단위로 맞춘다.
    센터: 1014(10~14세), 7000(70세 이상)  ·  허브: 10대, 10세미만, 70대이상
    """
    s = str(code).strip().replace(" ", "")
    if "미만" in s:
        return "10세 미만"
    if "이상" in s:
        return "70세 이상"
    if s.endswith("대") and s[:-1].isdigit():
        n = int(s[:-1])
        return "70세 이상" if n >= 70 else f"{n}대"
    if not s.isdigit():
        return "기타"
    n = int(s)
    lo = n // 100 if n >= 100 else n
    if lo >= 70:
        return "70세 이상"
    if lo < 10:
        return "10세 미만"
    return f"{lo // 10 * 10}대"
