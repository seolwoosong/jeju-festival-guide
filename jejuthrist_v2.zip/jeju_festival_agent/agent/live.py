"""실시간 받기: 화면에서 축제를 고르면 그 축제에 필요한 날짜만 제주데이터허브에서 바로 받는다.

- 날씨: 최근 10철 × 축제 앞뒤 7일 (하루 1번 호출, 보통 150~200번)
- 버스: 축제일(처음 3일)과 1주 전·후 같은 요일 (하루치 약 60~70번 호출)
받은 자료는 data/prep/ 에 저장되어 다음부터는 받지 않는다.
허브 호출 한도(데이터별 하루 1,000번)는 scripts/fetch_festivals.py 와 같은 기록(_usage.json)으로 함께 센다.
"""
from __future__ import annotations

import os
import sys
from datetime import date, timedelta
from pathlib import Path

from . import festivals as F
from . import prep

BASE = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BASE / "scripts"))

import fetch_festivals as FF  # noqa: E402

fp = FF.fp
BUS_FEST_DAYS = 3


def hub_key() -> str:
    """.env 를 매번 다시 읽는다 (프로그램을 켠 뒤 키를 적어도 바로 쓰이도록)."""
    env = BASE / ".env"
    if env.exists():
        for line in env.read_text(encoding="utf-8").splitlines():
            if line.strip().startswith("HUB_PROJECT_KEY="):
                v = line.split("=", 1)[1].strip().strip('"').strip("'")
                if v:
                    return v
    return os.environ.get("HUB_PROJECT_KEY", "").strip()


def _missing(sub: str, prefix: str, days: list[date]) -> list[date]:
    have = {p.stem for p in (fp.OUT / sub).glob(f"{prefix}_*.csv")}
    cut = date.today() - timedelta(days=2)
    return [d for d in days if f"{prefix}_{d:%Y%m%d}" not in have and d <= cut]


def weather_todo(row) -> list[date]:
    return _missing("weather", "wx", sorted(set(F.weather_days(row))))


def bus_todo(row) -> list[date]:
    fest, _ = F.bus_days(row, weeks=1)
    fest = fest[:BUS_FEST_DAYS]
    want = sorted(set(fest) | {d + timedelta(weeks=s) for d in fest for s in (-1, 1)})
    return _missing("bus", "bus", want)


def _start(key: str):
    if not key:
        raise LiveError("허브 키가 없습니다. .env 파일의 HUB_PROJECT_KEY= 뒤에 제주데이터허브 프로젝트 키를 적어 주세요.")
    FF._usage = FF.load_usage()


class LiveError(Exception):
    pass


def _wrap(fn):
    try:
        return fn()
    except FF.BudgetReached:
        raise LiveError("오늘 허브 호출 한도(데이터별 하루 1,000번)에 닿았습니다. 받은 만큼은 저장됐고, 자정 이후 다시 누르면 이어서 받습니다.")
    except fp.QuotaOrKeyError as e:
        raise LiveError(f"허브가 요청을 거절했습니다. 키와 [프로젝트 담기]를 확인해 주세요. ({str(e)[:80]})")
    except Exception as e:  # 인터넷 끊김, 허브 시간 초과 등
        raise LiveError(f"허브에 연결하지 못했습니다. 인터넷 연결을 확인해 주세요. ({str(e)[:80]})")
    finally:
        prep._read_dir.cache_clear()


def fetch_weather(row) -> int:
    key = hub_key()
    _start(key)
    todo = weather_todo(row)

    def run():
        for d in todo:
            j = fp.call("weather", key, {"searchDate": f"{d:%Y%m%d}", "limit": 100})
            fp.save(fp.OUT / "weather" / f"wx_{d:%Y%m%d}.csv", j.get("data") or [])
        return len(todo)
    return _wrap(run)


def fetch_bus(row) -> int:
    key = hub_key()
    _start(key)
    todo = bus_todo(row)

    def run():
        for d in todo:
            if FF._usage.get("bus", 0) + FF.BUS_CALLS_PER_DAY > FF.budget():
                raise FF.BudgetReached("bus")
            ymd = f"{d:%Y%m%d}"
            rows = fp.pages("bus", key, {"startDate": ymd, "endDate": ymd, "moveType": "승차", "payType": "카드"})
            fp.save(fp.OUT / "bus" / f"bus_{ymd}.csv", rows)
        return len(todo)
    return _wrap(run)


def minutes(calls: int) -> str:
    m = max(1, round(calls * 0.6 / 60))     # 호출 1번 ≈ 0.6초로 어림
    return f"약 {m}분"


def pop_missing(row, pop_df) -> list[str]:
    """이 회차 앞뒤 기간 유동인구가 없는 읍면동 (축제 지역, 대조 지역)."""
    import pandas as pd
    out = []
    for emd in [row["emd"], row.get("control", "")]:
        if not emd:
            continue
        if pop_df is None or pop_df.empty:
            out.append(emd)
            continue
        d = pop_df[(pop_df["emd_nm"] == emd) & (pd.to_datetime(pop_df["base_date"]) >= row["start"])
                   & (pd.to_datetime(pop_df["base_date"]) <= row["end"])]
        if d.empty:
            out.append(emd)
    return out


def fetch_pop(row, emds: list[str]):
    """읍면동 유동인구를 축제 앞뒤 8주씩 받는다 (읍면동 하나에 약 20번 호출)."""
    import pandas as pd
    from . import hub
    key = hub_key()
    if not key:
        raise LiveError("허브 키가 없습니다. .env 파일의 HUB_PROJECT_KEY= 뒤에 제주데이터허브 프로젝트 키를 적어 주세요.")
    lo = row["start"] - pd.Timedelta(weeks=8)
    hi = min(row["end"] + pd.Timedelta(weeks=8), pd.Timestamp(date.today() - timedelta(days=3)))
    try:
        return hub.collect(emds, lo, hi, key, with_weather=False)
    except hub.HubError as e:
        raise LiveError(str(e))
    except Exception as e:
        raise LiveError(f"허브에 연결하지 못했습니다. 인터넷 연결을 확인해 주세요. ({str(e)[:80]})")
