"""결과 화면 조각과 반출용 보고서(HTML) 만들기.

보고서는 그림이 파일 안에 들어 있는 HTML 한 개다. 브라우저에서 열어 '인쇄 → PDF로 저장'하면 PDF가 된다.
"""
from __future__ import annotations

import base64
import html

from .guard import MASK

CSS = """
body{font-family:'Malgun Gothic','맑은 고딕','Noto Sans KR',sans-serif;color:#1c2733;line-height:1.6;margin:0}
.wrap{max-width:980px;margin:0 auto;padding:24px}
h1{font-size:24px;margin:0 0 4px} h2{font-size:18px;margin:28px 0 8px;border-left:4px solid #2a6fb0;padding-left:10px}
.meta{color:#5b6875;font-size:13px}
.card{border:1px solid #d9e0e7;border-radius:10px;padding:16px 20px;margin:16px 0;background:#fff}
.q{font-weight:700;font-size:16px}
table{border-collapse:collapse;width:100%;font-size:13.5px;margin:8px 0}
th,td{border:1px solid #d9e0e7;padding:5px 9px;text-align:right} th{background:#f1f5f9;text-align:center}
td:first-child,td.l{text-align:left}
td.mask{color:#a03a2a;text-align:center}
img{max-width:100%;border:1px solid #eef1f4;border-radius:6px}
.say{background:#f4f8fc;border-radius:8px;padding:10px 14px;margin:8px 0}
.small{font-size:12.5px;color:#5b6875} .warn{color:#a03a2a;font-size:13px}
ul{margin:4px 0 4px 18px;padding:0}
@media print{.noprint{display:none}.card{break-inside:avoid}}
"""


def _table(df) -> str:
    head = "".join(f"<th>{html.escape(str(c))}</th>" for c in df.columns)
    body = []
    for row in df.itertuples(index=False):
        tds = []
        for v in row:
            if v == MASK:
                tds.append(f'<td class="mask">{MASK}</td>')
            elif isinstance(v, float):
                tds.append("<td>-</td>" if v != v else f"<td>{v:,.1f}</td>")
            elif isinstance(v, int) or hasattr(v, "item") and not isinstance(v, str):
                tds.append(f"<td>{int(v):,}</td>" if float(v) == int(v) else f"<td>{float(v):,.1f}</td>")
            elif v is None:
                tds.append("<td>-</td>")
            else:
                tds.append(f'<td class="l">{html.escape(str(v))}</td>')
        body.append("<tr>" + "".join(tds) + "</tr>")
    return f"<table><thead><tr>{head}</tr></thead><tbody>{''.join(body)}</tbody></table>"


def result_html(item: dict, min_count: int) -> str:
    r = item["result"]
    parts = [f"<h2>{html.escape(r.title)}</h2>",
             f'<div class="say">{html.escape(item["text"])} <span class="small">({item["how"]})</span></div>']
    if r.chart:
        parts.append(f'<img alt="{html.escape(r.title)}" src="data:image/png;base64,{base64.b64encode(r.chart).decode()}">')
    parts.append(_table(r.table))
    if r.masked:
        parts.append(f'<div class="warn">반출 기준 점검: 바탕 인원이 {min_count}명 미만인 {r.masked}개 행을 가렸습니다.</div>')
    else:
        parts.append(f'<div class="small">반출 기준 점검: {min_count}명 미만 값 없음.</div>')
    lim = "".join(f"<li>{html.escape(x)}</li>" for x in r.limits)
    parts.append(f'<div class="small"><b>사용 데이터</b>: {html.escape(", ".join(r.data_used))}<br>'
                 f'<b>계산 방법</b>: {html.escape(r.method)}'
                 + (f"<br><b>해석할 때 주의</b>:<ul>{lim}</ul>" if lim else "") + "</div>")
    return "".join(parts)


def answer_html(ans: dict) -> str:
    parts = [f'<div class="card"><div class="q">{html.escape(ans["question"])}</div>',
             f'<div class="meta">{ans["time"]} · {html.escape(ans["mode"])}</div>']
    if ans.get("spec_html"):
        parts.append(ans["spec_html"])
    if ans["note"]:
        parts.append(f'<div class="small">{html.escape(ans["note"])}</div>')
    for e in ans["errors"]:
        parts.append(f'<div class="warn">{html.escape(e)}</div>')
    for item in ans["results"]:
        parts.append(result_html(item, ans["min_count"]))
    parts.append("</div>")
    return "".join(parts)


def _overview(history: list[dict]) -> str:
    """보고서 첫머리: 축제별 결론을 한 표로."""
    rows = []
    for a in history:
        if a.get("kind") == "prep":
            continue
        f = {it["result"].tool: it["result"].facts for it in a["results"]}
        ve, cc = f.get("visit_effect", {}), f.get("control_compare", {})
        spec = a.get("spec")
        name = html.escape(spec.name) if spec else html.escape(a["question"])
        period = f"{spec.start:%Y-%m-%d} ~ {spec.end:%m-%d}" if spec else ""
        if cc:
            eff = cc.get("순증가가 뚜렷한 날", "없음")
            verdict = "효과 확인" if eff != "없음" else "효과 확인 안 됨"
            detail = f"효과 본 날: {eff} · 최대 순증가 {cc.get('순증가가 가장 큰 날', '-')} (대조: {cc.get('대조 지역', '')})"
        else:
            eff = ve.get("평소를 넘게 늘어난 날", "없음")
            verdict = "효과 확인" if eff != "없음" else "효과 확인 안 됨"
            detail = f"효과 본 날: {eff} · 최대 증가 {ve.get('가장 많이 늘어난 날', '-')}"
        wx = [x for x in (ve.get("비 온 날(1mm 이상)"), ve.get("강풍 날(최대 풍속 14m/s 이상)")) if x and x != "없음"]
        wtxt = ""
        if ve.get("비 온 날(1mm 이상)", "없음") != "없음":
            wtxt += f"비 {ve['비 온 날(1mm 이상)']} "
        if ve.get("강풍 날(최대 풍속 14m/s 이상)", "없음") != "없음":
            wtxt += f"강풍 {ve['강풍 날(최대 풍속 14m/s 이상)']}"
        if not wtxt:
            wtxt = "특이 없음" if ve.get("날씨 기준", "날씨 데이터 없음") != "날씨 데이터 없음" else "자료 없음 (허브 기상 자료가 2025년 3월까지만 제공)"
        color = "#1d7a3e" if verdict == "효과 확인" else "#8a5a00"
        rows.append(f"<tr><td class='l'><b>{name}</b><br><span class='small'>{period}</span></td>"
                    f"<td style='color:{color};font-weight:700'>{verdict}</td><td class='l'>{html.escape(detail)}</td>"
                    f"<td class='l'>{html.escape(wtxt)}</td></tr>")
    if not rows:
        return ""
    return ("<h2>한눈에 보기</h2><table><thead><tr><th>축제</th><th>판정</th><th>근거</th><th>날씨</th></tr></thead>"
            f"<tbody>{''.join(rows)}</tbody></table>")


def report_html(history: list[dict], datasets: list[dict], title: str = "제주 축제 준비·검증 보고서") -> str:
    rows = "".join(f"<tr><td class='l'>{html.escape(d['name'])}</td><td class='l'>{html.escape(d['filename'])}</td>"
                   f"<td>{d['rows']:,}</td><td class='l'>{d['period']}</td></tr>" for d in datasets)
    body = "".join(answer_html(a) for a in history)
    overview = _overview(history)
    srcs = sorted({d.get("source", "") for d in datasets if d.get("source")})
    src_line = (f"출처: {', '.join(srcs)}. " if srcs else "") + "유동인구는 통신 데이터 기반 추정치입니다."
    if any(d.get("role") == "bus" for d in datasets):
        src_line += " 버스 이용자 수는 교통카드 태그 기준입니다."
    made = history[-1]["time"] if history else ""
    mc = history[-1]["min_count"] if history else 10
    return f"""<!doctype html><html lang="ko"><head><meta charset="utf-8"><title>{html.escape(title)}</title>
<style>{CSS}</style></head><body><div class="wrap">
<h1>{html.escape(title)}</h1>
<div class="meta">작성 일시 {made} · 제주 축제 준비·검증 Agent로 작성</div>
<div class="noprint small" style="margin:10px 0">PDF로 저장하려면 Ctrl+P → 대상 'PDF로 저장'을 선택하세요.</div>
{overview}
<h2>분석에 사용한 데이터</h2>
<table><thead><tr><th>데이터</th><th>파일</th><th>행 수</th><th>기간</th></tr></thead><tbody>{rows}</tbody></table>
<div class="small">{src_line}</div>
{body}
<h2>판정 방법</h2>
<div class="small">평소 = 축제 전후 4주 안의 같은 요일 평균(축제일·공휴일 제외). 축제 지역 증가율에서 같은 날 이웃 대조 지역의 증가율을 뺀 값을
'순증가'로 보고, 평소 날짜들에서 같은 방식으로 구한 순증가의 흔들림(표준편차)의 2배를 넘으면 '축제 효과로 볼 만한 날'로 판정합니다.
계절이나 날씨처럼 제주 전체에 생긴 변화는 대조 지역에도 나타나므로 순증가에서 빠집니다.</div>
<h2>반출 기준 점검 요약</h2>
<div class="small">이 보고서의 모든 표는 바탕 인원이 {mc}명 미만인 값을 '기준 미만'으로 가린 뒤 작성했습니다.
원본 행 단위 데이터는 포함하지 않았습니다. 실제 반출 가능 여부는 제주빅데이터센터의 반출 심의 결과를 따릅니다.</div>
</div></body></html>"""
