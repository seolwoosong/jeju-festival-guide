@echo off
chcp 65001 >nul
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" goto noinstall
".venv\Scripts\python.exe" -X utf8 app.py
pause
exit /b
:noinstall
echo [!] Run install.bat first.
pause
exit /b 1
