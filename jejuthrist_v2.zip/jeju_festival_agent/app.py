"""제주 축제 성과 검증 Agent — 실행 파일.

이 PC 안(127.0.0.1)에서만 열리는 화면을 띄운다. 외부에서 접속할 수 없다.
실행: run.bat 더블클릭 (또는 `python app.py`)
"""
from __future__ import annotations

import html
import json
import os
import socket
import threading
import time
import webbrowser
from pathlib import Path

import pandas as pd
from flask import Flask, Response, jsonify, request

BASE = Path(__file__).resolve().parent
os.environ.setdefault("FLASK_SKIP_DOTENV", "1")


def _load_env():
    """.env 파일의 설정을 읽는다 (KEY=값 형식)."""
    p = BASE / ".env"
    if p.exists():
        for line in p.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))


_load_env()

from agent import core, festivals, guide, hub, live, prep, report, settings, tools  # noqa: E402
from agent.datasets import DatasetError, load_csv, merge  # noqa: E402

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 2 * 1024 * 1024 * 1024
DATA: dict = {}      # 역할(pop, bus, weather) → 불러온 데이터. 메모리에만 둔다.
HISTORY: list = []   # 이번 실행에서 검증한 축제들
CASES = json.loads((BASE / "data" / "cases.json").read_text(encoding="utf-8"))


def _add(d) -> None:
    DATA[d.role] = merge(DATA[d.role], d) if d.role in DATA else d


def load_bundled() -> list[str]:
    """제출물에 들어 있는 실제 데이터(data/hub/*.csv)를 시작할 때 자동으로 불러온다."""
    msgs = []
    for p in sorted((BASE / "data" / "hub").glob("*.csv")):
        try:
            _add(load_csv(p.read_bytes(), p.name))
            msgs.append(p.name)
        except DatasetError as e:
            msgs.append(f"{p.name}: {e}")
    return msgs


def _datasets():
    out = []
    for d in DATA.values():
        emds = ", ".join(tools.emd_names(DATA)) if d.role == "pop" else ""
        out.append({"role": d.role, "name": d.name, "source": d.source, "filename": d.filename, "rows": len(d.df),
                    "period": d.period, "emds": emds})
    return out


def _status():
    return {"datasets": _datasets(), "emds": tools.emd_names(DATA), "hub_key": bool(hub.project_key()),
            "prep": prep.available()}


GUIDE_HTML = (BASE / "agent" / "guide.html").read_text(encoding="utf-8")


@app.get("/")
def home():
    return Response(GUIDE_HTML, mimetype="text/html; charset=utf-8")


@app.get("/detail")
def index():
    cfg = core.config()
    mode = f"AI 모드 ({cfg['model']})" if core.llm_on(cfg) else "기본 모드 (AI 키 없음 · 외부 전송 없음)"
    btns = "".join(
        f'<div class="case"><button class="btn" onclick="runCase(\'{c["id"]}\')">{html.escape(c["name"])} 검증하기</button>'
        f'<div class="small">{html.escape(c["start"])} ~ {html.escape(c["end"])} · {html.escape(c["emd"])} · 대조 {html.escape(c["control"])}'
        f'<br>{html.escape(c["summary"])}<br>일정 출처: '
        + " · ".join(f'<a href="{html.escape(s["url"])}" target="_blank">{html.escape(s["title"])}</a>' for s in c["sources"])
        + "</div></div>" for c in CASES)
    pbtns = "".join(
        f'<div class="case"><button class="btn" onclick="runPrep(\'{c["id"]}\')">{html.escape(c["label"])}</button>'
        f'<div class="small">{html.escape(c["place"])} · 날씨 {c["wx_from"]}~{c["wx_to"]} (여러 해) · 비교 축제 {c["ref_start"]}~{c["ref_end"]}'
        f'<br>{html.escape(c["summary"])}</div></div>' for c in PREP_CASES)
    aud = "".join(
        f'<label class="chip"><input type="radio" name="aud" value="{k}"{" checked" if k == "organizer" else ""}> {html.escape(v)}</label>'
        for k, v in prep.AUDIENCES.items())
    return (PAGE.replace("{{CSS}}", report.CSS).replace("{{PREP}}", pbtns).replace("{{AUD}}", aud).replace("{{MODE}}", mode).replace("{{CASES}}", btns)
            .replace("{{MIN}}", str(cfg["min_count"])))


@app.get("/status")
def status():
    return jsonify(_status())


@app.post("/case/<cid>")
def run_case(cid):
    c = next((x for x in CASES if x["id"] == cid), None)
    if c is None:
        return jsonify({"html": '<div class="card warn">없는 사례입니다.</div>'})
    form = {k: c[k] for k in ("name", "emd", "start", "end", "control", "weather_station")}
    return _verify(form, _case_note(c), case=c)


def _case_note(c) -> str:
    links = " · ".join(f'<a href="{html.escape(x["url"])}" target="_blank">{html.escape(x["title"])}</a>'
                       for x in c.get("sources", []))
    return (f'<div class="small">사례 설명: {html.escape(c["summary"])}</div>'
            + (f'<div class="small">일정 출처: {links}</div>' if links else ""))


@app.post("/prescribe")
def prescribe():
    """축제 조건만으로 무엇이 필요한지 알려 준다."""
    form = {**(request.get_json(silent=True) or {}), "allow_missing": True}
    try:
        spec, _, _ = core.build_spec(form, {}, core.config())
    except core.SpecError as e:
        return jsonify({"html": f'<div class="warn">{html.escape(str(e))}</div>'})
    return jsonify({"html": report._table(pd.DataFrame(tools.prescription(spec)))})


@app.post("/fetch")
def fetch():
    """허브에서 축제 지역(과 대조 지역)의 유동인구, 날씨를 자동으로 가져온다."""
    form = {**(request.get_json(silent=True) or {}), "allow_missing": True}
    try:
        spec, _, _ = core.build_spec(form, {}, core.config())
        lo, hi = spec.window
        files = hub.collect([e for e in (spec.emd, spec.control) if e], lo, hi)
    except (core.SpecError, hub.HubError) as e:
        return jsonify({"ok": False, "html": f'<div class="warn">{html.escape(str(e))}</div>', **_status()})
    for p in files:
        _add(load_csv(p.read_bytes(), p.name))
    names = ", ".join(p.name for p in files)
    return jsonify({"ok": True, "html": f'<div class="ok">✔ 제주데이터허브에서 받았습니다: {html.escape(names)}</div>', **_status()})


@app.post("/upload")
def upload():
    msgs = []
    for f in request.files.getlist("files"):
        try:
            d = load_csv(f.read(), f.filename)
            _add(d)
            extra = f" 값이 숫자가 아닌 {d.dropped:,}행은 제외했습니다." if d.dropped else ""
            msgs.append({"ok": True, "text": f"{f.filename} → '{d.name}'(으)로 인식했습니다. ({len(d.df):,}행){extra}"})
        except DatasetError as e:
            msgs.append({"ok": False, "text": f"{f.filename}: {e}"})
        except Exception as e:  # 깨진 파일 등
            msgs.append({"ok": False, "text": f"{f.filename}: 파일을 읽지 못했습니다. CSV 파일인지 확인해 주세요. ({type(e).__name__})"})
    return jsonify({"messages": msgs, **_status()})


def _verify(form, prefix="", case=None):
    if not DATA:
        return jsonify({"html": '<div class="card warn">데이터가 없습니다. 허브에서 가져오거나 CSV를 넣어 주세요.</div>'})
    try:
        ans = core.verify(form, DATA)
    except core.SpecError as e:
        return jsonify({"html": f'<div class="card warn">{html.escape(str(e))}</div>'})
    if prefix:
        ans["spec_html"] = prefix + ans["spec_html"]
    ans["case_id"] = case["id"] if case else None
    # 같은 축제를 다시 검증하면 이전 결과를 바꿔 끼운다 (보고서에 중복으로 쌓이지 않게)
    HISTORY[:] = [a for a in HISTORY if a["question"] != ans["question"]]
    HISTORY.append(ans)
    return jsonify({"html": report.answer_html(ans)})


PREP_CASES = [
    {"id": "deulbul2026", "label": "2026 제주들불축제 준비하기 (2025 축제 기준)", "name": "제주들불축제 준비",
     "place": "새별오름", "wx_from": "03-07", "wx_to": "03-23", "ref_start": "2025-03-14", "ref_end": "2025-03-16",
     "summary": "애월읍 새별오름. 2025년에는 강풍으로 이틀째부터 행사가 전면 취소됨."},
]


def _prep_spec(form) -> prep.PrepSpec:
    def md(v, default):
        v = (v or "").strip()
        if len(v) == 10:          # 2026-03-07 처럼 날짜 전체를 넣어도 월-일만 쓴다
            v = v[5:]
        return v or default
    ref_s, ref_e = (form.get("ref_start") or "").strip(), (form.get("ref_end") or "").strip()
    place = (form.get("place") or "").strip()
    if not place:
        raise tools.ToolError("행사장 이름(예: 새별오름)을 적어 주세요.")
    start = pd.Timestamp(ref_s) if ref_s else None
    end = pd.Timestamp(ref_e) if ref_e else start
    wx_from = md(form.get("wx_from"), f"{start - pd.Timedelta(days=7):%m-%d}" if start is not None else "")
    wx_to = md(form.get("wx_to"), f"{end + pd.Timedelta(days=7):%m-%d}" if end is not None else "")
    if not wx_from or not wx_to:
        raise tools.ToolError("날씨를 볼 기간(예: 03-07 ~ 03-23)이나 지난 축제 기간을 적어 주세요.")
    radius = float(form.get("radius") or 2.0)
    return prep.PrepSpec(name=(form.get("name") or place + " 행사 준비").strip(), place=place, wx_from=wx_from,
                         wx_to=wx_to, ref_start=start, ref_end=end, radius_km=radius)


def _prep(form, note=""):
    cfg = core.config()
    try:
        spec = _prep_spec(form)
    except (tools.ToolError, ValueError) as e:
        return jsonify({"html": f'<div class="card warn">{html.escape(str(e))}</div>'})
    who = form.get("audience") if form.get("audience") in prep.AUDIENCES else "organizer"
    results, errors = [], []
    for f in (prep.weather_risk, prep.bus_demand):
        if f is prep.bus_demand and who == "outdoor" and not spec.ref_days:
            continue   # 일반 야외 행사는 장소·날짜만으로 날씨만 본다
        try:
            results.append(f(spec, cfg))
        except tools.ToolError as e:
            errors.append(str(e))
    items = [{"result": r, "text": prep.sentence(r), "how": "자동 요약"} for r in results]
    ref = f"{spec.ref_start:%Y-%m-%d} ~ {spec.ref_end:%Y-%m-%d}" if spec.ref_start is not None else "없음"
    spec_html = ('<table><tbody>'
                 f'<tr><th>행사</th><td class="l">{html.escape(spec.name)}</td><th>행사장</th><td class="l">{html.escape(spec.place)}</td></tr>'
                 f'<tr><th>날씨 볼 기간</th><td class="l">해마다 {spec.wx_from} ~ {spec.wx_to}</td>'
                 f'<th>비교할 지난 축제</th><td class="l">{ref}</td></tr></tbody></table>'
                 f'<div class="say"><b>[{html.escape(prep.AUDIENCES[who])}용 정리]</b> {html.escape(prep.advice(results, who))} '
                 '<span class="small">(실측 숫자로 만든 자동 정리 · 결정은 사람이 합니다)</span></div>'
                 + _other_audiences(results, who))
    ans = {"question": f"축제 준비: {spec.name} ({spec.place})", "mode": "기본 모드(규칙 기반)", "note": "",
           "errors": errors, "results": items, "time": time.strftime("%Y-%m-%d %H:%M"),
           "min_count": cfg["min_count"], "spec": None, "kind": "prep", "case_id": None,
           "spec_html": note + spec_html}
    HISTORY[:] = [a for a in HISTORY if a["question"] != ans["question"]]
    HISTORY.append(ans)
    return jsonify({"html": report.answer_html(ans)})


def _other_audiences(results, who) -> str:
    """같은 숫자를 다른 사람에게는 어떻게 말하는지 (접어 두기)."""
    if not results:
        return ""
    rows = "".join(f'<div style="margin:6px 0"><b>{html.escape(label)}</b> — {html.escape(prep.advice(results, key))}</div>'
                   for key, label in prep.AUDIENCES.items() if key != who)
    return f'<details><summary>같은 숫자, 다른 사람에게는 이렇게 (숫자는 같고 말만 다릅니다)</summary><div class="small">{rows}</div></details>'


def _fest_table(rows) -> str:
    if rows is None or len(rows) == 0:
        return ""
    body = []
    for _, r in rows.iterrows():
        c = festivals.coverage(r)
        ok = "바로 계산" if c["weather_ok"] else "누르면 허브에서 받아 계산"
        bus = f"버스 축제일 {c['bus_fest']} · 평소 {c['bus_base']}일"
        btn = (f'<button class="btn" style="padding:6px 10px;font-size:13px" onclick="festPrep(\'{r["id"]}\')">이 회차로 계산</button>')
        ed = f"{html.escape(r['edition'])} " if r["edition"] else ""
        body.append(
            f'<tr><td class="l"><b>{ed}{html.escape(r["name"])}</b></td><td>{r["year"]}</td>'
            f'<td class="l">{r["start"]:%Y-%m-%d} ~ {r["end"]:%Y-%m-%d}</td><td class="l">{html.escape(r["status"])}</td>'
            f'<td class="l">{html.escape(r["venue"])}<br><span class="small">정류소: {html.escape(r["place"])} · {html.escape(r["place_note"])}</span></td>'
            f'<td class="l"><a href="{html.escape(r["source_url"])}" target="_blank">{html.escape(r["source_title"])}</a></td>'
            f'<td class="l small">날씨 {c["weather"]}<br>{bus}<br><b>{ok}</b></td><td>{btn}</td></tr>')
    return ('<table><thead><tr><th>정식 이름</th><th>연도</th><th>기간</th><th>상태</th><th>장소</th><th>출처</th>'
            '<th>받아 둔 자료</th><th></th></tr></thead><tbody>' + "".join(body) + "</tbody></table>")


@app.get("/festivals")
def festival_search():
    q = (request.args.get("q") or "").strip()
    if not q:
        cat, visit = festivals.load()
        note = (f'<div class="small">VISIT JEJU 행사 목록 {len(visit)}건도 함께 찾습니다.</div>' if len(visit)
                else '<div class="small">VISIT JEJU 「축제행사콘텐츠」 CSV(허브 데이터 761)를 data 폴더에 넣으면 그 목록에서도 이름·기간을 찾습니다.</div>')
        return jsonify({"html": f'<div class="say"><b>확인된 축제 회차 {len(cat)}건</b> (모두 출처 링크 있음)</div>'
                                + _fest_table(cat.sort_values(["name", "year"])) + note})
    r = festivals.search(q)
    out = f'<div class="say"><b>확인 결과</b> {html.escape(r["verdict"])}</div>'
    if r.get("found"):
        out += _fest_table(r["rows"])
        v = r["visit_rows"]
        if len(v):
            out += ('<div class="small" style="margin-top:6px">VISIT JEJU 목록: '
                    + " · ".join(f'{html.escape(x["name"])} {x["start"]:%Y-%m-%d}~{x["end"]:%m-%d}' for _, x in v.head(10).iterrows())
                    + "</div>")
    return jsonify({"html": out})


def _pick(rows):
    """계산에 쓸 회차: 자료가 있는 회차 중 가장 최근, 없으면 가장 최근."""
    rows = rows.sort_values("start", ascending=False)
    ok = [r for _, r in rows.iterrows() if festivals.coverage(r)["weather_ok"]]
    return ok[0] if ok else rows.iloc[0]


@app.post("/festival_go")
def festival_go():
    """이름만 받아: 언제 열렸는지 보여 주고, 자료가 있으면 그 날짜로 바로 계산한다."""
    body = request.get_json(silent=True) or {}
    q = (body.get("q") or "").strip()
    if not q:
        return festival_search()
    r = festivals.search(q)
    out = f'<div class="say"><b>언제 열렸나</b> {html.escape(r["verdict"])}</div>'
    if not r.get("found") or len(r["rows"]) == 0:
        return jsonify({"html": out})
    rows = r["rows"]
    if len(r["names"]) > 1:      # 여러 축제가 걸리면 고르게 한다
        return jsonify({"html": out + '<div class="small">여러 축제가 맞습니다. 아래에서 고르세요.</div>' + _fest_table(rows)})
    row = _pick(rows)
    got = ""
    if not festivals.coverage(row)["weather_ok"]:      # 자료가 없으면 지금 허브에서 바로 받는다
        try:
            n = live.fetch_weather(row)
            got = f'<div class="ok small">허브에서 이 축제 시기 날씨 {n}일치를 방금 받았습니다 (다음부터는 바로 나옵니다).</div>'
        except live.LiveError as e:
            got = f'<div class="warn">{html.escape(str(e))}</div>'
    out += _fest_table(rows) + got
    if not festivals.coverage(row)["weather_ok"]:
        out += (f'<div class="warn">{row["year"]}년 {html.escape(row["name"])}의 날짜는 확인했지만 날씨 자료가 아직 모자라 계산은 못 했습니다.</div>')
        return jsonify({"html": out})
    return jsonify({"html": out + _fest_prep_html(row, body.get("audience", "organizer"))})


def _fest_prep_html(row, audience) -> str:
    form = {**festivals.prep_form(row), "audience": audience}
    ed = f"{row['edition']} " if row["edition"] else ""
    note = (f'<div class="small">계산에 쓴 회차: {row["year"]}년 {html.escape(ed + row["name"])} '
            f'({row["start"]:%Y-%m-%d} ~ {row["end"]:%Y-%m-%d}) · 날짜는 출처에서 자동으로 가져옴</div>')
    res = _prep(form, note).get_json()["html"]
    todo = live.bus_todo(row)
    if todo:
        calls = len(todo) * 70
        res += (f'<div class="row"><button class="btn g" onclick="festBus(\'{row["id"]}\')">버스 이용 자료도 받아서 다시 계산 '
                f'({len(todo)}일치, {live.minutes(calls)})</button></div>')
    return res


@app.post("/festival_bus/<fid>")
def festival_bus(fid):
    row = festivals.get(fid)
    if row is None:
        return jsonify({"html": '<div class="warn">목록에 없는 축제입니다.</div>'})
    msg = ""
    try:
        n = live.fetch_bus(row)
        msg = f'<div class="ok small">허브에서 버스 이용 자료 {n}일치를 방금 받았습니다.</div>'
    except live.LiveError as e:
        msg = f'<div class="warn">{html.escape(str(e))}</div>'
    return jsonify({"html": msg + _fest_prep_html(row, (request.get_json(silent=True) or {}).get("audience", "organizer"))})


# ---------- 제주 축제 길잡이 (새 첫 화면) ----------

def _pop_df():
    d = DATA.get("pop")
    return None if d is None else d.df


@app.get("/api/guide")
def api_guide():
    """이름(q) 또는 회차(id)로 길잡이 정보를 돌려준다. 자료가 없으면 허브에서 바로 받는다."""
    q, fid = (request.args.get("q") or "").strip(), (request.args.get("id") or "").strip()
    notes = []
    if fid:
        row = festivals.get(fid)
        if row is None:
            return jsonify({"found": False, "verdict": "목록에 없는 회차입니다."})
        verdict = ""
    else:
        r = festivals.search(q)
        if not r.get("found") or len(r["rows"]) == 0:
            return jsonify({"found": False, "verdict": r["verdict"]})
        if len(r["names"]) > 1:
            cat, _ = festivals.load()
            ch = cat[cat["name"].isin(r["names"])].sort_values("start", ascending=False).drop_duplicates("name")
            return jsonify({"found": True, "choices": [{"id": x["id"], "name": x["name"]} for _, x in ch.iterrows()],
                            "verdict": "여러 축제가 맞습니다. 하나를 고르세요."})
        row = _pick(r["rows"])
        verdict = r["verdict"] if r["how"].startswith("비슷한") else ""
    if not festivals.coverage(row)["weather_ok"]:
        try:
            n = live.fetch_weather(row)
            notes.append(f"허브에서 날씨 {n}일치를 방금 받았습니다.")
        except live.LiveError as e:
            notes.append(str(e))
    miss = live.pop_missing(row, _pop_df())
    if miss:
        try:
            for p in live.fetch_pop(row, miss):
                _add(load_csv(p.read_bytes(), p.name))
            notes.append(f"허브에서 {', '.join(miss)} 유동인구를 방금 받았습니다.")
        except (live.LiveError, DatasetError) as e:
            notes.append(str(e))
    info = guide.build(row, _pop_df())
    w_ok = info["weather"] and not info["weather"].get("error")
    if w_ok and info["crowd"]:          # 보여 줄 자료가 있으면 '키 없음' 같은 안내는 숨긴다
        notes = [n for n in notes if "방금 받았습니다" in n]
    info.update({"found": True, "verdict": verdict, "notes": notes, "bus_todo": len(live.bus_todo(row))})
    return jsonify(info)


@app.get("/api/extra")
def api_extra():
    row = festivals.get(request.args.get("id", ""))
    if row is None:
        return jsonify({})
    return jsonify(guide.extra(row, guide.build(row, _pop_df())))


PERSONA_HTML = (BASE / "agent" / "persona.html")


@app.get("/for/<mode>")
def persona(mode):
    return Response(PERSONA_HTML.read_text(encoding="utf-8"), mimetype="text/html; charset=utf-8")


@app.get("/api/settings")
def api_settings():
    k = settings.current_key()
    return jsonify({"has_key": bool(k), "masked": settings.masked(k),
                    "others": [{"path": o["path"], "masked": o["masked"]} for o in settings.find_other_keys()]})


@app.post("/api/settings/key")
def api_set_key():
    body = request.get_json(silent=True) or {}
    key = (body.get("key") or "").strip()
    if body.get("from_path"):
        hit = [o for o in settings.find_other_keys() if o["path"] == body["from_path"]]
        key = hit[0]["key"] if hit else ""
    try:
        settings.save_key(key)
    except ValueError as e:
        return jsonify({"ok": False, "msg": str(e)})
    ok, msg = settings.test_key(key)
    return jsonify({"ok": True, "tested": ok, "msg": ("저장했습니다. " + msg), "masked": settings.masked(key)})


@app.get("/api/stations")
def api_stations():
    return jsonify(settings.stations(request.args.get("q", "")))


@app.post("/api/festivals")
def api_add_festival():
    try:
        row = settings.add_festival(request.get_json(silent=True) or {})
    except ValueError as e:
        return jsonify({"ok": False, "msg": str(e)})
    return jsonify({"ok": True, "id": row["id"], "msg": f"{row['year']} {row['name']}을(를) 목록에 넣었습니다."})


@app.post("/api/visitjeju")
def api_visitjeju():
    f = request.files.get("file")
    if f is None:
        return jsonify({"ok": False, "msg": "파일을 골라 주세요."})
    try:
        n = settings.save_visit_file(f.filename, f.read())
    except ValueError as e:
        return jsonify({"ok": False, "msg": str(e)})
    return jsonify({"ok": True, "msg": f"VISIT JEJU 행사 {n}건을 넣었습니다. 이제 그 이름으로도 찾을 수 있습니다."})


@app.post("/api/bus/<fid>")
def api_bus(fid):
    row = festivals.get(fid)
    if row is None:
        return jsonify({"ok": False, "msg": "목록에 없는 회차입니다."})
    try:
        n = live.fetch_bus(row)
        return jsonify({"ok": True, "msg": f"버스 {n}일치를 받았습니다."})
    except live.LiveError as e:
        return jsonify({"ok": False, "msg": str(e)})


@app.get("/api/names")
def api_names():
    cat, _ = festivals.load()
    return jsonify(sorted(cat["name"].unique().tolist()))


ART = BASE / "agent" / "art"
PHOTOS = BASE / "data" / "photos"


@app.get("/art/<name>.svg")
def art(name):
    """직접 그린 제주 그림 (한라산·오름·유채·돌하르방). 인터넷 없이도 나온다."""
    f = ART / f"{name}.svg"
    if not f.is_file() or f.parent != ART:
        return Response("", status=404)
    return Response(f.read_bytes(), mimetype="image/svg+xml", headers={"Cache-Control": "max-age=3600"})


@app.get("/photo/<name>")
def photo(name):
    """data/photos/ 에 hero·fun·prep 사진을 넣으면 그림 대신 사진을 쓴다 (없으면 404 → 그림이 보임)."""
    if name not in ("hero", "fun", "prep"):
        return Response("", status=404)
    for ext, mt in ((".jpg", "image/jpeg"), (".jpeg", "image/jpeg"), (".png", "image/png"), (".webp", "image/webp")):
        f = PHOTOS / f"{name}{ext}"
        if f.is_file():
            return Response(f.read_bytes(), mimetype=mt)
    return Response("", status=404)


@app.get("/api/photos")
def api_photos():
    """넣어 둔 사진과 출처 (화면 아래 출처 표시용)."""
    try:
        cr = json.loads((PHOTOS / "credits.json").read_text(encoding="utf-8"))
    except Exception:
        cr = {}
    have = {n: any((PHOTOS / f"{n}{e}").is_file() for e in (".jpg", ".jpeg", ".png", ".webp")) for n in ("hero", "fun", "prep")}
    return jsonify({n: {"have": have[n], **cr.get(n, {})} for n in have})


@app.get("/api/catalog")
def api_catalog():
    """첫 화면 축제 카드: 축제마다 가장 최근 회차 하나 (달·장소·상태)."""
    cat, _ = festivals.load()
    pop = _pop_df()
    out = []
    for name, g in cat.groupby("name"):
        r = g.sort_values("start").iloc[-1]
        # 키 없이도 바로 볼 수 있나: 날씨와 유동인구를 이미 받아 둔 회차가 있으면 그 회차로 연다
        ready = [x for _, x in g.sort_values("start", ascending=False).iterrows()
                 if festivals.coverage(x)["weather_ok"] and not live.pop_missing(x, pop)]
        if ready:
            r = ready[0]
        s, e = str(r["start"])[:10], str(r["end"])[:10]
        out.append({"id": r["id"], "name": name, "start": s, "end": e,
                    "month": int(s[5:7]), "venue": str(r["venue"]), "status": str(r["status"]).split(" (")[0],
                    "editions": int(len(g)), "ready": bool(ready)})
    out.sort(key=lambda x: (x["month"], x["start"][5:]))
    return jsonify(out)


@app.post("/festival_prep/<fid>")
def festival_prep(fid):
    row = festivals.get(fid)
    if row is None:
        return jsonify({"html": '<div class="card warn">목록에 없는 축제입니다.</div>'})
    audience = (request.get_json(silent=True) or {}).get("audience", "organizer")
    msg = ""
    if not festivals.coverage(row)["weather_ok"]:
        try:
            n = live.fetch_weather(row)
            msg = f'<div class="ok small">허브에서 이 축제 시기 날씨 {n}일치를 방금 받았습니다.</div>'
        except live.LiveError as e:
            return jsonify({"html": f'<div class="card warn">{html.escape(str(e))}</div>'})
    return jsonify({"html": '<div class="card">' + msg + _fest_prep_html(row, audience) + "</div>"})


@app.post("/prep")
def prep_run():
    return _prep(request.get_json(silent=True) or {})


@app.post("/prep_case/<cid>")
def prep_case(cid):
    c = next((x for x in PREP_CASES if x["id"] == cid), None)
    if c is None:
        return jsonify({"html": '<div class="card warn">없는 사례입니다.</div>'})
    c = {**c, "audience": (request.get_json(silent=True) or {}).get("audience", "organizer")}
    return _prep(c, f'<div class="small">사례 설명: {html.escape(c["summary"])}</div>')


@app.post("/verify")
def verify():
    return _verify(request.get_json(silent=True) or {})


@app.get("/report")
def make_report():
    # 내장 실제 사례는 화면에서 누르지 않았어도 보고서에 항상 넣는다
    done = {a.get("case_id") for a in HISTORY}
    for c in CASES:
        if c["id"] not in done and all((BASE / "data" / "hub" / f).exists() for f in c["files"]):
            form = {k: c[k] for k in ("name", "emd", "start", "end", "control", "weather_station")}
            try:
                ans = core.verify(form, DATA)
                ans["spec_html"] = _case_note(c) + ans["spec_html"]
                ans["case_id"] = c["id"]
                HISTORY.insert(0, ans)
            except Exception:
                pass
    if not any(a.get("kind") == "prep" for a in HISTORY):
        for c in PREP_CASES:   # 준비 기본 사례도 자료가 있으면 넣는다
            try:
                _prep(c, f'<div class="small">사례 설명: {html.escape(c["summary"])}</div>')
            except Exception:
                pass
    if not HISTORY:
        return Response("아직 검증 결과가 없습니다.", mimetype="text/plain; charset=utf-8")
    ordered = [a for a in HISTORY if a.get("kind") == "prep"] + [a for a in HISTORY if a.get("kind") != "prep"]
    return Response(report.report_html(ordered, _datasets()), mimetype="text/html; charset=utf-8",
                    headers={"Content-Disposition": "attachment; filename=festival_report.html"})


@app.post("/reset")
def reset():
    DATA.clear(); HISTORY.clear(); load_bundled()
    return jsonify({"ok": True})


PAGE = """<!doctype html><html lang="ko"><head><meta charset="utf-8"><title>제주 축제 길잡이 · 자세히 보기</title>
<style>{{CSS}}
body{background:#f6f8fa}.top{background:#17324d;color:#fff;padding:14px 24px}.top h1{font-size:20px}
.top .meta{color:#c7d3df}
.drop{border:2px dashed #9fb3c8;border-radius:10px;padding:16px;text-align:center;background:#fff;cursor:pointer}
.drop.on{background:#e9f2fb}
label{display:block;font-size:13px;color:#42505e;margin:8px 0 3px}
input,textarea{width:100%;box-sizing:border-box;font-size:15px;padding:9px;border:1px solid #9fb3c8;border-radius:8px;font-family:inherit}
.grid{display:grid;grid-template-columns:2fr 1.2fr 1fr 1fr 1.2fr;gap:10px}
.btn{font-size:15px;padding:10px 18px;border:0;border-radius:8px;background:#2a6fb0;color:#fff;cursor:pointer}
.btn.g{background:#5b6875}.row{display:flex;gap:8px;margin-top:12px;flex-wrap:wrap}.ok{color:#1d6b3a}
.step{font-weight:700;color:#2a6fb0}.case{margin:10px 0}.case .small{margin-top:4px}
details summary{cursor:pointer;color:#2a6fb0;margin-top:10px}
.chip{display:inline-flex;align-items:center;gap:4px;margin:0;padding:6px 10px;border:1px solid #9fb3c8;border-radius:16px;background:#fff;font-size:14px;color:#17324d;cursor:pointer}
.chip input{width:auto;margin:0}
</style></head><body>
<div class="top"><h1><a href="/" style="color:#fff;text-decoration:none">← 제주 축제 길잡이</a> · 자세히 보기</h1>
<div class="meta">{{MODE}} · 반출 기준 {{MIN}}명 미만 자동 가림 · 이 화면은 이 PC 안에서만 열립니다</div></div>
<div class="wrap">
<div class="card"><div class="step">축제 이름만 넣으세요</div>
<div class="small">날짜는 넣지 않아도 됩니다. 축제가 언제 열렸는지(정식 이름·회차·기간·취소 여부)를 출처와 함께 찾아 보여 주고,
자료가 있으면 그 날짜로 날씨 위험과 버스 이용 변화를 바로 계산합니다. 이름은 대충 적어도 됩니다(예: 들블축제, 해녀축제).</div>
<div class="row"><input id="f_q" placeholder="예: 탐라문화제" style="flex:1" onkeydown="if(event.key==='Enter')festGo()">
<button class="btn" onclick="festGo()">확인하기</button><button class="btn g" onclick="$('f_q').value='';festFind()">목록 전체 보기</button></div>
<label>누가 보나요? (숫자는 같고, 고른 사람에게 맞는 말로 정리해 드립니다)</label>
<div class="row" id="aud" style="margin-top:4px">{{AUD}}</div>
<div id="fest_out" style="margin-top:10px"></div>
<details><summary>목록에 없는 행사: 장소와 날짜 직접 넣기</summary>
<div class="small">마을 행사·체육대회·야외 촬영처럼 목록에 없는 행사는 가까운 버스 정류소 이름과 날짜를 직접 넣습니다.</div>
{{PREP}}
<div class="grid" style="grid-template-columns:1.6fr 1.2fr 1fr 1fr 1fr 1fr">
<div><label>행사 이름</label><input id="p_name" placeholder="마을 체육대회"></div>
<div><label>행사장 (가까운 정류소 이름)</label><input id="p_place" placeholder="새별오름"></div>
<div><label>날씨 볼 기간 시작 (월-일)</label><input id="p_from" placeholder="03-07"></div>
<div><label>날씨 볼 기간 끝 (월-일)</label><input id="p_to" placeholder="03-23"></div>
<div><label>지난 행사 시작일 (선택)</label><input id="p_rs" type="date"></div>
<div><label>지난 행사 종료일 (선택)</label><input id="p_re" type="date"></div></div>
<div class="row"><button class="btn" onclick="prepRun()">준비 근거 계산하기</button></div></details>
<div id="prepds" class="small" style="margin-top:8px"></div></div>
<div class="card"><div class="step">지난 축제 성과 보기 — 실제 사례</div>
<div class="small">제주데이터허브의 실제 유동인구·날씨 데이터가 프로그램에 들어 있습니다. 버튼만 누르면 됩니다.</div>
{{CASES}}</div>
<div class="card"><div class="step">다른 축제 성과 검증하기</div>
<label>한 문장으로 적기 (아래 칸을 채우는 대신 써도 됩니다)</label>
<textarea id="text" rows="2" placeholder="예: 2025년 탐라문화제, 10월 10일부터 14일까지 삼도2동에서 열렸어"></textarea>
<div class="grid">
<div><label>축제 이름</label><input id="name"></div>
<div><label>개최 읍면동</label><input id="emd" list="emdlist" placeholder="애월읍"><datalist id="emdlist"></datalist></div>
<div><label>시작일</label><input id="start" type="date"></div>
<div><label>종료일</label><input id="end" type="date"></div>
<div><label>대조 지역 (이웃 읍면동)</label><input id="control" list="emdlist" placeholder="한림읍"></div></div>
<label>날씨 관측소 (선택, 예: 새별오름)</label><input id="weather_station">
<div class="row"><button class="btn" onclick="fetchHub()">① 허브에서 데이터 자동으로 가져오기</button>
<button class="btn" onclick="verify()">② 성과 검증하기</button>
<button class="btn g" onclick="prescribe()">필요한 데이터 보기</button></div>
<div id="hubmsg" class="small" style="margin-top:8px"></div>
<details><summary>센터에서 받은 CSV 직접 넣기 (센터 PC에서 반출 불가 데이터를 쓸 때)</summary>
<div class="small">지원: 내국인 유동인구(읍면동), 버스 정류소별 이용 현황, 일일 날씨 정보, 허브 유동인구·기상</div>
<div id="drop" class="drop" style="margin-top:8px">여기에 CSV 파일을 끌어다 놓거나 눌러서 고르세요
<input id="file" type="file" accept=".csv" multiple style="display:none"></div>
<div id="msgs" class="small" style="margin-top:8px"></div></details>
<div id="rx" style="margin-top:8px"></div>
<div class="small" style="margin-top:10px"><b>지금 들어 있는 데이터</b></div><div id="ds"></div></div>
<div class="card"><div class="row" style="margin-top:0"><button class="btn g" onclick="location.href='/report'">보고서 파일 받기</button>
<button class="btn g" onclick="resetAll()">결과 지우기</button></div>
<div id="busy" class="small" style="display:none;margin-top:8px">작업 중입니다… (처음 보는 축제는 허브에서 자료를 받느라 1~3분 걸릴 수 있습니다)</div></div>
<div id="out"></div></div>
<script>
const $=id=>document.getElementById(id);
const form=()=>({text:$('text').value,name:$('name').value,emd:$('emd').value,start:$('start').value,end:$('end').value,control:$('control').value,weather_station:$('weather_station').value});
const post=async(u,b)=>(await fetch(u,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(b||{})})).json();
function show(st){ $('ds').innerHTML=st.datasets.length?'<table><thead><tr><th>데이터</th><th>출처</th><th>행 수</th><th>기간</th><th>읍면동</th></tr></thead><tbody>'+
  st.datasets.map(d=>`<tr><td class="l">${d.name}</td><td class="l">${d.source}</td><td>${d.rows.toLocaleString()}</td><td class="l">${d.period}</td><td class="l">${d.emds}</td></tr>`).join('')+'</tbody></table>':'<div class="warn">데이터가 없습니다.</div>';
  $('emdlist').innerHTML=st.emds.map(e=>`<option value="${e}">`).join('');
  if(st.prep) $('prepds').innerHTML=`받아 둔 준비 자료 — 날씨: ${st.prep.weather} · 버스: ${st.prep.bus} · 정류소 위치: ${st.prep.stations} · 관측소: ${st.prep.observatories}`;
  if(!st.hub_key) $('hubmsg').innerHTML='허브 자동 가져오기를 쓰려면 .env 파일에 HUB_PROJECT_KEY 를 적어 주세요 (README 참고). 실제 사례 버튼은 키 없이 됩니다.';}
async function busy(f){$('busy').style.display='block'; try{await f();}catch(e){$('out').insertAdjacentHTML('afterbegin','<div class="card warn">오류가 발생했습니다. 프로그램 창이 켜져 있는지 확인해 주세요.</div>');} $('busy').style.display='none';}
const drop=$('drop'),file=$('file');
drop.onclick=()=>file.click(); file.onchange=()=>send(file.files);
drop.ondragover=e=>{e.preventDefault();drop.classList.add('on')}; drop.ondragleave=()=>drop.classList.remove('on');
drop.ondrop=e=>{e.preventDefault();drop.classList.remove('on');send(e.dataTransfer.files)};
async function send(files){const fd=new FormData();for(const f of files)fd.append('files',f);
 $('msgs').textContent='파일을 읽는 중입니다…';
 const r=await (await fetch('/upload',{method:'POST',body:fd})).json();
 $('msgs').innerHTML=r.messages.map(m=>`<div class="${m.ok?'ok':'warn'}">${m.ok?'✔':'✖'} ${m.text}</div>`).join(''); show(r);}
function festBus(id){busy(async()=>{const r=await post('/festival_bus/'+id,{audience:aud()}); $('fest_out').insertAdjacentHTML('beforeend',r.html);});}
function festGo(){$('fest_out').innerHTML='<div class="small">확인하는 중입니다… 처음 보는 축제는 허브에서 자료를 받느라 1~3분 걸릴 수 있습니다.</div>';busy(async()=>{const r=await post('/festival_go',{q:$('f_q').value,audience:aud()}); $('fest_out').innerHTML=r.html;});}
async function festFind(){const r=await (await fetch('/festivals?q='+encodeURIComponent($('f_q').value))).json(); $('fest_out').innerHTML=r.html;}
function festPrep(id){$('fest_out').insertAdjacentHTML('beforeend','<div class="small" id="fp_wait">계산하는 중입니다… 처음 보는 축제는 1~3분 걸릴 수 있습니다.</div>');busy(async()=>{const r=await post('/festival_prep/'+id,{audience:aud()}); const w=$('fp_wait'); if(w) w.remove(); $('fest_out').insertAdjacentHTML('beforeend',r.html);});}
const aud=()=>(document.querySelector('input[name=aud]:checked')||{}).value||'organizer';
function runPrep(id){busy(async()=>{const r=await post('/prep_case/'+id,{audience:aud()}); $('out').insertAdjacentHTML('afterbegin',r.html); $('out').scrollIntoView();});}
function prepRun(){busy(async()=>{const r=await post('/prep',{name:$('p_name').value,place:$('p_place').value,wx_from:$('p_from').value,wx_to:$('p_to').value,ref_start:$('p_rs').value,ref_end:$('p_re').value,audience:aud()}); $('out').insertAdjacentHTML('afterbegin',r.html); $('out').scrollIntoView();});}
function runCase(id){busy(async()=>{const r=await post('/case/'+id); $('out').insertAdjacentHTML('afterbegin',r.html); $('out').scrollIntoView();});}
function fetchHub(){busy(async()=>{$('hubmsg').textContent='제주데이터허브에서 받는 중입니다 (1~2분)…'; const r=await post('/fetch',form()); $('hubmsg').innerHTML=r.html; show(r);});}
function verify(){busy(async()=>{const r=await post('/verify',form()); $('out').insertAdjacentHTML('afterbegin',r.html); $('out').scrollIntoView();});}
async function prescribe(){$('rx').innerHTML=(await post('/prescribe',form())).html;}
async function resetAll(){await post('/reset');location.reload();}
fetch('/status').then(r=>r.json()).then(show);
</script></body></html>"""


def free_port(start: int) -> int:
    """이미 다른 프로그램(예: 예전에 켜 둔 창)이 쓰는 포트면 다음 번호를 쓴다."""
    for p in range(start, start + 30):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(0.3)
            if s.connect_ex(("127.0.0.1", p)) != 0:
                return p
    return start


load_bundled()

if __name__ == "__main__":
    want = int(os.environ.get("PORT", "8501"))
    port = free_port(want)
    url = f"http://127.0.0.1:{port}"
    if port != want:
        print(f"\n  [안내] {want}번은 다른 프로그램이 쓰고 있어 {port}번으로 엽니다.")
    if os.environ.get("NO_BROWSER") != "1":
        threading.Timer(1.2, lambda: webbrowser.open(url)).start()
    print("\n  제주 축제 길잡이를 시작합니다. 브라우저가 자동으로 열립니다.")
    print(f"  화면 주소: {url}\n  끝내려면 이 창을 닫으세요.\n")
    app.run(host="127.0.0.1", port=port, debug=False)
