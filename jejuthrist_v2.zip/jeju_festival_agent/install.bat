@echo off
chcp 65001 >nul
cd /d "%~dp0"
python --version >nul 2>&1
if errorlevel 1 goto nopython
python -X utf8 scripts\install.py
if errorlevel 1 echo [!] Install did not finish. See the message above.
pause
exit /b
:nopython
echo [!] Python was not found.
echo     1. Install Python 3.10 or newer: https://www.python.org/downloads/
echo     2. On the first setup screen, check "Add python.exe to PATH".
echo     3. Run install.bat again.
pause
exit /b 1
