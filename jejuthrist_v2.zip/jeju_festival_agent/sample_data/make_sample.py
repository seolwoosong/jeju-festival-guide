"""가상 데이터 만들기 (개발·시연용).

실제 센터 데이터가 아니다. 대회 제공 '예시데이터 및 컬럼확인용' 파일의 컬럼 구성과 CSV 규격
(영문 헤더, 쉼표, UTF-8, 결측 NA)만 따라 무작위로 만든 값이다.
'가을빛 축제'는 지어낸 행사이고, 수치는 실제 제주와 무관하다.

심어 둔 효과 (도구가 이 값을 되찾는지 검증하는 데 쓴다)
  - 삼도2동, 2026-10-09 ~ 10-13, 11~21시의 방문 인구를 1.5배로 늘림
  - 그중 도외(그외) 거주자와 20·30대를 더 늘림
  - 10-11 은 비가 와서 늘어난 폭을 절반으로 줄임
  - 한림읍에는 아무 효과도 넣지 않음 (대조용)
실행: python sample_data/make_sample.py
"""
import csv
import random
from datetime import date, timedelta
from pathlib import Path

OUT = Path(__file__).resolve().parent
random.seed(7)
DOW = ["월", "화", "수", "목", "금", "토", "일"]
DAYS = [date(2026, 9, 11) + timedelta(i) for i in range(61)]           # 09-11 ~ 11-10 (축제 전후 4주)
FEST = {date(2026, 10, 9) + timedelta(i) for i in range(5)}             # 10-09(금) ~ 10-13(화)
RAIN_DAY = date(2026, 10, 11)
EMDS = [("제주시 중부(서)", "50110530", "제주시 삼도2동", 1.0), ("제주시 서부", "50110250", "제주시 한림읍", 0.7)]
AGES = ["1014", "1519", "2024", "2529", "3034", "3539", "4044", "4549", "5054", "5559", "6064", "6569", "7000"]
AGE_W = [0.3, 0.6, 1.0, 1.1, 1.1, 1.0, 1.0, 1.0, 0.9, 0.8, 0.7, 0.5, 0.6]
HOUR_W = [.15, .1, .08, .08, .1, .2, .4, .7, .9, 1, 1.1, 1.2, 1.3, 1.3, 1.2, 1.2, 1.2, 1.3, 1.3, 1.1, .9, .6, .4, .25]
rain = {d: random.choice([0, 0, 0, 0, 0, 0, 0, 0.4, 3, 9, 25]) for d in DAYS}
for d in FEST:
    rain[d] = 0
rain[RAIN_DAY] = 12.0


def noisy(x):
    return max(0.0, round(random.gauss(x, max(x * 0.08, 0.4)), 2))


with open(OUT / "sample_floating_pop.csv", "w", newline="", encoding="utf-8") as f:
    w = csv.writer(f)
    w.writerow(["base_date", "time", "dstrct_se", "emd_cd", "emd_nm", "sex", "age",
                "resd_pop_cnt", "work_pop_cnt", "visit_pop_cnt", "resd"])
    for d in DAYS:
        wk = 1.25 if d.weekday() >= 5 else 1.0
        day_noise = random.gauss(1.0, 0.04)
        for dist, cd, emd, size in EMDS:
            fest_here = emd.endswith("삼도2동") and d in FEST
            for h in range(24):
                boost = 1.0
                if fest_here and 11 <= h <= 21:
                    boost = 1.25 if d == RAIN_DAY else 1.5
                for sex in ("남성", "여성"):
                    for age, aw in zip(AGES, AGE_W):
                        for resd, rw in (("제주", 0.7), ("그외", 0.3)):
                            b = boost
                            if b > 1:  # 도외 거주자와 20·30대가 더 많이 온다
                                b = 1 + (b - 1) * (1.6 if resd == "그외" else 0.75) * (1.5 if age in ("2024", "2529", "3034", "3539") else 0.8)
                            visit = 22 * size * HOUR_W[h] * aw * rw * wk * day_noise * b
                            resd_pop = 60 * size * aw * (1.2 - HOUR_W[h] * 0.3) if resd == "제주" else 0
                            work = 15 * size * aw * HOUR_W[h] * (0.4 if d.weekday() >= 5 else 1) * rw
                            w.writerow([d.strftime("%Y%m%d"), h, dist, cd, emd, sex, age,
                                        noisy(resd_pop), noisy(work), noisy(visit), resd])

STATIONS = [("탑동광장", 60, True), ("중앙로사거리", 80, True), ("제주시청", 100, False),
            ("한림환승정류장", 30, False)]
with open(OUT / "sample_station_usage.csv", "w", newline="", encoding="utf-8") as f:
    w = csv.writer(f)
    w.writerow(["base_date", "day_of_week", "base_hour", "bus_station_id", "bus_station_name",
                "get_on_off_type", "user_category", "pay_type", "user_count"])
    for d in DAYS:
        wk = 0.8 if d.weekday() >= 5 else 1.0
        for i, (nm, size, near) in enumerate(STATIONS):
            boost = 1.3 if (near and d in FEST) else 1.0
            for h in range(6, 23):
                for typ, tw in (("승차", 1.0), ("하차", 0.9)):
                    for cat, cw in (("일반", 0.7), ("청소년", 0.12), ("경로", 0.18)):
                        n = int(noisy(size * HOUR_W[h] * tw * cw * wk * boost * 0.5) + 0.5)
                        if n > 0:
                            w.writerow([d.strftime("%Y%m%d"), DOW[d.weekday()], h, 2000 + i, nm, typ, cat, "카드", n])

with open(OUT / "sample_weather_daily.csv", "w", newline="", encoding="utf-8") as f:
    w = csv.writer(f)
    w.writerow(["base_date", "observatory_code", "average_temperature", "lowest_temperature",
                "lowest_temperature_time", "highest_temperature", "highest_temperature_time", "daily_rainfall",
                "maximum_wind_speed", "maximum_wind_speed_time", "average_wind_speed",
                "maximum_wind_speed_direction", "pt_year", "pt_month"])
    for d in DAYS:
        for obs in ("184", "189", "328"):
            t = round(23 - (d - DAYS[0]).days * 0.12 + random.uniform(-2, 2), 1)
            wind = "NA" if random.random() < 0.03 else round(random.uniform(1, 6), 1)
            w.writerow([d.strftime("%Y%m%d"), obs, t, round(t - 4, 1), "0530", round(t + 4, 1), "1410",
                        round(rain[d] * random.uniform(0.85, 1.15), 1), round(random.uniform(4, 14), 1), "1300",
                        wind, round(random.uniform(0, 360), 1), d.year, d.month])
print("가상 데이터 3개를 만들었습니다:", OUT)
